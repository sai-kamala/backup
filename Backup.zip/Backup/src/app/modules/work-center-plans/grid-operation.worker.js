
onmessage = function(e) {
  const input = e.data;
  switch (input.type) {
    case 'filterSearch': 
      filterGrid(input);
      break;
    case 'sort':
      sortGrid(input);
      break;
  }
};

searchGrid = (array, term) => {
  term = term.toUpperCase();
  return  [...array].filter(rec => {
    const values = Object.values(rec).join("^").toUpperCase();
    return values.indexOf(term) > -1 ? true : false;
  });
};

filterGrid = input => {
  const { dataArr, filters, searchTerm, constants, type} = input;
  let filteredData = [...dataArr];
  if(Object.keys(filters).length > 0) {
    filteredData = [...dataArr].filter(rec => {
      let isValid = true;
      Object.keys(filters).forEach(attr => {
        if(constants.typeDropDowns[attr]) {
          rec[attr].forEach(opt => {
            if(opt[constants.typeDropDowns[attr]['key']] === filters[attr]) isValid = opt.IsSelected;
          })
        } else {
          if(isValid) isValid = rec[attr] ? rec[attr].indexOf(filters[attr]) > -1 : rec[attr] === filters[attr]
        }
      })
      return isValid;
    });
  }

  const finalResults = searchTerm ? searchGrid(filteredData, searchTerm) : [...filteredData]
  postResult(finalResults, type);
}

sortGrid = input => {
  const { dataArr, field, sortMode, type} = input;
  let dataToSort = [...dataArr];
  dataToSort.sort((a, b) => {
    return sortMode === 1
      ? a[field] - b[field]
      : b[field] - a[field];
  });

  postResult([...dataToSort], type);
}

postResult = (result, key) => {
  const message = {
    key,
    result
  };
  postMessage(message);
};
