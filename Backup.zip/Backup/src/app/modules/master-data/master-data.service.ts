import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { environment } from 'src/environments/environment';
export interface Todo {
  DataTypes: any[];
  DataTypeKeyValues: any[];
}

@Injectable()
export class MasterdataService {
  private baseUrl: string = environment.api;

  constructor(private http: HttpClient, private toastr: ToastrService) {
  }
  getDataTypes(): Observable<any> {
    return this.http.get(`${this.baseUrl}MasterData/GetDataTypes`);
  }
  getDimensionalTypes(): Observable<any> {
    return this.http.get(`${this.baseUrl}Common/GetDropDownValues?type=Dimensional UOM&value=`);
  }
  getWeightTypes(): Observable<any> {
    return this.http.get(`${this.baseUrl}Common/GetDropDownValues?type=Weight UOM&value= `);
  }
  saveMasterData(data): Observable<any> {
    return this.http.post(`${this.baseUrl}MasterData/Save`, data);
  }
  getMasterData(data): Observable<any> {
    return this.http.post(`${this.baseUrl}MasterData/GetSearchResults`, data);
  }
  getServerExcelFilePath(data): Observable<any> {
    return this.http.post(`${this.baseUrl}MasterData/ExportExcel`, data);
  }

  getSegmentsByUserId(): Observable<any> {
    return this.http.get(`${this.baseUrl}Common/GetSegmentsByUserId`);
  }
  getStorageUnitId(): Observable<any> {
    return this.http.get(`${this.baseUrl}Common/GetStorageUnitIdList`);
  }

  masterDataFileValidation = sender => {
    const validExts = new Array('.xlsx', '.xls');
    let fileExt = sender.name;
    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
    if (validExts.indexOf(fileExt) < 0) {
      return false;
    } else { return true; }
  }
  filterMasterDataDescOptions = (exist_data, new_data, checkelement) => {
    new_data.forEach(element => {
      if (exist_data.indexOf(element[checkelement]) < 0) {
        exist_data.push(element[checkelement].toString());
      }
    });
    return exist_data;
  }
  masterDataStringValidation = str => {
    return str.split('_').join(' ');
  }
  excelHeadersValidation = (value, data) => {
    let status = true;
    if (value.length === data.length) {
      value.forEach((element, index) => {
        if (!element['title'] || !data[index] || element['title'].toUpperCase() !== data[index].toUpperCase()) {
          status = false;
        }
      });
    } else {
      status = false;
    }
    return status;
  }

  objMasterData = (key, data) => {
    const Obj = {};
    key.forEach((element, index) => {
      Obj[element.field] = data[index];
    });
    Obj['isNew'] = true;
    Obj['isError'] = false;
    return Obj;
  }

  validateExcelData = (data, fields, searchCriteria) => {
    const returnData = { status: true, data: [] };
    if (
      data &&
      // data[0][0] === this.masterDataStringValidation(searchCriteria.DataType) &&
      this.excelHeadersValidation(fields, data[0])
    ) {
      const errorData = [];
      for (let i = 1; i < data.length; i++) {
        if (this.excelDataValidation(data[i])) {
          returnData.data.push(this.objMasterData(fields, data[i]));
        } else {
          errorData.push(i + 1);
        }

      }
    } else {
      this.toastr.error('Headers Mismatched Please Give Valid Formated Data');
      returnData.status = false;
    }
    return returnData;
  }
  excelDataValidation(data) {
    let status = true;
    if (data.length === 0) {
      status = false;
    }
    data.forEach((ele) => {
      if (ele === '') {
        status = false;
      }
    });

    return status;
  }

  getBranchDropDownList(value) {
    return this.http.get(`${this.baseUrl}HomeDashboard/GetWarehouseList?Segment=${value}`);
  }
}
