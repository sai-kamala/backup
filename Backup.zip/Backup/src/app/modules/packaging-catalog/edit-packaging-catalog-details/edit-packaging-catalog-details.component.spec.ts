import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPackagingCatalogDetailsComponent } from './edit-packaging-catalog-details.component';

describe('EditPackagingCatalogDetailsComponent', () => {
  let component: EditPackagingCatalogDetailsComponent;
  let fixture: ComponentFixture<EditPackagingCatalogDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPackagingCatalogDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPackagingCatalogDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
