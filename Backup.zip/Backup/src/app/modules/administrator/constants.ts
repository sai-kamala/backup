export const workCenter = 'WORK_CENTER_ID';
export const workCenterDDKey = 'WORK_CENTER_IDS';
export const groupKey = 'groups';
export const escalationKey = 'escalation';
export const segment= 'ORG_ID';
export const branch = 'FACILITY_ID';
export const oshKoshId = 'OSHKOSH_USER_ID';
export const approvalGroup = 'APPROVAL_GROUP';
export const username = 'USER_NAME';



export const planninParameterColumns = {
    columns: [

        { displayName: 'Oshkosh ID', value: 'OSHKOSH_USER_ID' },
        { displayName: 'User Name', value: 'USER_NAME' },
        { displayName: 'Segment', value: 'ORG_ID_LIST' },
        { displayName: 'Role Name', value: 'APP_ROLES' },
        { displayName: 'Email', value: 'EMAIL' }

    ]
};

export const escalationTblcolumns =
    [
        { title: 'Org ID', field: 'ORG_ID', isEdit: false, cellClass: 'col-edit-cell' },
        { title: 'Facility ID', field: 'FACILITY_ID', isEdit: false, cellClass: 'col-edit-cell' },
        { title: 'Escalation Days', field: 'ESCALATION_DAYS', isEdit: true, cellClass: 'col-edit-cell' }
    ];

export const addGroupTblColumns =
    [
        { title: 'Approval Group', field: 'APPROVAL_GROUP', isEdit: false, isValid: true, cellClass: 'col-edit-cell' },
        { title: 'Org ID', field: 'ORG_ID', isEdit: false, isValid: true, cellClass: 'col-edit-cell' },
        { title: 'Facility ID', field: 'FACILITY_ID', isEdit: false, isValid: true, cellClass: 'col-edit-cell' },
        { title: 'Work Center ID', field: 'WORK_CENTER_ID', isEdit: false, isValid: true, cellClass: 'col-edit-cell' },
        { title: 'Oshkosh User ID', field: 'OSHKOSH_USER_ID', isEdit: true, isValid: true, cellClass: 'col-edit-cell' },
        { title: 'User Name', field: 'USER_NAME', isEdit: false, isValid: true, cellClass: 'col-edit-cell' }
    ];

export const adminTabsList = [
    {
        displayName: 'Groups',
        value: groupKey
      },
      {
        displayName: 'Escalation Days',
        value: escalationKey
      }
]

export const wildCardLookUpConfig = [
    {
        serviceUrl: {
            dropdown: 'WildcardSearch/GetFields?fieldName=FACILITY_ID',
            table: 'WildcardSearch/GetDropdownValuesWarehouse'
        },
        tableFields: [
            { header: 'ID', field: 'FACILITY_ID' },
            { header: 'Description', field: 'FACILITY_DESC' }
        ],
        label: '',
        labelText: 'Branch',
        isMultiSelect: false,
        options: [],
        selectedData: '',
        modelName: 'FACILITY_ID',
        dependentData: '',
        styleclass: 'col-md-2',
        defaultselecteddropDownValue: { FIELD_NAME: 'FACILITY_ID' }
    },
    {
        serviceUrl: {
            dropdown: 'WildcardSearch/GetFields?fieldName=WORK_CENTER_ID',
            table: 'WildcardSearch/GetDropdownValuesWorkCenter'
        },
        tableFields: [
            { header: 'ID', field: workCenter },
            { header: 'Description', field: 'WORK_CENTER_DESC' }
        ],
        label: '',
        labelText: 'Work Center',
        isMultiSelect: true,
        selectedData: [],
        options: [],
        modelName: workCenter,
        styleclass: 'col-md-2',
        dependentData: '',
        defaultselecteddropDownValue: { FIELD_NAME: 'WORK_CENTER_ID' }
    },
    {
        serviceUrl: {
            dropdown: 'WildcardSearch/GetFields?fieldName=OSHKOSH_USER_ID',
            table: 'Common/GetAllUserInfo'
        },
        tableFields: [
            { header: 'User ID', field: 'OSHKOSH_USER_ID' },
            { header: 'User Name', field: 'USER_NAME' }
        ],
        label: '',
        labelText: 'Oshkosh User ID',
        isMultiSelect: true,
        selectedData: [],
        options: [],
        modelName: 'OSHKOSH_USER_ID',
        styleclass: 'col-md-2',
        dependentData: '',
        defaultselecteddropDownValue: { FIELD_NAME: 'OSHKOSH_USER_ID' }
    }
];

