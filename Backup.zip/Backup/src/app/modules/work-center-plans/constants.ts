
export const singleRackKey = 'singleRack';
export const rackBuilderKey = 'rack-builder';


export const orgId = 'ORG_ID';
export const itemId = 'ITEM_ID';
export const itemDesc = 'ITEM_DESC';
export const workCenter = 'TGT_WORK_CENTER_ID';
export const orientation = 'CONTAINER_ORIENTATION';
export const KSL = 'KIT_SPACE_LENGTH';
export const KSW = 'KIT_SPACE_WIDTH';
export const KSH = 'KIT_SPACE_HEIGHT';
export const kitId = 'MASTER_KIT_ID';
export const kitType = 'KIT_TYPE';
export const BPHQty = 'BAGS_PER_HOOK_QUANTITY';
export const bagQty = 'BAG_QUANTITY';
export const containerCode = 'CONTAINER_CODE';
export const lineSideQueue = 'LINE_SIDE_QUEUE_QTY';
export const MFP = 'MTRL_FLOW_PLAN_ID';
export const PID = 'PID';
export const taskId = 'TASK_ID';
export const plannedInWC = 'PLANNED_IN_WC';
export const stockingType = 'STOCKING_TYPE';
export const DNP = 'DO_NOT_PLAN';
export const HSH = 'HANDSTACK_SPACE_HEIGHT';
export const HSW = 'HANDSTACK_SPACE_WIDTH';
export const HSQty = 'HANDSTACK_SPACE_QUANTITY';
export const HSL = 'HANDSTACK_SPACE_LENGTH';
export const pickFacings = 'PICK_FACING_QNTY';
export const presentation = 'PresentationType';
export const itemPlanStatus = 'ItemPlanStatus';
export const expireDate = 'EXPIRE_DATE';
export const effectiveDate = 'EFFECTIVE_DATE';
export const itemPlanId = 'ITEM_PLAN_ID';
export const branch = 'FACILITY_ID';
export const executeCtr = 'Execute Container';
export const Archive = 'Archive';
export const workCenterId = 'WORK_CENTER_ID';
export const containerQty = 'CONTAINER_QTY';
export const HRPQ = 'HDS_REORDER_POINT_QTY';
export const HPQ = 'HDS_REORDER_QTY';

export const fromDate = 'EFFECTIVE_FROM_DATE';
export const toDate = 'EFFECTIVE_TO_DATE';

export const presentationTypeKey = 'PRESENTATION_TYPE';
export const itemPlanStatusKey = 'ITEM_PLAN_STATUS';
export const WCStorageID = 'WC_STORAGE_UNIT_ID';
export const WCStorageSID = 'WC_STORAGE_UNIT_SID';
export const workCenterPlansTableFields = [
  {
    field: itemId,
    type: 'text',
    order: 'sort',
    header: 'Part Number',
    sortField: itemId
  },
  { field: itemDesc, type: 'text', order: 'unsort', header: 'Description' },
  // {field:workCenter,order:"unsort",type:"text",header:"Work Center"},
  { field: branch, order: 'unsort', type: 'text', header: 'Branch' },
  {
    field: itemPlanId,
    type: 'link',
    header: 'Item Plan Id',
    order: 'unsort'
  },
  {
    field: effectiveDate,
    type: 'date',
    header: 'Effective Date',
    order: 'unsort'
  },
  { field: expireDate, type: 'date', header: 'Expire Date', order: 'unsort' },
  {
    field: itemPlanStatus,
    type: 'dropDown',
    header: 'Item Plan Status',
    ddField: itemPlanStatusKey,
    order: 'unsort'
  },
  {
    field: presentation,
    type: 'dropDown',
    header: 'Presentation Type',
    ddField: presentationTypeKey,
    order: 'unsort'
  },
  {
    field: WCStorageID,
    type: 'WcId',
    header: 'WC Rack ID',
    order: 'unsort'

  },
  {
    field: pickFacings,
    type: 'number',
    order: 'sort',
    header: 'Pick Facings',
    sortField: pickFacings
  },
  { field: orientation, type: 'text', header: 'Orientation', order: 'unsort' },
  {
    field: containerCode,
    type: 'text',
    header: 'POU Container',
    order: 'sort',
    sortField: containerCode
  },
  {
    field: containerQty,
    type: 'number',
    header: 'POU Container Qty.',
    order: 'unsort'
  },
  {
    field: lineSideQueue,
    type: 'number',
    order: 'sort',
    header: '# of Cards',
    sortField: lineSideQueue
  },
  { field: MFP, type: 'text', header: 'MFP', order: 'unsort', fullForm: 'Material Flow Plan' },
  { field: PID, type: 'decimal', header: 'PID', order: 'sort', sortField: PID, fullForm: 'Peak Interval Demand' },
  {
    field: taskId,
    type: 'text',
    header: 'TaskId',
    order: 'sort',
    sortField: taskId
  },
  {
    field: plannedInWC,
    type: 'number',
    header: 'Planned In Wc',
    order: 'unsort'
  },
  {
    field: stockingType,
    type: 'text',
    header: 'Stocking Type',
    order: 'unsort'
  },
  {
    field: DNP,
    type: 'checkbox',
    header: 'Do Not Plan',
    cbField: DNP,
    order: 'unsort'
  },
  {
    field: HSL,
    type: 'decimal',
    header: 'Handstack Space Length',
    order: 'unsort'
  },
  {
    field: HSW,
    type: 'decimal',
    header: 'Handstack Space Width',
    order: 'unsort'
  },
  {
    field: HSH,
    type: 'decimal',
    header: 'Handstack Space Height',
    order: 'unsort'
  },
  {
    field: HSQty,
    type: 'decimal',
    header: 'Handstack Space Quantity',
    order: 'unsort'
  },
  { field: HRPQ, type: 'number', header: 'Reorder Point', order: 'unsort' },
  { field: HPQ, type: 'decimal', header: 'Reorder Quantity', order: 'unsort' },
  { field: bagQty, type: 'number', header: 'Bag Quantity', order: 'unsort' },
  { field: BPHQty, type: 'number', header: 'Bags Per Loop', order: 'unsort' },
  { field: kitType, type: 'text', header: 'Kit Type', order: 'unsort' },
  { field: kitId, type: 'text', header: 'Master Kit Id', order: 'unsort' },
  { field: KSL, type: 'decimal', header: 'Kit Space Length', order: 'unsort' },
  { field: KSW, type: 'decimal', header: 'Kit Space Width', order: 'unsort' },
  { field: KSH, type: 'decimal', header: 'Kit Space Height', order: 'unsort' }
];

export const frozenColumns = [
  {
    field: itemId,
    type: 'text',
    order: 'sort',
    header: 'Part Number',
    sortField: itemId
  }, {
    field: itemPlanId,
    type: 'link',
    header: 'Item Plan Id',
    order: 'unsort'
  },
]

export const checkboxValues = {
  [DNP]: ['Y', 'N']
};

export const typeDropDowns = {
  [itemPlanStatus]: { field: itemPlanStatus, key: itemPlanStatusKey },
  [presentation]: { field: presentation, key: presentationTypeKey }
};

export const bulkSelectValue = 'Bulk';
export const binSelectValue = 'Bin';
const handStackSelectValue = 'Hand Stack';
const bagSelectValue = 'Bag';
export const kitSelectValue = 'Kit';
const callSelectValue = 'Call';

export const editableFieldsMap = {
  [binSelectValue]: [
    containerCode,
    MFP,
    lineSideQueue,
    containerQty,
    presentation,
    itemPlanStatus,
    executeCtr,
    effectiveDate,
    expireDate,
    pickFacings,
    MFP,
    plannedInWC,
    DNP
  ],
  [handStackSelectValue]: [
    HSQty,
    HSL,
    HSW,
    HSH,
    MFP,
    HRPQ,
    HPQ,
    presentation,
    itemPlanStatus,
    effectiveDate,
    expireDate,
    pickFacings,
    MFP,
    plannedInWC,
    DNP
  ],
  [bagSelectValue]: [
    bagQty,
    BPHQty,
    MFP,
    presentation,
    itemPlanStatus,
    effectiveDate,
    expireDate,
    pickFacings,
    MFP,
    plannedInWC,
    DNP
  ],
  [kitSelectValue]: [
    kitType,
    kitId,
    KSL,
    KSW,
    KSH,
    lineSideQueue,
    MFP,
    presentation,
    itemPlanStatus,
    effectiveDate,
    expireDate,
    pickFacings,
    MFP,
    plannedInWC,
    DNP
  ],
  [bulkSelectValue]: [
    lineSideQueue,
    MFP,
    containerCode,
    containerQty,
    presentation,
    itemPlanStatus,
    executeCtr,
    effectiveDate,
    expireDate,
    pickFacings,
    MFP,
    plannedInWC,
    DNP
  ],
  [callSelectValue]: [
    lineSideQueue,
    MFP,
    presentation,
    itemPlanStatus,
    effectiveDate,
    expireDate,
    pickFacings,
    MFP,
    plannedInWC,
    DNP
  ]
};

export const plsnStatusDisabledOpts = {
  PLANNING: ['ARCHIVED'],
  ARCHIVED: ['ACTIVE'],
  ACTIVE: []
};

export const allEditableFields = [
  containerCode,
  HSQty,
  HRPQ,
  HPQ,
  bagQty,
  BPHQty,
  kitType,
  kitId,
  lineSideQueue,
  containerQty
];

export const filters = [
  itemId,
  presentation,
  containerCode,
  MFP,
  taskId,
  stockingType,
  DNP
];

export const sortFields = {
  [itemId]: 0,
  [pickFacings]: 0,
  [containerCode]: 0,
  [lineSideQueue]: 0,
  [PID]: 0,
  [taskId]: 0
};

export const dateFields = [effectiveDate, expireDate];

export const saveSuccessMessage = 'Details saved successfully';

export const executeCtrTableAttrs = [
  itemId,
  branch,
  containerCode,
  presentation,
  pickFacings,
  PID
];

export const mandatoryFields = [itemPlanStatus, effectiveDate, expireDate, MFP];

export const presentationMandatoryFields = {
  [binSelectValue]: [containerCode, lineSideQueue, containerQty],
  [bulkSelectValue]: [containerCode, lineSideQueue, containerQty],
  [handStackSelectValue]: [HSQty, HSL, HSW, HSH, HRPQ, HPQ],
  [bagSelectValue]: [bagQty, BPHQty],
  [kitSelectValue]: [kitType, kitId, KSL, KSW, KSH, lineSideQueue],
  [callSelectValue]: [lineSideQueue]
};



// Copy Plans constants
export const supplyingLocation = 'SUPPLYING_LOCATION';
export const copyPlanSteps = [
  { label: 'Select Values', stepNumber: 0, icon: 'pi pi-list' },
  { label: 'Preview', stepNumber: 1, icon: 'pi pi-sitemap' },
  { label: 'Created Plans', stepNumber: 2, icon: 'pi pi-info' }
]
export const valuesScreenFieldsList = [
  { field: branch, header: 'Branch', valueField: branch },
  { field: workCenterId, header: 'Work Center', valueField: workCenterId },
  { field: supplyingLocation, header: 'Supplying Location', 'useExisting': true, valueField: supplyingLocation },
  { field: MFP, header: 'MFP', valueField: 'MFP_DESC', fullForm: 'Material Flow Plan' },
  { field: effectiveDate, type: 'date', header: 'Effective Date' }
];
export const previewScreenTableColumns = [
  { field: itemId, header: 'Part Number' },
  { field: itemDesc, header: 'Description' },
  { field: branch, header: 'Branch' },
  { field: workCenterId, header: 'Work Center' },
  { field: supplyingLocation, header: 'Supplying Location' },
  { field: MFP, header: 'MFP', fullForm: 'Material Flow Plan' },
  { field: effectiveDate, header: 'Effective Date' }
];
export const resultScreenTableColumns = [
  { field: itemId, header: 'Part Number' },
  { field: itemDesc, header: 'Description' },
  { field: itemPlanId, type: 'link', header: 'Item Plan Id' },
  { field: branch, header: 'Branch' },
  { field: workCenterId, header: 'Work Center', type: 'link' },
  { field: supplyingLocation, header: 'Supplying Location' },
  { field: 'StatusType', header: 'Status' }
];

export const valuesScreenDependency = {
  workCenterId: branch,
  MFP: branch
}

