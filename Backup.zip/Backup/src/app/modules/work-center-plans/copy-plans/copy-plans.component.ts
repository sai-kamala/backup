import { Component, OnInit, Input, OnChanges, ViewEncapsulation } from '@angular/core';
import * as constants from '../constants';
import { WorkCenterService } from '../work-center-plans.service';
import { CoreServices } from 'src/app/core/services/core.service';

@Component({
  selector: 'pfep-copy-plans',
  templateUrl: './copy-plans.component.html',
  styleUrls: ['./copy-plans.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CopyPlansComponent implements OnInit, OnChanges {

  @Input() rowData = [];
  @Input() copyCancelledFn: Function;
  @Input() workCenterInCopyPlansFn: Function;
  @Input() itemPlanIdInCopyPlansFn: Function;

  stepsCompleted: any = { 0: false, 1: false, 2: false };
  currentStep: number = 0;
  selectedValues: any = { [constants.branch]: '', [constants.workCenterId]: '', [constants.supplyingLocation]: '', [constants.MFP]: '', [constants.effectiveDate]: '' }
  copyPlanSteps = constants.copyPlanSteps;
  valuesScreenFieldsList = constants.valuesScreenFieldsList;
  previewScreenTableColumns = constants.previewScreenTableColumns;
  resultScreenTableColumns = constants.resultScreenTableColumns;
  dropDownValues: any = { [constants.branch]: [], [constants.workCenterId]: [], [constants.supplyingLocation]: [], [constants.MFP]: [], [constants.effectiveDate]: '' };
  supplyingLocationChecked = [];
  previewTableData = [];
  copiedPlansData = [];
  differingMFPsPresent = false;

  constructor(public workCenterService: WorkCenterService, public coreService: CoreServices) { }

  ngOnInit() {
    this.getAllDDValues();
  }

  ngOnChanges(changes) {

    if (changes.rowData) {
      if ((!changes.rowData.previousValue || changes.rowData.previousValue.length === 0) && changes.rowData.currentValue.length > 0) {
        this.getAllDDValues();
        this.emptySelectedValues();
        return;
      }

      if (changes.rowData.previousValue && changes.rowData.previousValue[0][constants.branch] !== changes.rowData.currentValue[0][constants.branch]) {
        this.getAllDDValues();
        this.emptySelectedValues();
      }
    }
  }

  emptySelectedValues = () => {
    this.selectedValues = { [constants.branch]: '', [constants.workCenterId]: '', [constants.supplyingLocation]: '', [constants.MFP]: '', [constants.effectiveDate]: '' }
  }

  stepChanged = e => {
  }

  changeStep = step => {
    if (this.currentStep > step.stepNumber) {
      for (let i = 0; i <= this.currentStep; i++) {
        this.stepsCompleted[i] = false;
      }
    }
    this.currentStep = step.stepNumber;

  }

  ddChanged = (e, field) => {
    switch (field) {
      case constants.branch:
        this.getWorkCenters(e.target.value);
        this.getMFPValues(e.target.value);
    }

    this.selectedValues[field] = e.target.value;
  }

  checkBoxChecked = (checked, field) => {
    if (field === constants.supplyingLocation) {
      if (checked) { this.selectedValues[field] = this.rowData[0][field] };
      if (!checked) {
        this.supplyingLocationChecked = [];
      }
    }
  }

  checkForDisable = field => {
    if (field === constants.supplyingLocation && this.supplyingLocationChecked.indexOf('supplyingLocation') > -1) {
      return true;
    }
    return false;
  }

  checkStepDisabled = step => {
    if (this.stepsCompleted[this.copyPlanSteps.length - 1] && step.stepNumber !== this.copyPlanSteps.length - 1) {
      return true;
    }
    let disable = false;
    for (let stepNum in this.stepsCompleted) {
      if (Number(stepNum) < step.stepNumber && !disable && !this.stepsCompleted[stepNum]) {
        disable = true;
      }
    }
    return disable;
  }

  checkValuesStepValidity = () => {
    let valid = true;
    for (const field in this.selectedValues) {
      if (this.isEmpty(this.selectedValues[field]) && valid) {
        valid = false;
      }
    }

    return !valid;
  }

  showPreviewStep = () => {
    this.buildPreviewTableValues();
    this.stepsCompleted[this.currentStep] = true;
    this.currentStep = this.currentStep + 1;
  }

  buildPreviewTableValues = () => {
    this.checkForDifferingMFPs();
    this.previewTableData = this.rowData.map(row => {
      constants.valuesScreenFieldsList.forEach(value => {
        row[value.field] = this.selectedValues[value.field]
      });

      return row;
    });

  }

  checkForDifferingMFPs = () => {
    this.differingMFPsPresent = false;
    const mfpToCompare = this.rowData[0][constants.MFP];
    const idx = this.rowData.findIndex(row => row[constants.MFP] !== mfpToCompare);
    if (idx > -1 && this.rowData.length > 1) {
      this.differingMFPsPresent = true;
    }
  }

  changeValues = () => {
    this.stepsCompleted[this.currentStep] = false;
    this.stepsCompleted[this.currentStep - 1] = false;
    this.currentStep = this.currentStep - 1;
  }

  executeCopy = () => {
    this.coreService.showLoader();
    const postData = { ...this.selectedValues, 'CopyItemPlan': this.rowData };
    this.workCenterService.copyItemPlans(postData).subscribe((res: any) => {
      this.copiedPlansData = [...res];
      this.currentStep = this.currentStep + 1;
      this.stepsCompleted[this.currentStep] = true;
      this.coreService.hideLoader();
    })
    /* this.copiedPlansData = this.workCenterService.copyItemPlans(postData);
    this.coreService.hideLoader();
    this.currentStep = this.currentStep + 1;
    this.stepsCompleted[this.currentStep] = true; */
  }

  linkClicked = (e, field, rowData) => {
    e.preventDefault();
    field === constants.workCenterId
      ? this.workCenterInCopyPlansFn(rowData[constants.workCenterId])
      : this.itemPlanIdInCopyPlansFn({
        itemPlanRequest: {
          planIdFromParent: rowData[constants.itemPlanId],
          parentScreenPath: '/work-center-plans',
          isChild: true,
          selectedRecord: rowData
        }
      });
  }


  copyCancelled = e => {
    e.preventDefault();
    this.supplyingLocationChecked = [];
    this.emptySelectedValues();
    this.previewTableData = [];
    this.copyCancelledFn();
  }

  getAllDDValues = () => {
    if (this.rowData.length > 0) {
      const branch = this.rowData[0][constants.branch];
      this.coreService.showLoader();
      this.workCenterService.getAllDDValues(branch).subscribe(res => {
        this.coreService.hideLoader();
        this.parseAllDDValues(res);
      });
      /* this.coreService.hideLoader();
      this.parseAllDDValues(this.workCenterService.getAllDDValues(branch)); */
    }
  }

  parseAllDDValues = res => {
    const resMap = {
      'BRANCHES': constants.branch,
      'WORKCENTERS': constants.workCenterId,
      'SUPPLYING_LOCATIONS': constants.supplyingLocation,
      'MATERIAL_FLOW_PLANS': constants.MFP
    };

    for (const field in resMap) {
      this.dropDownValues[resMap[field]] = res[field];
    }

  }

  getBranchList = () => {
    this.coreService.showLoader();
    this.workCenterService.getFacilities().subscribe(branchList => {
      this.dropDownValues[constants.branch] = branchList;
      this.coreService.hideLoader();
    });
    /* this.dropDownValues[constants.branch] = this.workCenterService.getFacilities();
    this.coreService.hideLoader(); */
  }


  getWorkCenters = branch => {
    this.coreService.showLoader();
    this.workCenterService.getWorkCenterList(branch).subscribe(workCenterList => {
      this.dropDownValues[constants.workCenterId] = workCenterList;
      this.coreService.hideLoader();
    });
    /* this.dropDownValues[constants.workCenterId] = this.workCenterService.getWorkCenterList(branch);
    this.coreService.hideLoader(); */

  };

  getSupplierLocationList = () => {
    this.coreService.showLoader();
    this.workCenterService.getSupplierLocationList().subscribe(supplyingLocationList => {
      this.dropDownValues[constants.supplyingLocation] = supplyingLocationList;
      this.coreService.hideLoader();
    });
    /* this.dropDownValues[constants.supplyingLocation] = this.workCenterService.getSupplierLocationList();
    this.coreService.hideLoader(); */

  };

  getMFPValues = branch => {
    this.coreService.showLoader();
    this.workCenterService.getMFPList(branch).subscribe(MFPList => {
      this.dropDownValues[constants.MFP] = MFPList;
      this.coreService.hideLoader();
    });
    /* this.dropDownValues[constants.MFP] = this.workCenterService.getMFPList(branch);
    this.coreService.hideLoader(); */

  };

  isEmpty = value => {
    if (value.trim() !== '' && value !== null && value !== undefined) {
      return false;
    }

    return true;
  }

}
