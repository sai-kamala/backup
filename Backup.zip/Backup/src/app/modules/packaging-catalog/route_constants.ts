// route constants
export const baseScreenPath = "catalog";
export const createNewScreenPath = 'catalog-detail';