import { Component, OnInit, Output, EventEmitter,ViewChild} from '@angular/core';
import * as constant from '../constants';
import { AdministrativeService } from '../administrator.service';
import { CoreServices } from '../../../core/services/core.service';
import { SharedService } from './../../../shared/services/share.service';
import { Paginator } from 'primeng/paginator';

@Component({
  selector: 'pfep-escalation-days',
  templateUrl: './escalation-days.component.html',
  styleUrls: ['./escalation-days.component.scss']
})
export class EscalationDaysComponent implements OnInit {

  constructor(public adminService: AdministrativeService, public coreService: CoreServices,public sharedService: SharedService) { }
  @Output() isEdited = new EventEmitter<any>();
  esaclationTblColumns: any;
  escalationTblData:Array<any> = [];
  first: number;
  disableSave:boolean = true;
  rowsPerPage = 10;
  page = 1;
  recordsToDisplay: any = [];
  stopPageChangeEvent: boolean = false;
  recordsString: string = '';
  index;
  
  @ViewChild(Paginator) paginator: Paginator;
  
ngOnInit() {
    this.esaclationTblColumns = constant.escalationTblcolumns;
    this.getEscalationDays();
    this.first = 0;
   
  }

  getEscalationDays() {
    this.coreService.showLoader();
    this.adminService.getAllEscalationDays().subscribe(response => {
      if(response['StatusType'] == 'SUCCESS') {
      this.escalationTblData = response['MFCREscalationDay'];
      this.determineRowsAndPage();
      } else {
        this.adminService.displayMessage('error',response['Message'])
      }
     this.coreService.hideLoader();
    })
  }

  editRow(index,rowdata) {
    this.escalationTblData.forEach((res, idx )=> {
      if(res.FACILITY_ID == rowdata['FACILITY_ID']) {
        this.escalationTblData[idx]['isEdit'] = true;
      }
    })
    this.disableSave = false;
    this.valueChangeConfirmation(true);
  }

  valueChangeConfirmation(bol) {
    this.isEdited.emit(bol);
  }

  cellClikedToEdit = (e, col, rowData) => {
    if (!col.isEdit || e.srcElement.className.includes('form-control')) {
      e.stopPropagation();
      return;
    }
    this.valueChangeConfirmation(true);
  }

  pageChanged(e) {
    this.first = e.first;
    if(!this.stopPageChangeEvent) {
     
      this.page = e.page + 1;

      if(this.rowsPerPage !== e.rows) {
        this.page = 1;
        this.resetToFirstPage();
      }

      this.rowsPerPage = e.rows;
      this.determineRowsAndPage();
    }

  }

  determineRowsAndPage = () => {
    if(this.escalationTblData.length > 0) {
      const startIndex = ((this.page - 1) * this.rowsPerPage);
      const endIndex = (this.page * this.rowsPerPage) - 1;
      this.recordsToDisplay = this.escalationTblData.slice(startIndex, endIndex + 1);
    } else {
      this.page = 1;
      this.rowsPerPage = 10;
      this.recordsToDisplay = [];
    }
    const totalPages = Math.ceil(this.escalationTblData.length/ this.rowsPerPage);
    this.recordsString = this.sharedService.buildTotalRecordsString(
                              typeof totalPages === 'number'
                              ? totalPages : 0,
                              this.escalationTblData.length,
                              this.rowsPerPage, this.page
                          );
  }

   //getting the index of a row in displayRows when page CHnage is triggered
   getPageRowIndexOnPageChange = event => {
    const idx = this.index - ((event.page) * event.rows);
    return idx < event.rows ? idx : -1;
  }
  // getting the index of a row in displayRows using the rows index in total rows
  getPageRowIndex = () => {
   const idx =  this.index - ((this.page - 1) * this.rowsPerPage);
   return idx < this.rowsPerPage ? idx : -1;
  }
  // getting the index of a row in total rows using the rows index in page rows
  getOverallRowIndex = pageRowIdx => ((this.page - 1) * this.rowsPerPage) + pageRowIdx;

  resetToFirstPage = () => {
    this.stopPageChangeEvent = true;
    this.paginator.changePage(0);
    this.stopPageChangeEvent = false;
  }

  saveChanges() {
   
    const editedArray = {};
    editedArray['MFCREscalationDay'] = [];
    editedArray['MFCREscalationDay']= this.escalationTblData.filter(val => { return val.isEdit});
    if(editedArray['MFCREscalationDay'].length != 0) {
      this.coreService.showLoader();
      this.adminService.saveEscalationDays(editedArray).subscribe(res => {
        if(res['StatusType'] === 'SUCCESS') {
          this.adminService.displayMessage('success',
          res['Message']);
          this.getEscalationDays();
          this.escalationTblData.forEach(data => {
            if(data.isEdit) {
              delete data.isEdit;
            }
          });
          this.disableSave = true;
          this.valueChangeConfirmation(false);
          
        } else {
          this.adminService.displayMessage('error',
          res['Message'])
        }
      });
      this.coreService.hideLoader();
    }
  }

}
