import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
// import { HttpClient } from 'selenium-webdriver/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PackagingCatalogService } from './packaging-catalog.service';
import tableConstants from './packaging_catalog';
import { CoreServices } from 'src/app/core/services/core.service';

@Component({
  selector: 'pfep-packaging-catalog',
  templateUrl: './packaging-catalog.component.html',
  styleUrls: ['./packaging-catalog.component.scss']
})
export class PackagingCatalogComponent implements OnInit {
  // @Input() rowSelectedData
  // @ViewChild(DataTableDirective)
  // public datatableElement : DataTableDirective;
  ORG_ID: any[];
  containerCategory: any[];
  containerUsageCategory: any[];
  selectedCategory = null;
  loadComponent = false;
  value: any;
  searchData: any;
  searchTableData: any;
  tableSearchData: any[] = [];
  pc_form: FormGroup;
  pc_containerCode = '';
  pc_containerCategory = '';
  pc_description = '';
  pc_supplier = '';
  pc_innerHeight = '';
  pc_innerLength = '';
  pc_innerWidth = '';
  pc_weight = '';
  pc_OuterHeight = '';
  pc_outerLength = '';
  pc_outerWidth = '';
  pc_Dimension = '';
  dataTable: any;
  data: any;
  formSearch: any;
  e1: any;
  tableFields: any = tableConstants['tableKeyFields'];
  searchCrieteriaEmpty: Boolean = false;
  isEditable: Boolean = false;
  containerUOMDDValues: Array<object> = [];
  orgIdValues: Array<object> = [];
  private regex: RegExp = new RegExp(/^[0-9]+(\.[0-9]*){0,1}$/g);
  isDisabled = true;

  constructor(private packagingCatalogService: PackagingCatalogService,
    private fb: FormBuilder, private change: ChangeDetectorRef, private router: Router,
    private toastr: ToastrService, private coreServices: CoreServices,
    private route: ActivatedRoute
  ) {
    this.pc_form = fb.group({
      'ORG_ID': [null, false],
      'container_code': [null, false],
      'container_category': [null, false],
      'conatiner_usage_type': [null, false],
      'container_desc': [null, false],
      'container_supplier': [null, false],
      'container_in_height': [null, false],
      'container_in_lenght': [null, false],
      'container_in_width': [null, false],
      'empty_container_weight': [null, false],
      'container_out_height': [null, false],
      'container_out_lenght': [null, false],
      'container_out_width': [null, false],
      'SearchTolerance': [null, false],
      'CONTAINER_UOM': [null, false]
    });
  }

  ngOnInit() {
    const routeRoles = this.route.snapshot.data.roles;
    this.isEditable = this.coreServices.checkAccess(routeRoles);
    this.getAllDropDownOptions();
  }

  onChangeCategory(event): void {
    this.selectedCategory = event;
    this.change.detectChanges();
  }

  onSearchDataGrid(data) {
    this.searchData = data;
  }

  onlyNumber(event: any) {
    const charCode = (event.which) ? event.which : event.keyCode;
    const decimals = event.target;
    const value: any = $(decimals).val();
    const keyValue: any = event.key;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      if (value.indexOf('.') !== -1) {
        return false;
      }
    }
    return true;
  }


  loadPackagingDetails() {
    this.router.navigate(['catalog/catalog-detail']);
  }

  getAllDropDownOptions() {
    this.packagingCatalogService
      .getContainerCategory().subscribe(data => {
        this.containerCategory = data.map(val => {
          const { CONTAINER_CATEGORY } = val;
          return {
            CONTAINER_CATEGORY,
            value: CONTAINER_CATEGORY
          };
        });
        this.containerCategory.unshift({ CONTAINER_CATEGORY: 'Select One', value: null });
      });

    this.packagingCatalogService.getContainerUsageType().subscribe(data => {
      this.containerUsageCategory = data.map(val => {
        console.log(val);
        const {  CONTAINER_USAGE_TYPE } = val;
        return {
          CONTAINER_USAGE_TYPE,
          value: CONTAINER_USAGE_TYPE
        };
      });
      this.containerUsageCategory.unshift({CONTAINER_USAGE_TYPE: 'Select One', value: null});
    });

      this.packagingCatalogService
        .getContaienrUOMList().subscribe(data => {
          this.containerUOMDDValues = [...data];
        });

      this.packagingCatalogService.getSegmentsByUserId().subscribe(data => {
        this.orgIdValues = data;
      });
  }

  getExistingContainer() {
    const data = this.pc_form.value;
    this.loadComponent = true;
    this.searchCrieteriaEmpty = (Object.values(data).every(val => val === null)) ? true : false;
    if (!this.searchCrieteriaEmpty) {
      if (data['container_code'] !== null && data['container_code'] !== undefined) {
        data['container_code'] = data['container_code'].toUpperCase();
      }
      this.formSearch = data;
      this.loadContainerTableData(this.formSearch);
    } else {
      this.displayMessage('danger', 'Please enter search item.');
    }

  }

  loadContainerTableData(searchData) {
    if (searchData) {
      this.packagingCatalogService.getContainerListBasedOnSearch(searchData).subscribe((data: any[]) => {
        this.searchTableData = data;
      });
    }
  }

  changeToDecimal = formName => {
    const ipValue = this.pc_form.get(formName).value;
    if (ipValue !== '' && typeof (ipValue) === 'number') {
      this.pc_form.get(formName).setValue(parseFloat(ipValue.toString()).toFixed(3));
    }
  }

  validateNumber(controlName, event) {
    if (event.target.value === '.') {
      this.pc_form.controls[controlName].setValue(null);
      event.target.value = '';
    }
  }

  displayMessage(type = 'danger', message = 'Unknown Error occured. Please try again.') {
    type === 'danger' ? this.toastr.error(message) : this.toastr.success(message, '', { disableTimeOut: false });
  }

}
