import {
  Component,
  OnInit,
  OnChanges,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation
} from '@angular/core';

class searchFieldOption {
  displayValue: any;
  value: string;
}

@Component({
  selector: 'pfep-search-field',
  templateUrl: './search-field.component.html',
  styleUrls: ['./search-field.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SearchFieldComponent implements OnInit, OnChanges {
  @Input() key: string;
  @Input() options: Array<searchFieldOption>;
  @Input() selectedValue: string;
  @Input() isDisabled = false;
  @Input() model: any;
  @Input() className = '';
  @Input() invalidValue = false;
  @Input() appendTo: any = null;
  @Output() searchClicked = new EventEmitter();
  @Output() optionSelected = new EventEmitter();
  @Output() typing = new EventEmitter();
  @Output() ipEmptied = new EventEmitter();
  @Output() ipBlurred = new EventEmitter();

  valueToDisplay: any = { value: this.model };
  debounceTime = 1500;
  valueSet = 'unset';

  constructor() {}

  ngOnInit() {
    this.valueToDisplay = { value: this.model };
  }
  ngOnChanges(changes) {
    if (changes.model) {
      this.valueToDisplay = { value: changes.model.currentValue };
    }
  }

  inputBlurred = () => {
    setTimeout(() => {
      this.ipBlurred.emit(this.valueSet);
    }, 200);
  }
  getResults = event => this.searchClicked.emit(event.query);
  onSelect = event => {
    this.optionSelected.emit(event.value);
    this.valueSet = 'set';
    this.selectedValue = event.value;
  }
  inputChanged = value => {
    this.typing.emit();
    this.valueSet = 'unset';
    if (typeof value === 'string' && value.trim() === '') {
      this.optionSelected.emit(value);
      this.valueSet = '';
      this.selectedValue = '';
      this.ipEmptied.emit();
    }
  }
}
