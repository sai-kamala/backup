export const environment = {
    production: true,
    api: 'https://entpfepq01/pfepsitservice/api/',
    authUser: 'https://entpfepq01/pfepsitservice/api/User/Get',
    authToken: 'https://entpfepq01/pfepsitservice/Token'
  };
