export default {
  tableKeyFields: [
    { field: 'ORG_ID', header: 'Segment' },
    { field: 'CONTAINER_CODE', header: 'Container Code' },
    { field: 'CONTAINER_CATEGORY', header: 'Container Category' },
    { field: 'CONTAINER_USAGE_TYPE',header:'Container Usage Type'},
    { field: 'CONTAINER_DESC', header: 'Container Description' },
    { field: 'CONTAINER_SUPPLIER', header: 'Container Supplier' },
    { field: 'CONTAINER_IN_LENGHT', header: 'Inner Length' },
    { field: 'CONTAINER_IN_WIDTH', header: 'Inner Width' },
    { field: 'CONTAINER_IN_HEIGHT', header: 'Inner Height' },
    { field: 'CONTAINER_OUT_LENGHT', header: 'Outer Length' },
    { field: 'CONTAINER_OUT_WIDTH', header: 'Outer Width' },
    { field: 'CONTAINER_OUT_HEIGHT', header: 'Outer Height' },
   // { field: 'EMPTY_CONTAINER_WEIGHT', header: 'Weight' }
  ]
};
