import { NgModule } from '@angular/core';
import { Routes, RouterModule, provideRoutes } from '@angular/router';
import { PackagingCatalogComponent } from './packaging-catalog.component';
import { EditPackagingCatalogDetailsComponent } from './edit-packaging-catalog-details/edit-packaging-catalog-details.component';
import { BillOfMaterialsComponent } from './bill-of-materials/bill-of-materials.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { AuthGuard } from 'src/app/core/guards/auth-guard';
import { CanDeactivateGuard } from 'src/app/core/guards/can-deactivate-guard';


const catalogRoutes: Routes = [
  { path: '', component: PackagingCatalogComponent, data: { roles: ['PACKAGING ENGINEER'] }, canActivate: [AuthGuard] },
  { path: 'catalog-detail', component: EditPackagingCatalogDetailsComponent, data: { roles: ['PACKAGING ENGINEER'] }, canActivate: [AuthGuard], canDeactivate: [CanDeactivateGuard] },
  { path: 'edit-detail', component: EditPackagingCatalogDetailsComponent, data: { containerID: null, roles: ['PACKAGING ENGINEER'] }, canActivate: [AuthGuard], canDeactivate: [CanDeactivateGuard] },
  { path: 'edit-detail/bom', component: BillOfMaterialsComponent, data: { routeData: null, roles: ['PACKAGING ENGINEER'] }, canActivate: [AuthGuard], canDeactivate: [CanDeactivateGuard] }];

@NgModule({
  imports: [RouterModule.forChild(catalogRoutes), ReactiveFormsModule, BsDatepickerModule.forRoot()],
  exports: [RouterModule, FormsModule]
})
export class PackagingCatalogRoutingModule {
  constructor() {
    console.log('packaing catalog module');
  }


}
