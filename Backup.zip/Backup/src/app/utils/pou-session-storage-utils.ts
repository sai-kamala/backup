class CommunicationObject {
  openRecords: Array<string>;
  openRecData: object;
  activeTabs: Array<string>;
  shouldPoll: boolean;
  editedRecData: object;
  savedRecords: Array<string>;
}

const pouPackagingCalcComm = 'pouPackagingCalcComm';
const openRecords = 'openRecords';
const openRecData = 'openRecData';
const activeTabs = 'activeTabs';
const shouldPoll = 'shouldPoll';
const savedRecData = 'editedRecData';
const savedRecords = 'savedRecords';
const itemId = 'ITEM_ID';
const itemPlanId = 'ITEM_PLAN_ID';
const arrayDelimiter = '|';
// let commObjCache: CommunicationObject = {
//     [openRecords]: [],
//     [openRecData]: {},
//     [activeTabs]: [],
//     [shouldPoll]: true,
//     [savedRecData]: {},
//     [savedRecords]: []
//   };

const buildRecId = rec => `${rec[itemId] + rec[itemPlanId]}`;
const buildCommObject = rec => {
  const recKey = buildRecId(rec);
  return {
    [openRecords]: [recKey],
    [openRecData]: { [recKey]: rec },
    [activeTabs]: [recKey],
    [shouldPoll]: true,
    [savedRecData]: {},
    [savedRecords]: []
  };
};

const createSessionStorageObj = rec => {
  const commObj = JSON.stringify(buildCommObject(rec));
  sessionStorage.setItem(pouPackagingCalcComm, commObj);
};
const setItemToStorage = (key, data) => {};
const getStorageData = () =>
  Object.assign({}, JSON.parse(sessionStorage.getItem(pouPackagingCalcComm)));
const setStorageData = commObj =>
  sessionStorage.setItem(pouPackagingCalcComm, JSON.stringify({...commObj}));
const addRecToStore = (key, rec, commObj) => {
  let recData = commObj[key];
  recData = { ...recData, [buildRecId(rec)]: rec };
  commObj[key] = recData;
  return commObj;
};
const addIdsToStorage = (key, rec, commObj) => {
  const id = buildRecId(rec);
  commObj[key].push(id);
  return commObj;
};
const getIdsFromStorage = key => [...getStorageData()[key]];
const setShouldPollValue = (commObj) => {
    commObj.shouldPoll = false;
  if (
    commObj[openRecords].length > 0 ||
    commObj[savedRecords].length > 0
  ) {
    commObj.shouldPoll = true;
  }
  return commObj;
};
const recOpened = rec => {
  let commObjCache = getStorageData();
  commObjCache = addIdsToStorage(openRecords, rec, commObjCache);
  commObjCache = addRecToStore(openRecData, rec, commObjCache);
  commObjCache = setShouldPollValue(commObjCache);
  setStorageData(commObjCache);
};
