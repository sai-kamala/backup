export const environment = {
  production: true,
  api: 'https://entpfepd01/PFEPService/api/',
  authUser: 'https://entpfepd01/PFEPService/api/User/Get',
  authToken: 'https://entpfepd01/PFEPService/Token'
};
