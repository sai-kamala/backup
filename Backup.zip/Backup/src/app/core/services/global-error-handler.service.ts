import { Injectable, ErrorHandler, NgZone, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { LoggingService } from './logging.service';
import { CoreServices } from './core.service';

@Injectable()
export class GlobalErrorHandlerService implements ErrorHandler {
  constructor(private ngZone: NgZone, private toastr: ToastrService, private injector: Injector, private coreService: CoreServices) { }

  handleError(error: any) {
    const logger = this.injector.get(LoggingService);
    if (error instanceof HttpErrorResponse) {
      // Backend returns unsuccessful response codes such as 404, 500 etc.
      console.error('Backend returned status code: ', error.status);
      console.error('Response body:', error.message);
      //   alert(error.message);
      this.displayToaster(error.message);
    } else {
      // A client-side or network error occurred.
      console.error('An error occurred:', error.message);
      // this.displayToaster('An error occurred');
    }
    logger.logError(error.message);
  }

  displayToaster(error) {
    this.ngZone.run(() => {
      this.coreService.hideLoader();
      this.toastr.error(error);
    });


  }
}
