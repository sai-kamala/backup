

  export const formatDate = (date) => {
    if (date !== null && date !== undefined && date !== '') {
      let d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

      if (month.length < 2) { month = '0' + month; }
      if (day.length < 2) { day = '0' + day; }

      return [year, month, day].join('-');
    } else {
      return '';
    }
  };

  export const setFromDate = (date) => {
    const d = new Date(date);
    d.setDate(d.getDate() - 56);
    console.log(d);
    return d;
  };

  export const setFutureDate = (): any => {
      const d = new Date() ;
      d.setFullYear(d.getFullYear() + 1);
      console.log(d);
      return d;
  };

  export const getDateLimit = (limitType, d) => {
    const date = new Date(d);
    const offSetDate = limitType === 'toDate' ? 1 : -1;
    date.setDate(date.getDate() + offSetDate);
    return date;
  };
