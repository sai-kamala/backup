import * as XLSX from 'xlsx';

export const exportToExcel = (data, name, header) => {
  if (!data || data.length === 0) {return; }
    const workBook = XLSX.utils.book_new();

    function buildWorkSheet(dataToExport, sheetName) {
        const workSheet = header ? XLSX.utils.json_to_sheet(dataToExport, { header }) : XLSX.utils.json_to_sheet(dataToExport);
        XLSX.utils.book_append_sheet(workBook, workSheet, sheetName);
    }

    if (Array.isArray(data)) {
        buildWorkSheet(data, name);
    } else if (data.constructor === Object) {
        Object.keys(data).forEach(sheet => {
            buildWorkSheet(data[sheet], sheet);
        });
    }

    XLSX.writeFile(workBook, name);
};

export const buildExportData = (dataToExport, tableColumns, headerKey, valueKey, droDownAPIKey) => {
    if (!dataToExport || dataToExport.length === 0) {return; }
    function getTotalColumns() {
      let totalColumns = tableColumns.columns ? [...tableColumns.columns] : [...tableColumns];
      const dropDownColumns = {};
      if (tableColumns.groupedColumns && Object.keys(tableColumns.groupedColumns).length > 0) {
        Object.keys(tableColumns.groupedColumns).forEach(col => {
          totalColumns = [...totalColumns, ...tableColumns.groupedColumns[col]];
        });
      }

      const headerKeymap = {};
      totalColumns.forEach(col => {
        let key = col[valueKey];
        if (col.type === 'dropDown') {
          key = col[droDownAPIKey] ? col[droDownAPIKey] : col[valueKey];
          dropDownColumns[col[droDownAPIKey]] = {ddKey: col[valueKey]};
        }
        headerKeymap[key] = `${col['group'] ? col['group'] + ' ' : ''}` + col[headerKey] ;
      });

      return { headerKeymap, dropDownColumns };
    }

    function getDDValue(arr, key) {
      const values = arr.filter(ele => ele.IsSelected === true);
      return values.length > 0 ? values[0][key] : '';
    }


    const $dataToAlter = dataToExport;
    const tableKeys = Object.keys($dataToAlter[0]);
    return $dataToAlter.map(rec => {
      const alteredRecord = {};
      const { headerKeymap, dropDownColumns } = getTotalColumns();
      tableKeys.forEach(key  => {
        const value = (Array.isArray(rec[key])) ? getDDValue(rec[key], dropDownColumns[key]['ddKey']) : rec[key];
        if (headerKeymap[key]) { Object.assign(alteredRecord, {[headerKeymap[key]]: value }); }
      });
      return alteredRecord;
    });
  };

