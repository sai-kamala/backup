import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { mergeMap, map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/x-www-form-urlencoded'
  })
};

@Injectable()
export class AuthService {
  private baseUrl: string = environment.api;
  private authData: any;
  private userData: any;
  timerFlag = false;
  constructor(private http: HttpClient) { }

  load(): Promise<any> {
    this.authData = null;
    return this.http
      .get(environment.authUser)
      .pipe(
        mergeMap(userData =>
          //this.http.post(environment.authToken, this.constructTokenObj(userData), httpOptions)
          this.http.get(environment.authToken, httpOptions)
        )
      )

      .toPromise()
      .then((data: any) => {
        if (data !== undefined) {
          this.authData = data;
          this.timerFlag === false ? this.timerTokenCall() : null;
          localStorage.setItem('currentUser', JSON.stringify(this.authData));
        } else {
          this.authData = null;
          localStorage.clear();
        }

      })
      .catch((err: any) => Promise.resolve());
  }

  constructTokenObj(userData) {
    const body = `username=${userData}&grant_type=password`;
    return body;
  }
  get userAuthData(): any {
    return this.authData;
  }

  timerTokenCall() {
    this.timerFlag = true;
    const interval = (this.authData.expires_in - 10) * 1000;
    setInterval(() => {
      this.load();
    }, interval);
  }
}
