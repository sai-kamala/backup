import { Component, OnInit, Input, ViewChild, Injector, ViewEncapsulation } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { PackagingCatalogService } from '../packaging-catalog.service';
import { DatePipe } from '@angular/common';
import { FileUploadService } from '../file-upload.service';
import { Location } from '@angular/common';
import formConstants from './constants';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BomService } from './../bill-of-materials/bom.service';
import { createNewScreenPath, baseScreenPath } from '../route_constants';
import { CoreServices } from 'src/app/core/services/core.service';
import { DISABLED } from '@angular/forms/src/model';
import constants from './constants';
import { toBase64String } from '@angular/compiler/src/output/source_map';
import { ConfirmationService } from 'primeng/api';
import { ModalService } from 'src/app/core/services/modal.service';
import { NavBarComponent } from 'src/app/core/header/nav-bar/nav-bar.component';
import { SharedService } from 'src/app/shared/services/share.service';

@Component({
  selector: 'app-edit-packaging-catalog-details',
  templateUrl: './edit-packaging-catalog-details.component.html',
  styleUrls: ['./edit-packaging-catalog-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EditPackagingCatalogDetailsComponent implements OnInit {
  pc_details: any = {};
  segmentValues: any = [];
  containerId: any;
  successData: any = null;
  customContainerStatus: boolean;
  details: any = {};
  lists: any;
  isDisable = true;
  StackableFlag: any[];
  CustomContainerInd: any[];
  IITRequiredInd: any[];
  FlowRackInd: any[];
  PrimaryOrinentInd: any[];
  Organization: any[];
  InternalUse: any[];
  ContainerCategory: any[];
  detailsUpdated = false;
  imgUploaded = false;
  bgImgPath: any = '';
  selectedOrganization: any;
  custom = { ITEM_ID: null, CUSTOM_PACK_QTY: null, add: true, Item_Required: false, Custom_Required: false };
  imgPath: any;
  isNew = true;
  selectValues: Array<string> = Object.keys(formConstants.dropDownObjAPIValues);
  dropDownObjAPIValues = formConstants.dropDownObjAPIValues;
  updateClicked: Boolean = false;
  files: any;
  formData = new FormData();
  fileArray: any[] = [];
  uploadedFiles = [];
  CustContainer = [];
  showUploadedFiles = false;
  isFormValid = false;
  isEditable = false;
  ORG_ID: any;
  segmentsArray = [];
  isTabNameRequired: Boolean = false;
  imagesTabListCopy: Array<Object> = [];
  imagesTabList = [];
  customContainer = [{ customContainerId: '1123', customContainerPackQty: '1232' }];
  selectedStack = 'Tab 1';
  display: Boolean;
  tabName: String = '';
  checkBoxStatus: boolean;
  selectedTabObj: any;
  Photoplannings: any;
  imageExtension: any;
  PhotoplanningCopy: any;
  valueChangesSubscription: any;
  tabNamesUpdated: object = {};
  isEnableDelete: any;
  searchFieldResults: any = {};
  selectedSupplierValue: any;
  isSupplierDisable: Boolean = false;
  supplierRequired: Boolean = false;
  requiredContainerCode: Boolean = false;
  // @ViewChild(NavBarComponent) nav: NavBarComponent;
  constructor(
    public fb: FormBuilder,
    public packagingCatalogService: PackagingCatalogService,
    public router: Router,
    public route: ActivatedRoute,
    public datePipe: DatePipe,
    public fileUploadService: FileUploadService,
    public location: Location,
    private toastr: ToastrService,
    public modalService: NgbModal,
    public bomService: BomService,
    private coreServices: CoreServices,
    public confirmationService: ConfirmationService,
    private globalModalService: ModalService,
    private sharedService: SharedService
  ) {
    this.buildForm();
  }

  ngOnInit() {
    const routeRoles = this.route.snapshot.data.roles;
    this.isEditable = this.coreServices.checkAccess(routeRoles);
    this.setImageTablist();
    this.containerId = this.packagingCatalogService.getParamForEdit();
    if ((this.containerId !== null && this.containerId !== undefined) && this.router.url === '/catalog/edit-detail') {
      this.fetchData();
      this.isNew = false;
    } else if ((this.containerId === null || this.containerId === undefined) && this.router.url === '/catalog/edit-detail') {
      this.router.navigate(['home']);
    } else {
      this.isNew = true;
      // this.assignImagesIfEdit();
      this.packagingCatalogService.getDropDownLists()
        .subscribe(data => {
          this.lists = data;
          this.checkFormValueChange();
        });
    }
    this.imagesTabListCopy = JSON.parse(JSON.stringify(this.imagesTabList));
    this.formControlValueChanged();
  }

  validateNumber(controlName, event) {
    if (event.target.value === '.') {
      this.pc_details.controls[controlName].setValue(null);
      event.target.value = '';
    }
  }


  checkisFormValid() {
    return ((this.custom.ITEM_ID !== null && this.custom.ITEM_ID.trim() !== '' && this.custom.ITEM_ID !== undefined && this.custom.CUSTOM_PACK_QTY !== null && this.custom.CUSTOM_PACK_QTY !== undefined) ? false : true);
  }




  fetchData = (updateAllDetails = true) => {

    const containerID = this.containerId ? this.containerId : null;
    if (containerID && containerID !== 'undefined' && containerID !== null) {
      this.setImageTablist();
      this.packagingCatalogService.getGridRoWDetails(containerID)
        .subscribe((catalogDetails: any) => {
          this.unSubscribeToValueChanges();
          if (!updateAllDetails) {
            this.bgImgPath = '';
            this.imgUploaded = false;
            this.checkBoxStatus = false;
            this.setImageTablist();
            if (catalogDetails.Photoplanning !== null) {
              // const imageUrls = catalogDetails.Photoplanning.map(e => e.PHOTO_TITLE).reverse();
              // this.bgImgPath = imageUrls.find(e => e.includes('.jpg') || e.includes('.png') || e.includes('.PNG') || e.includes('.jpeg') || e.includes('.gif'));
              // this.imgUploaded = true;
              this.assignImagesIfEdit(catalogDetails);
              const viewUploads = catalogDetails['Photoplanning'].filter(e => {
                const ext = e.PHOTO_TITLE.toLowerCase().split('.');
                return !(formConstants.imageExtensions.includes(ext[ext.length - 1]))
              });
              this.uploadedFiles = [...viewUploads];
            }
            // this.bgImgPath = '';
            // this.imgUploaded = false;
            // this.checkBoxStatus = false;
            return;
          }
          this.details = catalogDetails;
          this.selectedSupplierValue = catalogDetails['CONTAINER_SUPPLIER'];
          this.CustContainer = catalogDetails.CustContainer;
          if (catalogDetails.Photoplanning !== null) {
            // const imageUrls = catalogDetails.Photoplanning.map(e => e.PHOTO_TITLE).reverse();
            // this.bgImgPath = imageUrls.find(e => e.includes('.jpg') || e.includes('.png') || e.includes('.PNG') || e.includes('.jpeg') || e.includes('.gif'));
            // this.imgUploaded = true;
            this.assignImagesIfEdit(catalogDetails);
            const viewUploads = catalogDetails['Photoplanning'].filter(e => {
              const ext = e.PHOTO_TITLE.toLowerCase().split('.');
              return !(formConstants.imageExtensions.includes(ext[ext.length - 1]))
            });
            this.uploadedFiles = [...viewUploads];
          }
          this.lists = this.getListValuesFromDetails(catalogDetails);
          this.populateForm();
          this.subscribeToValueChanges();
        });
    }
  }

  addRow() {
    if (!this.CustContainer.some(item => item.ITEM_ID === this.custom.ITEM_ID)) {
      this.CustContainer.push(this.custom);
      this.custom = { ITEM_ID: null, CUSTOM_PACK_QTY: null, add: true, Item_Required: false, Custom_Required: false };
      this.detailsUpdated = true;
    } else {
      this.toastr.error('Given part number already exists', '', { disableTimeOut: false });
    }
  }
  changeCunsomContStatus() {
    this.CustContainer.forEach(function (ele) {
      ele.add = false;
    });
  }
  changContainerCode() {
    this.detailsUpdated = true;
  }

  validateCustomQty(id, value) {
    if (id === 'cust_cont' && (value['ITEM_ID'] !== null || value['ITEM_ID'] !== undefined)) {
      value['Custom_Required'] = true;
      value['Item_Required'] = false;
    }
  }

  getListValuesFromDetails = details => {
    const lists = {};
    this.selectValues.forEach(list => {
      lists[list] = [...details[list]];
    });
    return lists;
  }

  buildForm = () => {
    this.pc_details = this.fb.group(formConstants.formFields);
  }

  populateForm = () => {
    this.setSelectValues(this.selectValues);
    this.setFieldValues(formConstants.fieldValues);
    this.setCustContainerValues();
    // this.disableRequiredFields();
    this.checkFormValueChange();
  }

  customContainerChange() {
    if (this.pc_details.controls.CustomContainerInd.value) {
      this.customContainerStatus = (this.pc_details.controls.CustomContainerInd.value.CUSTOM_CONTAINER_IND === 'No') ? false : true;
      this.CustContainer = [];
    } else {
      this.customContainerStatus = false;
      this.CustContainer = [];
    }
    this.checkFormValueChange();
  }

  disableRequiredFields = () => {
    formConstants.staticRequiredFields.forEach(field => {
      this.pc_details.get(field).disable();
    });
  }

  checkFormValueChange = () => {
    this.formControlValueChanged();
    this.subscribeToValueChanges();
  }

  subscribeToValueChanges = () => {
    this.valueChangesSubscription = this.pc_details.valueChanges
      .subscribe(val => {
        this.detailsUpdated = true;
      });
  }

  unSubscribeToValueChanges = () => {
    if (this.valueChangesSubscription) {
      this.valueChangesSubscription.unsubscribe();
    }
  }

  setSelectValues = (selectControls: Array<string>) => {
    selectControls.forEach(ctrl => {
      const value = this.details[ctrl].find(i => {
        if (i.IsSelected === true) { return i; }
      });
      this.pc_details.controls[ctrl].setValue(value, { onlySelf: true });
    });
  }

  setFieldValues = (fieldControls: Array<string>) => {
    const dateFields = ['fleet_maintance_date', 'fleet_size_date', 'implementation_date'];
    for (const key in this.details) {
      if (dateFields.indexOf(key.toLowerCase()) !== -1) {
        this.details[key] = this.datePipe.transform(this.details[key], 'yyyy-MM-dd');
      }
    }
    fieldControls.forEach(ctrl => {
      const value = this.details[ctrl.toUpperCase()] === undefined || this.details[ctrl.toUpperCase()] === null
        ? formConstants.defaultZeroFields.indexOf(ctrl) > -1 ? 0 : null : this.details[ctrl.toUpperCase()];
      this.pc_details.controls[ctrl].setValue(value, { onlySelf: true });
    });
  }

  setCustContainerValues = () => {
    // TODO: Fetching only the first of the array for now. Need to changes according to functionality
    this.pc_details.controls['CustContainer_1'].setValue(this.details.CustContainer);

    const custContainerValues = this.details.CustContainer[0];
    if (custContainerValues) {
      const containerValue = custContainerValues.ITEM_ID || null;
      this.pc_details.controls['CustContainer_1'].setValue(containerValue);
      if (containerValue !== null) {
        this.pc_details.controls['CustContainer_1'].disable();
      }
      this.pc_details.controls['CustPackQty_1'].setValue(custContainerValues.CUSTOM_PACK_QTY || null);
    }
    this.customContainerStatus = false;
    this.details.CustomContainerInd.forEach(element => {
      if (element.CUSTOM_CONTAINER_IND === 'Yes' && element.IsSelected) {
        this.customContainerStatus = element.IsSelected;
      }
    });

  }

  formControlValueChanged() {
    if (this.checkValidInput(this.pc_details.value['CustPackQty_1'])) {
      this.pc_details.controls['CustContainer_1'].setValidators([Validators.required]);
      this.pc_details.controls['CustContainer_1'].updateValueAndValidity();
    } else {
      this.pc_details.controls['CustContainer_1'].setValidators([]);
      this.pc_details.controls['CustContainer_1'].updateValueAndValidity();
    }
  }

  returnPackagingScreen(content) {
    if (this.detailsUpdated) {
      this.modalService.open(content, { centered: true });
    } else {
      this.router.navigate(['/catalog']);
    }

  }

  returnPackagingSearchScreen() {
    // this.nav.breadcrumbListCopy();
    this.sharedService.createCopy.next();
    this.router.navigate(['/catalog']);
    this.modalService.dismissAll();
  }

  getCustContainerValidity = () => {
    // return this.checkValidInput(this.pc_details.get('CustPackQty_1').value) ? this.checkValidInput(this.pc_details.get('CustContainer_1').value) : true;
    if (this.custom.ITEM_ID !== null && this.custom.ITEM_ID !== undefined && this.custom.ITEM_ID !== '') {
      return this.checkValidInput(this.custom.CUSTOM_PACK_QTY);
    } else if (this.custom.CUSTOM_PACK_QTY !== null && this.custom.CUSTOM_PACK_QTY !== undefined && this.custom.CUSTOM_PACK_QTY !== '') {
      return this.checkValidInput(this.custom.ITEM_ID);
    } else {
      return true;
    }
  }

  checkData = () => {
    this.updateClicked = true;
    let detailsValid = true;
    let containerCodeValid = true;
    // Checking required fields
    if (this.isNew) {
      detailsValid = this.segmentValues.length === 0 ? false : true;
      if (this.segmentValues.length === 1 && detailsValid) {
        detailsValid = (this.checkValidInput(this.selectedSupplierValue));
        this.supplierRequired = !detailsValid;
      }
      if (this.segmentValues.length === 1 && containerCodeValid) {
        containerCodeValid = this.checkValidInput(this.pc_details.controls['container_code'].value);
        if (this.CustContainer.length === 0 || containerCodeValid) {
          this.requiredContainerCode = true;
        }
      } else {
        this.requiredContainerCode = false;
      }
    }

    if (!this.isNew) {
      const organization = this.lists.Organization.filter(a => a.IsSelected === true);
      detailsValid = this.checkValidInput(this.selectedSupplierValue);
      if (organization && !detailsValid) {
        this.supplierRequired = !detailsValid;
      }
    }

    // checking custom Container fields
    if (detailsValid) {
      detailsValid = this.getCustContainerValidity();
    }

    let defaultTab = [];
    const hasImages = this.imagesTabList.filter(e => e['bgImgPath'] !== '');
    if (hasImages.length > 0) {
      defaultTab = hasImages.filter(e => e['defaultTab']);
    }
    if ((hasImages.length > 0 && defaultTab.length === 1) || hasImages.length === 0) {
      (detailsValid) ? this.updateExistingContainer() : this.displayMessage('error', 'Please fill mandatory fields');
    } else {
      this.displayMessage('error', 'Please check set as default tab for any image');
    }
  }

  focusContainerCode() {
    this.requiredContainerCode = false;
  }
  blurContainerCode() {
    this.requiredContainerCode = !(this.checkValidInput(this.pc_details.controls['container_code'].value));
 }
  updateExistingContainer(): any {
    this.checkFormValueChange();
    const postData = this.buildPostData(this.pc_details.value);
    postData.CustContainer = this.CustContainer;
    postData.CONTAINER_SUPPLIER = this.selectedSupplierValue;
    if (!this.isNew && this.PhotoplanningCopy.length > 0) {
      postData.Photoplanning = this.isPhotoPlanningChanged(postData);
      // postData.photoPlanning = [...this.getPhotoPlanningUptoDate(postData.Photoplanning)];
    } else {
      postData.Photoplanning = [];
    }

    this.packagingCatalogService.saveContainerDetails(postData)
      .subscribe(data => {
        this.successData = data;
        this.isDisable = false;
        const status = this.successData.map(a => a.statusEntity.StatusType).filter(e => e === 'FAILURE');
        const message = this.successData.map(a => a.statusEntity.Message);
        //   if (this.isNew) {
        // if (status.StatusType === 'SUCCESS') {
        //   this.isNew = false;
        //   this.detailsUpdated = false;
        //   this.route.snapshot.data['containerID'] = this.successData.CONTAINER_SID;
        //   this.changeCunsomContStatus();
        //   this.displayMessage('success', 'Details succesfully updated');
        // }
        if (status.length === 0) {
          this.detailsUpdated = false;
          this.changeCunsomContStatus();
          this.displayMessage('success', 'Details succesfully updated');
          if (this.fileArray && this.fileArray.length > 0) {
            this.uploadService();
          } else {
            if (this.isNew) {
              this.router.navigate(['/catalog']);
            }
          }
        } else {
          this.displayMessage('error', message);
          this.detailsUpdated = false;
        }
        //   }

      });
  }

  defaultValueToZero = details => {
    formConstants.defaultZeroFields.forEach(field => {
      details[field] =
        details[field] === undefined || null ? 0 : details[field];
    });
    return details;
  }

  buildPostData = fieldDetails => {
    // fetching the disabled field values explicitly
    // fieldDetails.CONTAINER_SUPPLIER = this.selectedSupplierValue;
    fieldDetails.Organization = this.pc_details.get('Organization').value;

    fieldDetails.CONTAINER_SID = this.isNew ? 0 : this.containerId;
    // append zero
    fieldDetails = this.defaultValueToZero(fieldDetails);

    fieldDetails = this.formatDates(fieldDetails);
    // TODO: Remove this once all the cust containers functionality is in place
    fieldDetails.CustContainer = [{}];
    fieldDetails.CustContainer[0].ITEM_ID = this.pc_details.get('CustContainer_1').value;
    fieldDetails.CustContainer[0].CUSTOM_PACK_QTY = this.pc_details.get('CustPackQty_1').value;
    // End
    this.selectValues.forEach(select => {
      const selectedValue = fieldDetails[select];
      if (selectedValue) {
        fieldDetails[select] = this.lists[select];
        fieldDetails[select].forEach(val => {
          val.IsSelected = val[this.dropDownObjAPIValues[select]] === selectedValue[this.dropDownObjAPIValues[select]] ? true : false;
        });
      } else {
        fieldDetails[select] = this.lists[select];
      }
    });
    return fieldDetails;
  }

  checkValidInput(data) {
    return (data !== null && data !== undefined && data !== '') ? true : false;
  }

  formatDates(data) {
    const dateFields = ['fleet_maintance_date', 'fleet_size_date', 'implementation_date'];
    dateFields.forEach(field => {
      data[field] = this.datePipe.transform(data[field], 'yyyy-MM-dd');
    });
    return data;
  }

  displayMessage(type = 'error', message) {
    type !== 'error' ? this.toastr.success(message, '', { disableTimeOut: false }) : this.toastr.error(message);
  }

  segmentSelection(field) {
    this.lists.Organization.forEach(val => val.IsSelected = false);
    this.segmentValues.forEach(val => val.IsSelected = true);
    const value = this.lists[field][0];
    if (this.segmentValues && this.segmentValues.length > 1 && this.isNew) {
      this.pc_details.get(field).disable();
      this.isSupplierDisable = true;
      this.selectedSupplierValue = '';
      this.supplierRequired = false;
      value.IsSelected = true;
      this.lists.CustomContainerInd[0].IsSelected = true;
      this.pc_details.controls[field].setValue(value, { onlySelf: true });
    } else {
      this.pc_details.get(field).enable();
      this.isSupplierDisable = false;
      value.IsSelected = false;
      this.lists.CustomContainerInd[0].IsSelected = false;
      this.pc_details.controls[field].setValue(null, { onlySelf: true });
    }
    // this.customContainerChange();
  }

  loadBillOfMaterial() {
    if (this.successData !== null) {
      // tslint:disable-next-line:no-var-keyword
      var { CONTAINER_SID, ORG_ID } = this.successData;
    } else {
      // tslint:disable-next-line:no-var-keyword
      // tslint:disable-next-line:prefer-const
      var { CONTAINER_SID } = this.details;
      // tslint:disable-next-line:no-var-keyword
      // tslint:disable-next-line:prefer-const
      var { ORG_ID } = this.details.Organization.find(i => i.IsSelected);
    }
    this.bomService.setBomContainerId(CONTAINER_SID);
    this.bomService.setBomOrgId(ORG_ID);
    this.bomService.setRouteData(CONTAINER_SID, ORG_ID);
    // this.router.config.find(e=>e.path==='catalog/edit-detail').data.containerID=CONTAINER_SID
    // this.router.config.find(e=>e.path==='catalog/bom').data.routeData = { CONTAINER_SID, ORG_ID };
    this.router.navigate(['catalog/edit-detail/bom']);
  }

  // new form functions

  isFieldValid(field: string) {
    return (!this.pc_details.get(field).valid && this.pc_details.get(field).touched);
  }

  displayFieldCss(field: string) {
    return { 'has-error': this.isFieldValid(field), 'has-feedback': this.isFieldValid(field) };
  }




  displayOptionValue = results => {
    results = results.map(res => {
      const opt = { displayValue: '', value: '' };
      opt.displayValue = `${res['SUPPLIER_ID']} - ${res['SUPPLIER_NAME']}`;
      opt.value = res['SUPPLIER_ID'];
      return opt;
    });
    return [...results];

  }

  searchFieldFetch = (value) => {
    this.selectedSupplierValue = value;
    const editedOrgId = this.lists ? this.lists.Organization.map(a => { if (a.IsSelected === true) { return a.ORG_ID; } }).join('') : null;
    const ORG_ID = this.isNew ? this.segmentValues.map(a => { a.IsSelected; return a.ORG_ID; }) : editedOrgId;
    this.packagingCatalogService.getSearchFieldData(value, ORG_ID).subscribe(res => {
      const results = res as Array<any>;
      this.searchFieldResults = this.displayOptionValue([...results]);
    });
  }

  searchFieldOptSelected = (selectedValue) => {
    this.selectedSupplierValue = selectedValue;
    this.supplierRequired = false;
    if (!this.detailsUpdated) {
      this.detailsUpdated = true;
    }
  }

  searchfieldEmptied = event => {
    this.supplierRequired = true;
    // this.detailsUpdated = false;
  }

  searchfieldBlurred = (e) => {
    if (e === 'unset') {
      this.selectedSupplierValue = '';
      this.supplierRequired = true;
      // this.detailsUpdated = false;

    }
  }

  /* confirmation for delete images */
  deleteConfirmation(e) {
    this.confirmationService.confirm({
      message: 'Do you want to delete the image?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.deleteImage();
      },
      reject: () => {
      }
    });
  }

  /* to set bgImgPath */
  setImageBg = file => {
    const reader = new FileReader();
    if (file) {
      reader.readAsDataURL(file);
    }
    reader.onloadend = () => {
      this.bgImgPath = reader.result;
      this.imgUploaded = true;
      this.setImageForObj();
    };
  }

  /* to set bgImgPath for selectedtab */
  setImageForObj() {
    this.selectedTabObj['bgImgPath'] = this.bgImgPath;
  }


  /*  File Upload functions */
  uploadFiles = (event, type) => {
    this.files = event.target.files;
    const fileUploaded = type;

    for (let i = 0; i < this.files.length; i++) {
      if (type === 'files') {
        const fileExtension = this.files[i].name.split('.').pop();
        for (const fileType in constants.fileExtensions) {
          type = (type === 'files' && constants.fileExtensions[fileType].includes(fileExtension)) ? fileType : type;
        }

      }
      if (this.selectedTabObj.displayName) {
        this.files[i]['tabName'] = this.selectedTabObj.displayName;
        this.files[i]['filetype'] = type;
      } else if (this.selectedTabObj.PHOTO_TAB_NAME) {
        this.files[i]['tabName'] = this.selectedTabObj.PHOTO_TAB_NAME;
        this.files[i]['filetype'] = type;
      }
      type = fileUploaded;
      this.fileArray.push(this.files[i]);
      if (type === 'images') {
        this.setImageBg(this.files[0]);
        this.imageExtension = this.files[0].name.split('.').pop();
        this.selectedTabObj.imageExtension = this.imageExtension;
      }
    }
    this.detailsUpdated = true;
  }

  /* upload service */
  uploadService = () => {
    let ORG_ID = null;
    if (this.isNew) {
      ORG_ID = this.segmentValues.map(a => a.ORG_ID).join();
    } else {
      ORG_ID = this.details.Organization.find(e => e.IsSelected).ORG_ID;
    }
    const CONTAINERSID_ORGID = this.successData.map(a => (`${a.CONTAINER_SID}_${a.ORG_ID}`)).join();
    const defaultTab = this.imagesTabList.find(e => e['defaultTab']);
    const editedTabNames = this.imagesTabList.filter(e => e['isEdited']);
    const defaultEditedTabName = this.imagesTabList.find(e => e['isEdited'] && e['defaultTab']);
    this.formData = new FormData();
    this.formData.append('ORG_ID', ORG_ID);
    this.formData.append('PHOTO_ORIGIN_SCREEN', 'PkgDetails');
    this.formData.append('DEFAULT_TAB', defaultEditedTabName ? defaultEditedTabName['displayName'] : defaultTab ? defaultTab['displayName'] : 'Tab 1');
    this.formData.append('CONTAINERSID_ORGID', CONTAINERSID_ORGID);
    const formDataValue = this.formData;
    for (let i = 0; i < this.fileArray.length; i++) {
      // Add the file to the request.
      // this.fileArray[i].tabName = this.imagesTabList.length > 0 ? this.imagesTabList[i]['displayName'] : defaultTab ? defaultTab['displayName'] : 'Tab 1';
      if (this.fileArray[i].filetype === 'images') {
        this.formData.append('File' + i, this.fileArray[i], `${this.fileArray[i].tabName}^${this.fileArray[i].name}`);
      } else {
        this.formData.append('File' + i, this.fileArray[i], `${this.fileArray[i].name}`);
      }

    }
    this.fileUploadService.uploadFiles(this.formData, (progress, percent, e) => {
      if (progress === 'complete' && e.StatusEntity.StatusType === 'SUCCESS') {
        e.Photoplannings.forEach(data => {
          this.uploadedFiles.unshift(data.PHOTO_TITLE);
          this.imageExtension = data.PHOTO_TITLE.split('.').pop();
        });
        this.displayMessage('success', 'File Uploaded Successfully');
        if (this.isNew) {
          this.router.navigate(['/catalog']);
        } else {


          this.fetchData(false);
        }
      }
      if (progress === 'error') {
        this.displayMessage('error', e);
      }
      this.fileArray = [];
    });
  }

  /* to view uploaded files in popup */
  viewUploadFiles = (content) => {
    this.modalService.open(content, { centered: true, size: 'lg', windowClass: 'view-uploads-modal' });
  }

  /* open edit tab names popup */
  editTabNames = () => {
    this.display = true;
  }

  /* close edit tab names popup */
  close = () => {
    this.display = false;
  }

  /* save edited tab names */
  saveTabNames() {
    if (!this.isTabNameRequired) {
      this.display = false;
      let selectTabIndex = null;
      if (this.selectedTabObj.PHOTO_TAB_NAME) {
        selectTabIndex = this.imagesTabList.findIndex(e => e['displayName'] === this.selectedTabObj.PHOTO_TAB_NAME);
      } else {
        selectTabIndex = this.imagesTabList.findIndex(e => e['displayName'] === this.selectedTabObj.displayName);
      }
      if (Object.keys(this.tabNamesUpdated).length > 0) {
        for (const changedTabIdx in this.tabNamesUpdated) {
          const i = this.fileArray.findIndex(e => e.tabName === this.imagesTabListCopy[changedTabIdx]['displayName']);

          this.imagesTabListCopy[changedTabIdx]['displayName'] = this.tabNamesUpdated[changedTabIdx];
          if (i > -1) {
            this.fileArray[i].tabName = this.imagesTabListCopy[changedTabIdx]['displayName'];
          }
          this.imagesTabList[changedTabIdx]['displayName'] = JSON.parse(JSON.stringify(this.imagesTabListCopy[changedTabIdx]['displayName']));
          this.imagesTabListCopy[changedTabIdx]['value'] = this.tabNamesUpdated[changedTabIdx];
          this.imagesTabList[changedTabIdx]['value'] = JSON.parse(JSON.stringify(this.imagesTabListCopy[changedTabIdx]['displayName']));
          this.imagesTabList[changedTabIdx]['isEdited'] = true;
        }
        this.selectedTabObj = this.imagesTabList[selectTabIndex];
        this.selectedTabObj.PHOTO_TAB_NAME = this.selectedTabObj.displayName;
        this.selectedStack = this.selectedTabObj.displayName;
        this.detailsUpdated = true;
      }
    } else {
      this.display = true;
    }
  }

  /* set tab value to the model */
  tabValueChange(e, index) {
    e.stopPropagation();
    const name = e.target.value;
    this.tabNamesUpdated[index] = name.trim();
    if (this.tabNamesUpdated[index] === '') {
      this.isTabNameRequired = true;
    } else {
      this.isTabNameRequired = false;
      if (e.key === 'Enter') {
        this.saveTabNames();
      }
    }
  }

  /* to disable delete */
  isDisableDelete() {
    const isDisable = this.uploadedFiles.filter(e => e.isDeleted);
    return isDisable.length > 0 ? false : true;
  }

  /* api call to delete files */
  deleteFile() {
    const post = this.uploadedFiles.filter(e => e.isDeleted).map(e => e.PHOTO_SID);
    if (post && post.length > 0) {
      this.packagingCatalogService.deleteUploadedFiles(post).subscribe(res => {
        if (res['StatusType'] === 'SUCCESS') {
          this.modalService.dismissAll();
          this.displayMessage('success', 'File Deleted Successfully');
          this.fetchData(false);
        }
      });
    }
  }

  /* set selected objec on tab click */
  onTabClick = (selectedTab) => {
    this.tabClickHandler(selectedTab);
    this.selectedTabObj = this.imagesTabList.find(e => e['displayName'] === selectedTab);
    const editedTabNames = this.imagesTabList.find(e => e['isEdited'] && e['value'] === selectedTab);
    if (editedTabNames) {
      selectedTab = editedTabNames['displayName'];
      this.selectedTabObj = this.imagesTabList.find(e => e['displayName'] === selectedTab);
    }
    this.bgImgPath = this.selectedTabObj['bgImgPath'] ? this.selectedTabObj['bgImgPath'] : '';
    this.imgUploaded = this.bgImgPath ? true : false;
    this.checkBoxStatus = this.selectedTabObj['defaultTab'] ? this.selectedTabObj['defaultTab'] : false;
    this.imageExtension = this.selectedTabObj.imageExtension;
  }

  /* set value of tab on click of tab */
  tabClickHandler = (selectedTab) => {
    this.selectedStack = selectedTab;
  }

  /* set default tab for current object on click on checkbox */
  checkBoxTabStatus(eve) {

    this.detailsUpdated = true;
    this.imagesTabList.forEach(e => e['defaultTab'] = false);
    this.selectedTabObj['defaultTab'] = eve;
  }

  /* add new tab */
  addNewTab = () => {
    this.display = true;
  }

  /* hide new tab */
  hideDialoge = () => {
    this.display = false;
  }


  /* api call to delete image */
  deleteImage() {
    const post = [];
    if (this.selectedTabObj.PHOTO_SID === undefined) {
      this.selectedTabObj.bgImgPath = '';
      this.bgImgPath = this.selectedTabObj.bgImgPath;
      this.imgUploaded = this.bgImgPath ? true : false;
      this.selectedTabObj.defaultTab = false;
      this.checkBoxStatus = false;
      this.imageExtension = '';
      const index = this.fileArray.findIndex(e => e.tabName === this.selectedTabObj.value);
      this.fileArray.splice(index, 1);
      this.toastr.success('Deleted image successfully', '', { disableTimeOut: false });
    } else {

      post.push(this.selectedTabObj.PHOTO_SID);
      this.packagingCatalogService.deleteUploadedFiles(post)
        .subscribe((data: any) => {
          if (data.StatusType !== 'FAILURE') {
            this.toastr.success(data.Message, '', { disableTimeOut: false });
            this.fetchData(false);
          } else {
            this.toastr.error(data.Message);
          }
        });
    }

  }

  /* logic for default tab changes */
  isPhotoPlanningChanged(post) {
    const imageTabDefault = this.imagesTabList.find(e => e['defaultTab']);
    const orginalDefaultTab = this.PhotoplanningCopy.find(e => e['DEFAULT_TAB']);
    const imagesUploadedLength = this.imagesTabList.filter(e => e['bgImgPath'] !== '');
    if (orginalDefaultTab !== undefined) {
      if (imageTabDefault['displayName'] !== orginalDefaultTab['PHOTO_TAB_NAME']) {
        if (imagesUploadedLength.length > this.PhotoplanningCopy.length) {
          this.PhotoplanningCopy.forEach(e => e['DEFAULT_TAB'] = false);
          post.Photoplanning = [...this.getPhotoPlanningUptoDate([...this.PhotoplanningCopy])];
        } else {
          const index = this.PhotoplanningCopy.findIndex(e => e['PHOTO_TAB_NAME'] === imageTabDefault['displayName']);
          if (index > -1) {
            this.PhotoplanningCopy.forEach(e => e['DEFAULT_TAB'] = false);
            this.PhotoplanningCopy[index]['DEFAULT_TAB'] = true;
            post.Photoplanning = [...this.getPhotoPlanningUptoDate([...this.PhotoplanningCopy])];
          } else {
            post.Photoplanning = [...this.getPhotoPlanningUptoDate([...this.PhotoplanningCopy])];
          }
        }
      } else {
        post.Photoplanning = [...this.getPhotoPlanningUptoDate([...this.PhotoplanningCopy])];
      }
    } else {
      post.Photoplanning = [...this.getPhotoPlanningUptoDate([...this.PhotoplanningCopy])];
    }
    return post.Photoplanning;
  }

  /* logic to construct edited tab's object */
  getPhotoPlanningUptoDate = photoPlanning => {
    let hasChanged = false;
    this.imagesTabList.forEach(e1 => {
      if (e1['isEdited'] || e1['defaultTab']) {
        hasChanged = true;
        const index = photoPlanning.findIndex(e => e['PHOTO_SID'] === e1['PHOTO_SID']);
        if (index > -1) {
          photoPlanning[index]['PHOTO_TAB_NAME'] = e1['displayName'];
          photoPlanning[index]['DEFAULT_TAB'] = e1['defaultTab'];
        }
      }
    });
    return hasChanged ? [...photoPlanning] : [];
  }

  /* set images in edit screen */
  assignImagesIfEdit(data) {
    // this.Photoplannings = this.details.Photoplanning;
    this.Photoplannings = data['Photoplanning'].filter(e => {
      const ext = e.PHOTO_TITLE.toLowerCase().split('.');
      return (formConstants.imageExtensions.includes(ext[ext.length - 1]))
    });
    this.PhotoplanningCopy = JSON.parse(JSON.stringify(this.Photoplannings));
    if (this.Photoplannings.length > 0) {
      let index = 0;
      this.Photoplannings.forEach(element => {
        const tempObjindex = this.imagesTabList.findIndex(e => e['displayName'] === element.PHOTO_TAB_NAME);
        if (tempObjindex !== -1) {
          this.imagesTabList[tempObjindex]['bgImgPath'] = element['PHOTO_TITLE'];
          this.imagesTabList[tempObjindex]['defaultTab'] = element['DEFAULT_TAB'];
          this.imagesTabList[tempObjindex]['displayName'] = element['PHOTO_TAB_NAME'];
          this.imagesTabList[tempObjindex]['PHOTO_TAB_NAME'] = element['PHOTO_TAB_NAME'];
          this.imagesTabList[tempObjindex]['CONTAINER_SID'] = element['CONTAINER_SID'];
          this.imagesTabList[tempObjindex]['PHOTO_SID'] = element['PHOTO_SID'];
          this.imagesTabList[tempObjindex]['imageExtension'] = this.imagesTabList[tempObjindex]['bgImgPath'].split('.').pop();
          this.imageExtension = this.imagesTabList[tempObjindex]['bgImgPath'].split('.').pop();
        } else {
          index = this.imagesTabList.findIndex(e => e['bgImgPath'] === '');
          this.imagesTabList.splice(index, 1);
          this.imagesTabList.splice(index, 0, { class: 'image-tab' });
          this.imagesTabList[index]['bgImgPath'] = element['PHOTO_TITLE'];
          this.imagesTabList[index]['defaultTab'] = element['DEFAULT_TAB'];
          this.imagesTabList[index]['value'] = element['PHOTO_TAB_NAME'];
          this.imagesTabList[index]['displayName'] = element['PHOTO_TAB_NAME'];
          this.imagesTabList[index]['PHOTO_TITLE'] = element['PHOTO_TITLE'];
          this.imagesTabList[index]['CONTAINER_SID'] = element['CONTAINER_SID'];
          this.imagesTabList[index]['PHOTO_SID'] = element['PHOTO_SID'];
          this.imagesTabList[index]['imageExtension'] = this.imagesTabList[index]['bgImgPath'].split('.').pop();
          this.imageExtension = this.imagesTabList[index]['bgImgPath'].split('.').pop();
        }

      });
      this.selectedTabObj = this.setDefaultTabObject();
      this.selectedStack = this.selectedTabObj['PHOTO_TAB_NAME'];
      this.selectedTabObj['bgImgPath'] = this.selectedTabObj['PHOTO_TITLE'];
      this.bgImgPath = this.selectedTabObj['bgImgPath'];
      this.checkBoxStatus = true;
      this.imgUploaded = this.bgImgPath ? true : false;
      const imageCurrentTab = this.imagesTabList.findIndex(e => e['displayName'] === this.selectedTabObj.PHOTO_TAB_NAME);
      this.imageExtension = this.bgImgPath.split('.').pop();
      this.imagesTabList[imageCurrentTab]['defaultTab'] = true;
    }
  }

  /* set default image */
  setDefaultTabObject() {
    let defaultTabIndex = this.Photoplannings.findIndex(e => e.DEFAULT_TAB);
    if (defaultTabIndex < 0) {
      defaultTabIndex = this.Photoplannings.findIndex(e => e.PHOTO_TITLE);
      this.PhotoplanningCopy[defaultTabIndex]['DEFAULT_TAB'] = true;
      this.Photoplannings[defaultTabIndex]['DEFAULT_TAB'] = true;
    }
    return this.Photoplannings[defaultTabIndex];
  }

  /* initialize imagesTabList array */
  setImageTablist() {
    this.imagesTabList = [{ displayName: 'Pic 1', value: 'Pic 1', class: 'image-tab', bgImgPath: '', defaultTab: false, imageExtension: '' },
    { displayName: 'Pic 2', value: 'Pic 2', class: 'image-tab', bgImgPath: '', defaultTab: false, imageExtension: '' },
    { displayName: 'Pic 3', value: 'Pic 3', class: 'image-tab', bgImgPath: '', defaultTab: false, imageExtension: '' },
    { displayName: 'Pic 4', value: 'Pic 4', class: 'image-tab', bgImgPath: '', defaultTab: false, imageExtension: '' },
    { displayName: 'Pic 5', value: 'Pic 5', class: 'image-tab', bgImgPath: '', defaultTab: false, imageExtension: '' }];
    this.selectedTabObj = this.imagesTabList[0];
    this.selectedStack = this.selectedTabObj.displayName;
  }

  canDeactivate = () => {
    if (this.detailsUpdated) {
      this.globalModalService.open();
      return this.globalModalService.getConfirmationSubject();
    }
    return true;

  }


}
