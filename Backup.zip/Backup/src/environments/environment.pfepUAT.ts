export const environment = {
    production: true,
    api: 'https://entpfepq01/pfepuatservice/api/',
    authUser: 'https://entpfepq01/pfepuatservice/api/User/Get',
    authToken: 'https://entpfepq01/pfepuatservice/Token'
};