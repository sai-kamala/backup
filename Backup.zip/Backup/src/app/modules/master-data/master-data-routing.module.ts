import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MasterDataComponent } from './master-data.component';
import { AuthGuard } from 'src/app/core/guards/auth-guard';
import { CanDeactivateGuard } from 'src/app/core/guards/can-deactivate-guard';
// import { PresentationTypesComponent } from './presentation-types/presentation-types.component';
// import { ReplenishMethodCodesComponent } from './replenish-method-codes/replenish-method-codes.component';
// import { StorageUnitsComponent } from './storage-units/storage-units.component';
// import { ShopCalendarComponent } from './shop-calendar/shop-calendar.component';
// import { ContainerUsageTypeComponent } from './container-usage-type/container-usage-type.component';
// import { OrganizationComponent } from './organization/organization.component';

const masterDataRoutes: Routes = [
  { path: '', component: MasterDataComponent, data: { roles: { Partial: ['PFEP SPECIALIST'], All: ['BUSINESS ADMINISTRATOR'] } }, canActivate: [AuthGuard], canDeactivate: [CanDeactivateGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(masterDataRoutes)],
  exports: [RouterModule]
})
export class MasterDataRoutingModule { }
