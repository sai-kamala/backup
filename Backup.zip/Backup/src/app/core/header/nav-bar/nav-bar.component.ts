import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { CoreServices } from '../../services/core.service';
import { Location } from '@angular/common';
import { Router, NavigationStart, NavigationEnd, ActivatedRoute, RoutesRecognized, ActivationEnd } from '@angular/router';
import { filter, pairwise } from 'rxjs/operators';
import { menuItems } from './menu.constant';
import { BreadCrumbs } from './bread-crumbs.constant';
import { SharedService } from 'src/app/shared/services/share.service';
import { ModalService } from '../../services/modal.service';

// import { Router, Event, ActivationEnd, NavigationEnd, ActivatedRoute } from '@angular/router';
// import { filter, map, buffer, pluck, switchMap } from 'rxjs/operators';

const userAdmin = ['USER ACCESS ADMINISTRATOR'];


@Component({
  selector: 'pfep-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class NavBarComponent implements OnInit {

  navItems: Array<Object>;
  isAdmin = false;
  breadcrumbList: any = [];
  breadcrumbListCopy: any = [];
  bcLoadedData: any[];
  bcForDisplay: any;
  isChanged: boolean;
  isMenuClicked: boolean;
  currentBreadCrumbURL = '/home';
  currentIndex: number;
  menuBreadCrumb: any;
  constructor(private coreServices: CoreServices, private router: Router, private sharedService: SharedService, private cdRef: ChangeDetectorRef, private modalService: ModalService) { }

  /* function to set breadcrumb on load of app */
  onAppLoad(url) {
    let routerList;
    if (url === '/' && !this.isAdmin) {
      routerList = ['home'];
    } else if (url === '/' && this.isAdmin) {
      routerList = ['Administration'];
    } else {
      routerList = url.slice(1).split('/');
    }
    return routerList;
  }

  /* function to set breadcrumb on menu click  */
  setBreadCrumb(url, flag) {
    const routerList = this.onAppLoad(url);
    this.isMenuClicked = flag ? flag : false;
    this.createBreadCrumbCopy();

    this.breadcrumbList = [];
    routerList.forEach((router) => {
      const urlBreadCrumb = BreadCrumbs.find(page => page.url === router);
      if (urlBreadCrumb) {
        this.breadcrumbList.push(urlBreadCrumb.breadcrumb);
      }
    });
    this.cdRef.detectChanges();
  }

  /* function to create a copy of breadcrumb */
  createBreadCrumbCopy() {
    this.breadcrumbListCopy = JSON.parse(JSON.stringify(this.breadcrumbList));
  }

  /* function on click of the breadcrumb  */
  setRoute(url) {
    this.currentBreadCrumbURL = url;
    this.isMenuClicked = true;
    this.currentIndex = this.breadcrumbList.findIndex(e => e.to === this.currentBreadCrumbURL);
    this.setHierarchy(this.currentIndex + 1);
  }

  /* function to set the hierarchy/link of routes */
  setHierarchy(currentIndex) {
    this.createBreadCrumbCopy();
    if (this.currentIndex > -1) {
      this.breadcrumbList.splice(currentIndex, this.breadcrumbList.length);
    }
    this.isChanged = true;
  }

  /* funtion to check the hierarchy */
  checkHierarchy() {
    this.sharedService.getHierArchy()
      .subscribe((data) => {
        if (!this.isMenuClicked) {
          if (data.isChild) {
            if (this.checkPfepUrl()) {
              let url = this.router.url.slice(1).split('/')[0];
              let urlBreadCrumb = BreadCrumbs.find(page => page.url === url);
              if (!urlBreadCrumb) {
                url = this.router.url.slice(1).split('/')[1];
                urlBreadCrumb = BreadCrumbs.find(page => page.url === url);
              }
              this.breadcrumbList = [...this.breadcrumbListCopy.concat(urlBreadCrumb.breadcrumb)];
              this.createBreadCrumbCopy();
            }
          } else if (data.back) {
            this.currentBreadCrumbURL = data.backurl;
            this.currentIndex = this.breadcrumbList.findIndex(e => e.to === this.currentBreadCrumbURL);
            //since there is a circular navigation between mfcr, item-plan, single-rack and routeReuse doesn't work we have to consider the breadcrumblistcopy aswell
            if (['/mfcr', '/item-plan-detail', '/pou/single-rack'].includes(data.backurl)) {
              const idx = this.breadcrumbListCopy.findIndex(e => e.to === this.currentBreadCrumbURL);
              if (idx > -1) {
                this.breadcrumbList = JSON.parse(JSON.stringify(this.breadcrumbListCopy));
                this.currentIndex = idx;
              }
            }
            this.setHierarchy(this.currentIndex);
          } else if (data.setUrl) {
            this.setBreadCrumb(data.backurl, false);
          }
          this.cdRef.detectChanges();
        }
        this.isMenuClicked = false;
      });
  }

  /* fucntion for pfep hierarchy link removal */
  checkPfepUrl() {
    if (this.breadcrumbList.length === 1) {
      if (this.breadcrumbList[0].to === this.breadcrumbListCopy[0].to) {
        return false;
      }
      return true;
    }
    return true;

  }

  /* function to set breadcrumb on stay and save changes */
  checkDeactivate() {
    this.modalService.getConfirmationSubject()
      .subscribe(data => {
        if (!data) {
          this.isMenuClicked = false;
          if (!this.router.url.includes('/catalog')) {
            this.breadcrumbList = this.breadcrumbListCopy;
          }
          this.cdRef.detectChanges();
        }
      });
  }

  /* function to set breadcrumb naviation end */
  routerEvents() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.createBreadCrumbCopy();
        if (!this.isChanged) {
          this.setBreadCrumb(event.urlAfterRedirects ? event.urlAfterRedirects : event.url, false);
        }
        this.isChanged = false;
      }
    });
  }

  /*  create copy for breadcrumb */
  createCopy() {
    this.sharedService.getBreadCrumbCopy()
      .subscribe(data => {
        this.createBreadCrumbCopy();
      });
  }

  ngOnInit() {
    this.isAdmin = this.coreServices.checkAccess(userAdmin);
    this.navItems = this.isAdmin ? menuItems.filter(e => e.label === 'Administration') : menuItems;
    this.checkHierarchy();
    this.checkDeactivate();
    this.routerEvents();
    this.createCopy();
  }

}
