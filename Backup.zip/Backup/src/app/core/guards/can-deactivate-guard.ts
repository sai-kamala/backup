import { Injectable } from '@angular/core';
import { CanDeactivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';

export interface CanDeactivateInterface {
  canDeactivate: () => boolean | Observable<boolean> | Promise<boolean>  ;
}

@Injectable({ providedIn: 'root' })
export class CanDeactivateGuard implements CanDeactivate<CanDeactivateInterface> {
  canDeactivate(component: CanDeactivateInterface, 
           route: ActivatedRouteSnapshot, 
           state: RouterStateSnapshot) {

     return component.canDeactivate ? component.canDeactivate() : true;
  }
}