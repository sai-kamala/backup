export const photoPlanningData = [
    {
        "PHOTO_SID": 14,
        "PHOTO_TITLE": "https://entpfepp01/PFEPDocs//220387/DEF/C0001.png",
        "PHOTO_ORIGIN_SCREEN": "PkgDetails",
        "CONTAINER_SID": 283,
        "PHOTO_TAB_NAME": "Front",
        "DEFAULT_TAB": true
    },
    {
        "PHOTO_SID": 15,
        "PHOTO_TITLE": "",
        "PHOTO_ORIGIN_SCREEN": "PkgDetails",
        "CONTAINER_SID": 283,
        "PHOTO_TAB_NAME": "Back",
        "DEFAULT_TAB": false
    },
    {
        "PHOTO_SID": 15,
        "PHOTO_TITLE": 'https://entpfepd01/PFEPDocs/komodo_dragon-1050x700-1024x683.jpg',
        "PHOTO_ORIGIN_SCREEN": "PkgDetails",
        "CONTAINER_SID": 283,
        "PHOTO_TAB_NAME": "Top",
        "DEFAULT_TAB": false
    }
];

export const tabName = 'PHOTO_TAB_NAME';
export const photoUrl = 'PHOTO_TITLE';
export const defaultTab = 'DEFAULT_TAB';
export const originScreen = 'PHOTO_ORIGIN_SCREEN';
export const photoSID = 'PHOTO_SID';
export const ctrSID = 'CONTAINER_SID';
export const photoPlanning = 'Photoplanning';
export const imageExtensions = ['jpg', 'png', 'gif', 'jpeg'];
export const fileDataSkeleton = {
    "PHOTO_SID": '',
    "PHOTO_TITLE": '',
    "PHOTO_ORIGIN_SCREEN": "PkgDetails",
    "CONTAINER_SID": '',
    "PHOTO_TAB_NAME": "",
    "DEFAULT_TAB": false
}