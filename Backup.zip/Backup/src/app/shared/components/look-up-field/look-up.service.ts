import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { environment } from 'src/environments/environment';
@Injectable({
  providedIn: 'root'
})

export class LookUpService {

  private baseUrl: string = environment.api;
  constructor(private http: HttpClient) {
  }
  getDropDownData(url) {
    return this.http.get(`${this.baseUrl}${url}`);
  }
  getTableData(url, data) {
    return this.http.post(`${this.baseUrl}${url}`, data);
  }

}
