export default {
  transnationalFields: {
    ITEM_DEMAND: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: true,
        type: 'select',
        maxLength: 100,
        disabled: true,
        value: '',
        isPrimary: false, styleclass: '  col-md-2'
      },
      {
        field: 'ITEM_ID',
        title: 'Item Id',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: false, styleclass: '  col-md-2'
      },
      {
        field: 'DEMAND_DATE',
        title: 'Demand Date',
        required: true,
        type: 'date',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: true, styleclass: 'col-md-2'
      },
      {
        field: 'WORK_CENTER_ID',
        title: 'Work Center Id',
        required: true,
        type: 'text',
        maxLength: 50,
        disabled: true,
        value: null, isPrimary: false, styleclass: '  col-md-2'
      }
    ],
    ITEMS: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: true,
        type: 'select',
        maxLength: 20,
        disabled: true,
        value: '', isPrimary: false, styleclass: '  col-md-2'
      },
      {
        field: 'ITEM_ID',
        title: 'Item Id',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: false, styleclass: '  col-md-2'
      }

    ],
    MATERIAL_FLOW_PLANS: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: true,
        type: 'select',
        maxLength: 100,
        disabled: true,
        value: '',
        isPrimary: false, styleclass: '  col-md-2'
      },
      {
        field: 'MTRL_FLOW_PLAN_ID',
        title: 'Mtrl Flow Plan Id',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: false, styleclass: '  col-md-2'
      },
      {
        field: 'REPLENISHMENT_METHOD_CODE',
        title: 'Replenishment Method Code',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: false, styleclass: '  col-md-3'
      },

    ],
    STORAGE_UNITS: [
      {
        field: 'STORAGE_UNIT_ID',
        title: 'Storage Unit Id',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: false, styleclass: '  col-md-2'
      }
    ],
    SHOP_CALENDAR: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: false,
        type: 'select',
        maxLength: 50,
        disabled: false,
        value: '', isPrimary: false, styleclass: ' col-md-2'
      },
      {
        field: 'FACILITY_ID',
        title: 'Facility Id',
        required: false,
        type: 'text',
        maxLength: 50,
        disabled: false,
        value: null, isPrimary: false, styleclass: ' col-md-2'
      },
      {
        field: 'CALENDAR_DATE',
        title: 'Calendar Date',
        required: true,
        type: 'date',
        disabled: false,
        value: null, isPrimary: false, styleclass: ' col-md-2'
      }
    ],
    FACILITY_STORAGE_UNITS: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: false,
        type: 'select',
        maxLength: 50,
        value: null, isPrimary: false, styleclass: 'col-md-2'
      },
      {
        field: 'FACILITY_ID',
        title: 'Facility Id',
        required: false,
        type: 'text',
        maxLength: 50,
        value: null, isPrimary: false, styleclass: 'col-md-2'
      },
      {
      field: 'STORAGE_UNIT_ID',
      title: 'Storage Unit Id',
      required: false,
      type: 'text',
      maxLength: 50,
      value: null, isPrimary: false, styleclass: 'col-md-2'
      }
    ]
  },
  fieldFormsTables: {
    CONTAINER_USAGE_TYPE: [
      {
        field: 'CONTAINER_USAGE_TYPE1',
        title: 'Container Usage Type',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'CONTAINER_USAGE_DESC',
        title: 'Container Usage Desc',
        required: true,
        type: 'text-area',
        maxLength: 100,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      }
    ],
    ORGANIZATION: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: true,
        type: 'select',
        maxLength: 50,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'ORG_DESC',
        title: 'Org Desc',
        required: true,
        type: 'text-area',
        maxLength: 100,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'OSN_ORG_ID',
        title: 'OSN Org Id',
        required: false,
        type: 'text',
        maxLength: 50,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      }
    ],
    PRESENTATION_TYPES: [
      {
        field: 'PRESENTATION_TYPE',
        title: 'Presentation Type',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'PRESENTATION_TYPE_DESC',
        title: 'Presentation Type Desc',
        required: true,
        type: 'text-area',
        maxLength: 100,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      }
    ],
    REPLENISH_METHOD_CODES: [
      {
        field: 'REPLENISHMENT_METHOD_CODE',
        title: 'Replenishment Method Code',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'REPLENISHMENT_METHOD_DESC',
        title: 'Replenishment Method Desc',
        required: true,
        type: 'text-area',
        maxLength: 100,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      }
    ],
    SHOP_CALENDAR: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: true,
        type: 'select',
        maxLength: 50,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'FACILITY_ID',
        title: 'Facility Id',
        required: true,
        type: 'text',
        maxLength: 50,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'CALENDAR_DATE',
        title: 'Calendar Date',
        required: true,
        type: 'date',
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'CALENDAR_DATE_FULL_NAME',
        title: 'Calendar Date Full Name',
        required: false,
        type: 'text',
        maxLength: 30,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'WORK_DAY_IND',
        title: 'Work Day Ind',
        required: true,
        type: 'select',
        data: ['Y', 'N'],
        disabled: false,
        maxLength: 1,
        value: null, isPrimary: false, cellClass: 'break-word'
      }
    ],
    STORAGE_UNITS: [
      {
        field: 'STORAGE_UNIT_ID',
        title: 'Storage Unit Id',
        required: true,
        type: 'text',
        maxLength: 30,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },

      {
        field: 'STORAGE_UNIT_DESC',
        title: 'Storage Unit Desc',
        required: false,
        type: 'text',
        maxLength: 100,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },

      {
        field: 'STORAGE_UNIT_TYPE',
        title: 'Storage Unit Type',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },

      {
        field: 'ROLLERS',
        title: 'Rollers',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },

      {
        field: 'ROLLER_HEIGHT',
        title: 'Roller Height',
        required: true,
        type: 'integer',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },

      {
        field: 'ROLLERS_PER_SHELF',
        title: 'Rollers Per Shelf',
        required: true,
        type: 'integer',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },

      {
        field: 'SHELF_HEIGHT',
        title: 'Shelf Height',
        required: true,
        type: 'integer',
        maxLength: 20,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },

      {
        field: 'STD_NBR_PLCMNTS',
        title: 'Std Nbr Plcmnts',
        required: false,
        type: 'text',
        maxLength: 10,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },

      {
        field: 'STD_NBR_BAG_HOOKS_PER_PLCMNTS',
        title: 'Std Nbr Bag Hooks Per Plcmnt',
        required: false,
        type: 'text',
        maxLength: 10,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },

      {
        field: 'UNIT_DIM_UOM',
        title: 'Unit DIM UOM',
        required: false,
        type: 'text',
        maxLength: 10,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'UNIT_HEIGHT',
        title: 'Unit Height',
        required: false,
        type: 'number',
        maxLength: 15,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },

      {
        field: 'UNIT_INNER_WIDTH',
        title: 'Unit Inner Width',
        required: false,
        type: 'number',
        maxLength: 15,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },

      {
        field: 'UNIT_LENGTH',
        title: 'Unit Length',
        required: false,
        type: 'number',
        maxLength: 15,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },

      {
        field: 'UNIT_OUTER_WIDTH',
        title: 'Unit Outer Width',
        required: false,
        type: 'number',
        maxLength: 15,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      }
    ],
    ITEMS: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: true,
        type: 'select',
        maxLength: 50,
        disabled: false,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'ITEM_ID',
        title: 'Item Id',
        required: true,
        type: 'text',
        maxLength: 40,
        disabled: false,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'ITEM_DESC',
        title: 'Item Desc',
        required: false,
        type: 'text-area',
        maxLength: 150,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'ITEM_LENGTH',
        title: 'Item Length',
        required: false,
        type: 'number',
        maxLength: 15,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'ITEM_WIDTH',
        title: 'Item Width',
        required: false,
        type: 'number',
        maxLength: 15,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'ITEM_HEIGHT',
        title: 'Item Height',
        required: false,
        type: 'number',
        maxLength: 15,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'ITEM_WEIGHT',
        title: 'Item Weight',
        required: false,
        type: 'number',
        maxLength: 15,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'ITEM_DIMENSION_UOM',
        title: 'Item Dimension UOM',
        required: false,
        type: 'select',
        data: [],
        maxLength: 10,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'ITEM_WEIGHT_UOM',
        title: 'Item Weight UOM',
        required: false,
        type: 'select',
        data: [],
        maxLength: 10,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'REVISION_NBR',
        title: 'Revision NBR',
        required: false,
        type: 'text',
        maxLength: 50,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      }
    ],
    ITEM_DEMAND: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: true,
        type: 'select',
        maxLength: 100,
        disabled: false,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'ITEM_ID',
        title: 'Item Id',
        required: true,
        type: 'text',
        maxLength: 40,
        disabled: false,
        value: null, isPrimary: true, cellClass: 'break-word'
      },

      {
        field: 'WORK_CENTER_ID',
        title: 'Work Center Id',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: false,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'DEMAND_DATE',
        title: 'Demand Date',
        required: true,
        type: 'date',
        maxLength: 100,
        disabled: true,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'DAILY_DEMAND_QNTY',
        title: 'Daily Demand QTY',
        required: false,
        type: 'integer',
        maxLength: 100,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      }, {
        field: 'MIN_ORDER_QNTY',
        title: 'Min Order QTY',
        required: false,
        type: 'integer',
        maxLength: 50,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'ORDER_MULTI_QNTY',
        title: 'Order Multi QTY',
        required: false,
        type: 'integer',
        maxLength: 50,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'PLANNING_DATE',
        title: 'Planning Date',
        required: false,
        type: 'date',
        maxLength: 10,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },

      {
        field: 'SRC_WORK_CENTER_ID',
        title: 'SRC Work Center Id',
        required: true,
        type: 'text',
        maxLength: 40,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'TASK_ID',
        title: 'Task Id',
        required: false,
        type: 'text',
        maxLength: 30,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },

      {
        field: 'TGT_WORK_CENTER_ID',
        title: 'TGT Work Center Id',
        required: true,
        type: 'text',
        maxLength: 40,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      }
    ],
    MATERIAL_FLOW_PLANS: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: true,
        type: 'select',
        maxLength: 50,
        disabled: false,
        value: '', isPrimary: false, styleclass: ' col-md-2'
      },
      {
        field: 'FACILITY_ID',
        title: 'Facility Id',
        required: true,
        type: 'select',
        maxLength: 50,
        disabled: false,
        value: '', isPrimary: false, styleclass: ' col-md-2'
      },
      {
        field: 'MTRL_FLOW_PLAN_ID',
        title: 'Mtrl Flow Plan Id',
        required: true,
        type: 'text',
        maxLength: 50,
        disabled: false,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'REPLENISHMENT_METHOD_CODE',
        title: 'Replenishment Method Code',
        required: true,
        type: 'text',
        maxLength: 20,
        disabled: false,
        value: null, isPrimary: true, cellClass: 'break-word'
      },
      {
        field: 'MTRL_FLOW_PLAN_DESC',
        title: 'Mtrl Flow Plan Desc',
        required: false,
        type: 'text-area',
        maxLength: 400,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'REPLENISH_CYCLE_BY_DAYS',
        title: 'Replenish Cycle By Days',
        required: false,
        type: 'integer',
        maxLength: 10,
        disabled: false,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'SUPERMARKET_IND',
        title: 'Supermarket Indicator',
        required: false,
        type: 'select',
        data: ['Y', 'N'],
        disabled: false,
        maxLength: 1,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'WAREHOUSE_IND',
        title: 'Warehouse Indicator',
        required: false,
        type: 'select',
        data: ['Y', 'N'],
        disabled: false,
        maxLength: 1,
        value: null, isPrimary: false, cellClass: 'break-word'
      }
    ],
    FACILITY_STORAGE_UNITS: [
      {
        field: 'ORG_ID',
        title: 'Org Id',
        required: true,
        type: 'select',
        maxLength: 50,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
        field: 'FACILITY_ID',
        title: 'Facility Id',
        required: true,
        type: 'select',
        maxLength: 50,
        value: null, isPrimary: false, cellClass: 'break-word'
      },
      {
      field: 'STORAGE_UNIT_ID',
      title: 'Storage Unit Id',
      required: true,
      type: 'select',
      maxLength: 50,
      value: null, isPrimary: false, cellClass: 'break-word'
      },
    ]
  },
};
