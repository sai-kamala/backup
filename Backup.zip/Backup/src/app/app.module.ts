import { BrowserModule } from "@angular/platform-browser";
import { NgModule, ErrorHandler, APP_INITIALIZER } from "@angular/core";
import { RouterModule } from "@angular/router";
import { AppRoutingModule } from "./app-routing.module";
import { NgFlashMessagesModule } from "ng-flash-messages";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
// TODO: remove after prime ng

import { CoreModule } from "./core/core.module";
import { AppComponent } from "./app.component";
import { HeaderComponent } from "./core/header/header.component";
import { NavBarComponent } from "./core/header/nav-bar/nav-bar.component";
import { HomeModule } from "./modules/home/home.module";
import { GlobalErrorHandlerService } from "./core/services/global-error-handler.service";
import { DataTablesModule } from "angular-datatables";
import { AuthService } from "./core/auth/auth.service";
import { ErrorInterceptor } from "./core/auth/unauthorized-interceptor";
import { RequestInterceptor } from "./core/auth/request-interceptor.service";
import { ToastrModule } from "ngx-toastr";
import { DialogModule } from "primeng/dialog";

@NgModule({
  declarations: [AppComponent, HeaderComponent, NavBarComponent],
  imports: [
    HomeModule,
    BrowserModule,
    HttpClientModule,
    CoreModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    BsDatepickerModule.forRoot(),
    ToastrModule.forRoot({
      preventDuplicates: true,
      closeButton: true,
      disableTimeOut: true
    }),
    DataTablesModule,
    BrowserAnimationsModule,
    DialogModule
  ],
  providers: [
    /* GlobalErrorHandlerService,
    {
      provide: ErrorHandler,
      useClass: GlobalErrorHandlerService
    }, */
    AuthService,
    {
      provide: APP_INITIALIZER,
      useFactory: (auth: AuthService) =>
        async function () {
          return await auth.load();
        },
      deps: [AuthService],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: RequestInterceptor,
      multi: true
    }
    // { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
