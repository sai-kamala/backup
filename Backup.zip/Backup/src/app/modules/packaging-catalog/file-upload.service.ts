import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpErrorResponse, HttpHeaders, HttpEventType } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';

const httpHeaders = {
    headers: new HttpHeaders({
        'Access-Control-Allow-Origin': '*'
    })
}

@Injectable({
    providedIn: 'root'
})
export class FileUploadService {
    baseUrl = environment.api
    constructor(private http: HttpClient) { }

    uploadFiles = (formDataValue, progressCb) => {
        this.http.post(`${this.baseUrl}Upload/File`, formDataValue, {
            ...httpHeaders,
            reportProgress: true,
            observe: 'events'
        }).subscribe(e => {
            function errorFn(error) {
                const errorRes = {
                    "Maximum request length exceeded.": 'Maximum file size limit exceeded'
                }
                progressCb('error', '', errorRes[error.statusText] || error.statusText)
            }

            if (e instanceof Observable) {
                e.subscribe({error: errorFn});
            } else if (e instanceof HttpResponse) {
                progressCb('complete', 100, e.body);
            } 
        })
    }
}
