import { Component, OnInit, Input, ViewChild } from '@angular/core';
import * as constants from './constants';
import { WorkCenterService } from './work-center-plans.service';
import { SharedService } from './../../shared/services/share.service';
import { PartsGridComponent } from './parts-grid/parts-grid.component';
import { CopyPlansComponent } from './copy-plans/copy-plans.component';
import { CoreServices } from 'src/app/core/services/core.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'pfep-work-center-plans',
    templateUrl: './work-center-plans.component.html',
    styleUrls: ['./work-center-plans.component.scss']
})
export class WorkCenterPlansComponent implements OnInit {
    tableFields: any;
    workCenter: any;
    getArchivedRecords = false;
    archiveStatus = false;
    gridData: any = [];
    editedRecData = {};
    loading = false;
    workCenterId: any;
    fromDate: Date;
    toDate: Date;
    itemFlowData: any;
    disableSave = true;
    tabledropDowndata: any[] = [];
    dataOpened: any = { itemPlanRequest: {} };
    isFromItemFlow = false;
    showCopyPlansPopup = false;
    fieldsEmpty: Array<string> = [];
    defaultselecteddropDownValue = { FIELD_NAME: 'WORK_CENTER_ID' };
    rowsSelectedForCopy = [];
    currentSearchCriteria: any = {};
    Object = Object;

    @Input() isEditable: Boolean;
    @ViewChild(PartsGridComponent) partsGridComponent;
    @ViewChild(CopyPlansComponent) copyPlansComponent;

    constructor(
        public coreService: CoreServices,
        public workCenterService: WorkCenterService,
        public sharedService: SharedService,
        private route: ActivatedRoute,
        public router: Router,
    ) { }
    ngOnInit() {
        this.isFromItemFlow = false;
        const routeRoles = this.route.snapshot.data.roles;
        this.workCenterService.setEditAccess(this.coreService.checkAccess(routeRoles));
        this.isEditable = this.workCenterService.getEditAccess();
        this.tableFields = constants.workCenterPlansTableFields;
        this.subscribeToRouteSubject();

        this.workCenter = {
            serviceUrl: {
                dropdown: 'WildcardSearch/GetFields?fieldName=WORK_CENTER_ID',
                table: 'WildcardSearch/GetDropdownValuesWorkCenter'
            },
            tableFields: [
                { header: 'ID', field: 'WORK_CENTER_ID' },
                { header: 'Description', field: 'WORK_CENTER_DESC' }
            ],
            label: '',
            isMultiSelect: false,
            selectedData: '',
            options: '',
            modelName: 'WORK_CENTER_ID',
            styleclass: 'col-md-2'
        };

        this.itemFlowData = this.sharedService.getPouData();
        this.sharedService.setPouData({});
        if (Object.keys(this.itemFlowData).length > 0) {
            this.isFromItemFlow = true;
            this.onLoadDataFromItemFlow(this.itemFlowData);
        }
    }

    async onLoadDataFromItemFlow(data) {
        this.gridData = await this.workCenterService
            .onLoadDataFromItemFlow(data)
            .toPromise();
    }

    subscribeToRouteSubject = () => {
        this.sharedService.getRouteAttachedSubject().subscribe(screenData => {
            if (screenData === 'work-center-plans') {
                this.routeAttached();
            }
        });
    }

    workCenterChangeEvent(event) {
        this.workCenterId = event.selectedData;
    }

    itemDetailFn = data => {
        this.dataOpened = {
            ...data,
            scrollTopPosition: this.getTableScrollPosition(),
            scrollLeftPosition: this.getTableScrollLeftPosition()
        };
        // if (!this.isFromItemFlow) { this.dataOpened[constants.workCenterId] =  this.workCenterId; }
        this.sharedService.setItemPlanIp({
            ...this.dataOpened.itemPlanRequest
        });
        this.router.navigate(['/item-plan-detail']);
    }
    singleRackNavigationFn = data => {
        this.dataOpened = {
            scrollTopPosition: this.getTableScrollPosition(),
            scrollLeftPosition: this.getTableScrollLeftPosition()
        };
        this.sharedService.setSingleRackIp(data);
        this.router.navigate(['/pou/single-rack']);
    }

    getTableScrollPosition = () => this.getTableScrollableDivs()[0].scrollTop;

    getTableScrollableDivs = () =>
        document.querySelectorAll('.ui-table-scrollable-body')

    setTableScrollPosition = () => {
        const tableScrollableDivs = this.getTableScrollableDivs();
        for (let i = 0; i < tableScrollableDivs.length; i++) {
            tableScrollableDivs[
                i
            ].scrollTop = this.dataOpened.scrollTopPosition;
        }
    }

    addScrollListener = () => {
        const tblElem = this.getTableLeftScrollableDivs();
        if (tblElem) {
            tblElem.removeEventListener('scroll', () => { });
            tblElem.addEventListener('scroll', () => {
                if (!tblElem.scrollLeft) {
                    const elem = <HTMLElement>document.querySelectorAll('.ui-table-scrollable-header-box')[1];
                    elem.style.marginLeft = '0';
                }
            });
        }
    }

    getTableScrollLeftPosition = () => this.getTableLeftScrollableDivs().scrollLeft;

    getTableLeftScrollableDivs = () =>
        document.querySelectorAll('.ui-table-scrollable-body')[1]

    setTableLeftScrollPosition = () => {
        this.getTableLeftScrollableDivs().scrollLeft = this.dataOpened.scrollLeftPosition;
    }

    archiveChanged = e => {
        this.fromDate = null;
        this.toDate = null;
    }

    checkForInvalid = () => {
        this.fieldsEmpty = [];
        if (!this.workCenterId) {
            this.fieldsEmpty.push('workCenter');
        }
    }

    getOnSearchGridData() {
        this.checkForInvalid();
        if (this.fieldsEmpty.length === 0) {
            this.loading = true;
            this.tableFields.forEach(data => {
                if (data.type === 'dropdown') {
                    this.tabledropDowndata.push(data.field);
                }
            });
            if (this.archiveStatus === true) {
                this.currentSearchCriteria = {
                    archiveStatus: true,
                    criteria: [this.workCenterId, this.archiveStatus, this.fromDate, this.toDate]
                };
                this.workCenterService
                    .searchUsingItemPlanStatus(
                        this.workCenterId,
                        this.archiveStatus,
                        this.fromDate,
                        this.toDate
                    )
                    .subscribe(res => {
                        if (res) {
                            this.gridData = res;
                        } else {
                            this.workCenterService.displayMessage(
                                'danger',
                                res['statusText']
                            );
                        }
                        this.loading = false;
                    });
            } else {
                this.currentSearchCriteria = {
                    archiveStatus: false,
                    criteria: [this.workCenterId]
                };
                this.workCenterService
                    .onSearchGridDataWithWorkCenter(this.workCenterId)
                    .subscribe(res => {
                        if (res.status === 200) {
                            this.gridData = res.body;
                            // this.gridData = [...this.gridData,...this.gridData,...this.gridData,...this.gridData, ...this.gridData]
                        } else {
                            this.workCenterService.displayMessage(
                                'danger',
                                res.statusText
                            );
                        }
                        this.loading = false;
                    });
            }
        }
        // this.addScrollListener();
    }

    saveEditedData = () => {
        this.workCenterService
            .saveEditedGridData(Object.values(this.editedRecData))
            .subscribe(res => {
                if (res.status === 200) {
                    this.workCenterService.displayMessage(
                        'success',
                        constants.saveSuccessMessage
                    );
                } else {
                    this.workCenterService.displayMessage(
                        'danger',
                        res.statusText
                    );
                }
            });
        this.editedRecData = {};
        this.disableSave = true;
    }

    updateRowData = rowData => {
        const index = this.partsGridComponent.getIndex(
            this.gridData,
            rowData,
            this.dataOpened.itemPlanRequest.planIdFromParent ? false : true
        );

        // this.gridData[index] = {...rowData};
        this.partsGridComponent.updateRow(
            { ...rowData },
            index,
            this.dataOpened.itemPlanRequest.planIdFromParent ? false : true
        );
        this.setTableScrollPosition();
        this.setTableLeftScrollPosition();
    }

    rowsSubmittedForCopy = rows => {
        this.copyPlansComponent.currentStep = 0;
        this.showCopyPlansPopup = true;
        this.rowsSelectedForCopy = [...rows];
    }

    copyCancelled = () => {
        this.showCopyPlansPopup = false;
        this.partsGridComponent.copyCancelled();
    }

    workCenterInCopyPlans = wC => {
        this.showCopyPlansPopup = false;
        this.workCenter = { ...this.workCenter, selectedData: wC };
        this.workCenterChangeEvent({ selectedData: wC });
        this.getOnSearchGridData();
    }

    itemPlanIdInCopyPlans = data => {
        this.showCopyPlansPopup = false;
        setTimeout(() => this.itemDetailFn(data), 10);
    }

    routeAttached = () => {
        const postData = { ...this.sharedService.getCbReqData()['data'] };
        this.sharedService.setCbReqData({});
        if (Object.keys(postData).length > 0) {
            this.workCenterService.getRowUpdate(postData).subscribe(res => {
                if (res.status === 200 && res.body) {
                    this.updateRowData(res.body);
                } else {
                    this.workCenterService.displayMessage(
                        'danger',
                        'Failed to update details. Please refresh to see latest data'
                    );
                }
            });
        } else if (this.dataOpened.scrollTopPosition || this.dataOpened.scrollLeftPosition) {
            setTimeout(() => {
                this.setTableScrollPosition();
                this.setTableLeftScrollPosition();
            });
        }
    }

    exportExcel = () => {
        this.coreService.showLoader();
        if (this.currentSearchCriteria.archiveStatus === true) {
            this.workCenterService
                .downloadExcelWithItemPlanStatus(
                    this.workCenterId,
                    this.archiveStatus,
                    this.fromDate,
                    this.toDate
                )
                .subscribe(res => this.downloadFile(res));
        } else {
            this.workCenterService
                .downloadExcelWithWorkCenter(this.workCenterId)
                .subscribe(res => this.downloadFile(res));
        }

    }

    downloadFile = res => {
        if (res['StatusType'] === 'SUCCESS') {
            window.open(res['FilePath'], '_blank');
        } else {
            this.workCenterService.displayMessage(
                'danger',
                res['statusText']
            );
        }
        this.coreService.hideLoader();
    }
}
