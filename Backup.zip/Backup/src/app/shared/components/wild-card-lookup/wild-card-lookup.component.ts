import { Component, OnInit, OnChanges, Input, Output, EventEmitter, OnDestroy, ViewEncapsulation } from '@angular/core';
import { SharedService } from '../../services/share.service';
import { Observable } from 'rxjs';
import { CoreServices } from 'src/app/core/services/core.service';

@Component({
  selector: 'pfep-wild-card-lookup',
  templateUrl: './wild-card-lookup.component.html',
  styleUrls: ['./wild-card-lookup.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class WildCardLookupComponent implements OnInit, OnChanges, OnDestroy {
  @Input() config;
  @Output() changeEvent = new EventEmitter();
  @Input() showInvalid: boolean = false;
  @Input() selectEntireRecord: boolean = false;
  displayDialog = false;
  optionsList: any;
  selectedOptionValue: any;
  @Input() defaultselecteddropDownValue: any;
  @Input() modalClass: string = '';
  lookUpKey = '';
  tableData: any;
  columns: any;
  selectedTableData: any = [];
  selectedOptions: any;
  disableCal = false;
  invalidLookUp = false;
  lookUpKeyChange = false;
  constructor(public sharedService: SharedService, public coreService: CoreServices) { }

  ngOnInit() {
    this.columns = (this.config['tableFields']) ? this.config['tableFields'] : [{ header: 'ID', field: this.config['modelName'] }];
    this.selectedOptions = (this.config.isMultiSelect) ? [] : '';

    if (this.config.isMultiSelect && this.config.selectedData && this.config.selectedData.length > 0) {
      this.config.options = [...this.config.selectedData];
      this.selectedOptions = [...this.config.selectedData];
    } else {
      this.selectedOptions = this.config.selectedData;
    }
  }
  ngOnDestroy() {
    this.disableCal = true;
  }
  ngOnChanges(changes) {
    if (this.config.isMultiSelect && changes.config) {
      if (this.selectedOptions && this.selectedOptions.sort().join('^') !== changes.config.currentValue.selectedData.sort().join('^')) {
        this.selectedOptions = [...changes.config.currentValue.selectedData];
        this.changeEvent.emit({ ...this.config, selectedData: changes.config.currentValue.selectedData });
      } else {
        this.selectedOptions = [...changes.config.currentValue.selectedData];
        this.changeEvent.emit({ ...this.config, selectedData: changes.config.currentValue.selectedData });
      }
    } else {
      if (changes.config && this.selectedOptions !== changes.config.currentValue.selectedData) {
        this.selectedOptions = changes.config.currentValue.selectedData;
        this.changeEvent.emit({ ...this.config, selectedData: changes.config.currentValue.selectedData });
      }
    }

    // this.selectedTableData = [...this.config.options];

  }

  showDialog = e => {
    e.preventDefault();
    this.displayDialog = true;
    this.lookUpKey = '';
    this.selectedOptionValue = this.defaultselecteddropDownValue['FIELD_NAME'] ? JSON.parse(JSON.stringify(this.defaultselecteddropDownValue['FIELD_NAME'])) : '';
    this.coreService.showLoader();
    this.sharedService.getWildCardDropDownValues(this.config.serviceUrl.dropdown)
      .subscribe(data => {
        this.optionsList = data;
        this.coreService.hideLoader();
      });
  }

  changeSearchBy(event) {
    this.selectedOptionValue = event['FIELD_NAME'];
    this.tableData = false;
    this.lookUpKey = '';
    if (this.config.modelName === event['FIELD_NAME']) {
      this.lookUpKeyChange = false;
    } else if (this.config.dependentData && this.config.dependentData[event['FIELD_NAME']] !== '') {
      this.lookUpKeyChange = true;
      this.lookUpKey = this.config.dependentData[event['FIELD_NAME']];
    } else {
      this.lookUpKeyChange = false;
    }
    if (this.config.dependentData && this.config.dependentData['FACILITY_ID'] && event['FIELD_NAME'] === 'ORG_ID') {
      this.lookUpKeyChange = true;
    }

  }

  constructPostObject(post) {
    this.optionsList.forEach(element => {
      post[element.FIELD_NAME] = (this.config.dependentData && this.config.dependentData[element.FIELD_NAME]) ? this.config.dependentData[element.FIELD_NAME] : null;
    });
    for (const key in this.config.dependentData) {
      if (!post[key]) {
        post[key] = this.config.dependentData[key];
      }
    }
    if (this.selectedOptionValue !== undefined) {
      post[this.selectedOptionValue] = this.lookUpKey;
    }
    return post;
  }

  getWildCardTable(postData) {
    this.coreService.showLoader();
    this.sharedService.getWildCardTableData(this.config.serviceUrl.table, postData)
      .subscribe(data => {
        this.tableData = data;
        this.selectedTableData = this.config.selectedData;
        this.coreService.hideLoader();
      });
  }

  getTableData(event) {
    event.returnValue = false;
    event.cancelBubble = true;
    // event.stopPropagation();
    event.preventDefault();

    if (this.selectedOptionValue !== '' && this.lookUpKey !== '') {
      this.invalidLookUp = false;
      const post = { IS_SHOW_ALL: false };
      const postData = this.constructPostObject(post);
      this.getWildCardTable(postData);
    } else {
      this.invalidLookUp = true;
    }
  }

  showAll = e => {
    e.preventDefault();
    const post = { IS_SHOW_ALL: true };
    const postData = this.constructPostObject(post);
    this.getWildCardTable(postData);
  }

  removeArrayDuplicates(arr, key) {
    return arr.reduce((unique, o) => {
      if (!unique.some(obj => obj[key] === o[key])) {
        unique.push({ [key]: o[key] });
      }
      return unique;
    }, []);
  }
  onRowSelect(event) {
    if (this.config.isMultiSelect) {
      this.selectedTableData.push(event.data);
      this.selectedOptions.push(event.data);
    } else {
      this.selectedTableData = event.data;
    }
  }
  onRowUnselect(event) {
    if (event.data && this.selectedOptions.length) {
      let idx = this.selectedOptions.findIndex(opt => event.data[this.config['modelName']] === opt[this.config['modelName']]);
      this.selectedOptions.splice(idx, 1);
      idx = this.config.options.findIndex(opt => event.data[this.config['modelName']] === opt[this.config['modelName']]);
      this.config.options.splice(idx, 1);
      idx = this.selectedTableData.findIndex(opt => event.data[this.config['modelName']] === opt[this.config['modelName']]);
      this.selectedTableData.splice(idx, 1);
    }

  }



  ddChanged = e => {
    this.changeEvent.emit({ ...this.config, selectedData: this.selectedOptions });
  }


  close() {
    this.displayDialog = false;
  }

  done() {
    if (this.config.isMultiSelect) {
      this.selectedTableData.forEach(element => {
        this.config['options'].push(element);
      });
      this.selectedOptions = this.removeArrayDuplicates(this.selectedOptions, this.config['modelName']);
      this.config['options'] = this.removeArrayDuplicates(this.config['options'], this.config['modelName']);
    } else {
      this.selectedOptions = this.selectedTableData[this.config.modelName];
    }
    this.displayDialog = false;
    this.changeEvent.emit({ ...this.config, selectedData: (this.selectEntireRecord && !this.config.isMultiSelect) ? this.selectedTableData : this.selectedOptions });
  }

  singleSelectChange() {
    this.changeEvent.emit({ ...this.config, selectedData: this.selectedOptions });
  }

  hideDialog() {
    this.lookUpKeyChange = false;
    this.tableData = false;
  }
  onSelect(event) {
    if (this.config.isMultiSelect) {
      this.selectedTableData = event;
      this.selectedOptions = event;
    }
  }

  checked(e) {
    e.stopPropagation();
  }
}
