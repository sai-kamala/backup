import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
//import { packaging_catalog } from "./packaging_catalog";
import { Observable, of, BehaviorSubject } from "rxjs";
import { Content } from "@angular/compiler/src/render3/r3_ast";
import { environment } from "src/environments/environment";

const httpOptions = {
  headers: new HttpHeaders({
    "Content-Type": "application/json"
  })
};

@Injectable({
  providedIn: "root"
})
export class PackagingCatalogService {
  private baseUrl: string = environment.api;
  constructor(private http: HttpClient) { }
  defaultRowData: object;
  private messageSource = new BehaviorSubject(this.defaultRowData);
  currentMessage = this.messageSource.asObservable();
  tableSearch: any;
  editContainerId: any;

  containerCategoryListUrl =
    `${this.baseUrl}PackageCatalog/GetContainerCategoryList`;
  containerListUrl =
    `${this.baseUrl}PackageCatalog/GetContainerList`;
  gridRowDetailsUrl =
    `${this.baseUrl}PackageCatalog/GetContainerDetails`;
  saveNewContainerUrl =
    `${this.baseUrl}PackageCatalog/SaveContainerDetails`;
  createNewDropDownListsUrl =
    `${this.baseUrl}PackageCatalog/GetAllLists`;
  containerUsageTypeListUrl = `${this.baseUrl}PackageCatalog/GetContainerUsageTypeList`;
  getContainerListBasedOnSearchUrl = `${this.baseUrl}PackageCatalog/GetContainerList`;
  getContainerUOmList = `${this.baseUrl}PackageCatalog/GetContainerUOMList`;
  getOrgIdsUrl = `${this.baseUrl}PackageCatalog/GetORGList`

  setParamForEdit = param => (this.editContainerId = param)
  getParamForEdit = () => this.editContainerId;

  getContainerListBasedOnSearch(searchData) {
    return this.http.post<any>(this.getContainerListBasedOnSearchUrl, searchData);
  }

  getDropDownLists() {
    return this.http.get<any[]>(this.createNewDropDownListsUrl);
  }
  getImages() {
    return this.http.get<any[]>('src/app/modules/packaging-catalog/edit-packaging-catalog-details/constants.json');
  }

  getContainerCategory() {
    return this.http.get<any[]>(this.containerCategoryListUrl);
  }

  getContainerUsageType() {
    return this.http.get<any[]>(this.containerUsageTypeListUrl);
  }


  getContaienrUOMList = () => this.http.get<any[]>(this.getContainerUOmList)

  //getOrgIdsList = () => this.http.get<any[]>(this.getOrgIdsUrl);

  getSegmentsByUserId(): Observable<any> {
    return this.http.get(`${this.baseUrl}Common/GetSegmentsByUserId`);
  }

  getContainerList(data): Observable<any> {
    let json = JSON.stringify(data);
    return this.http.post(this.containerListUrl, data, httpOptions);
  }

  saveContainerDetails(data) {
    let dataJson = JSON.stringify(data);
    return this.http.post(this.saveNewContainerUrl, dataJson, {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Accept: "application/json"
      })
    });
  }

  appendRowData(rowData: object) {
    return this.messageSource.next(rowData);
  }

  getGridRoWDetails(id: any) {
    return this.http.get(
      this.gridRowDetailsUrl + "?" + "containerID=" + id,
      httpOptions
    );
  }

  checkValidInput(data) {
    return (data !== null && data !== undefined && data !== "") ? true : false;
  }

  deleteUploadedFiles(id) {
    return this.http.post(`${this.baseUrl}PackageCatalog/DeleteUploadFiles`, id)
  }

  getSearchFieldData = (value, OrgId) => {
    return this.http.get(`${this.baseUrl}WildcardSearch/GetSupplier?Value=${value}&OrgId=${OrgId}`);
  }

}