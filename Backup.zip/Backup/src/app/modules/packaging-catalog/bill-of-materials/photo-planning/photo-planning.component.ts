import { Component, OnInit, OnChanges, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import * as constants from '../constants';

@Component({
  selector: 'pfep-photo-planning',
  templateUrl: './photo-planning.component.html',
  styleUrls: ['./photo-planning.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PhotoPlanningComponent implements OnInit, OnChanges {
  @Input() photoPlanning = [];
  @Input() containerSID = '';
  @Input() isNew = true;
  @Output() edited = new EventEmitter();

  Object = Object;
  tabsList: Array<any> = [];
  selectedTab: any = {};
  deletedFiles = [];
  totalFiles: object = {};
  uploadedFiles: object = {};
  tabName = constants.tabName;
  photoUrl = constants.photoUrl;
  defaultTab = constants.defaultTab;
  tempTabNames = {};
  isTabNameRequired: boolean = false;
  showTabNamesList: boolean = false;
  tabNames = [];

  constructor() { }

  ngOnInit() {
    this.buildFilesArray(this.photoPlanning);
  }

  ngOnChanges(changes) {
    if (changes.photoPlanning) {
      this.buildFilesArray([...changes.photoPlanning.currentValue]);
    }
  }

  setTabs = filesArr => {
    this.tabsList = [];
    if (filesArr) {
      filesArr.forEach(rec => {
        if (rec[constants.tabName]) {
          this.tabsList.push({ displayName: rec[constants.tabName], value: rec[constants.tabName], class: 'bom-img-path', defaultTab: rec, imgExtension: '' });
          this.tabNames.push(rec[constants.tabName]);
          if (rec[constants.defaultTab]) {
            this.selectedTab = { ...rec };
            this.setImageBg();
          }
        }
      });
    }
    if (!this.selectedTab[constants.tabName]) {
      this.selectedTab = { ...filesArr[0] };
      this.setImageBg();
    }
  }

  buildFilesArray = (photoplanning) => {
    this.resetPhotoPlanning();
    let i = 0;

    //setting object with indexes as keys and files without a tab as others like {0: {tabInfo}, 1: {tabInfo}, 'others': {tabInfo}}
    [...photoplanning].forEach(rec => {
      if (rec[constants.tabName]) {
        this.totalFiles[i] = { ...rec };
        this.tabNames.push(rec[constants.tabName]);
        i++;
      } else {
        this.totalFiles['others'].push({ ...rec });
      }
    });
    if (Object.keys(this.totalFiles).length < 6) {
      this.createTempTabs();
    }
    this.setTabs(Object.values(this.totalFiles));
  }

  createTempTabs = () => {
    const tempTabsCreated = [];
    // adding 1 beacuse of 'other' key
    const tabsToCreate = 5 - Object.values(this.totalFiles).length + 1;

    let i = 1;
    while (tempTabsCreated.length < tabsToCreate) {
      if (!this.tabNames.includes(`Pic ${i}`)) {
        tempTabsCreated.push(`Pic ${i}`);
      }
      i++;
    }

    for (let i = tabsToCreate; i >= 0; i--) {
      if (this.totalFiles['others'][0]) {
        this.totalFiles[5 - i] = { ...constants.fileDataSkeleton, ...this.totalFiles['others'][0], [constants.tabName]: tempTabsCreated[tabsToCreate - i] };
        this.totalFiles['others'].splice(0, 1);
      } else {
        this.totalFiles[5 - i] = { ...{}, ...constants.fileDataSkeleton, [constants.tabName]: tempTabsCreated[tabsToCreate - i] };
      }
    }
  }

  resetPhotoPlanning = () => {
    this.totalFiles = { 'others': [] };
    this.tabNames = [];
    this.selectedTab = {};
    this.uploadedFiles = {};
    this.tempTabNames = {};
    this.tabsList = [];
    this.deletedFiles = [];
  }

  isImage = url => {
    const ext = url.toLowerCase().split('.');
    return (constants.imageExtensions.includes(ext[ext.length - 1]));
  }

  setSelectedTab = tab => {
    this.tabsList.forEach(rec => {
      if (rec[constants.tabName] === tab) {
        rec.defaultTab = true;
      }
    });
    this.tabsList = [...this.tabsList];

    for (const idx in this.totalFiles) {
      if (idx !== 'others' && this.totalFiles[idx][constants.tabName] === tab) {
        this.selectedTab = { ...this.totalFiles[idx] };
        this.setImageBg();
      }
    }
  }

  onTabClick = tab => {
    this.setSelectedTab(tab);
  }

  setDefaultTab = () => {
    for (const idx in this.totalFiles) {
      if (idx !== 'others') {
        this.totalFiles[idx][constants.defaultTab] = false;
      }
      if (idx !== 'others' && this.totalFiles[idx][constants.tabName] === this.selectedTab[constants.tabName]) {
        this.totalFiles[idx][constants.defaultTab] = true;
        this.selectedTab = { ...this.totalFiles[idx] };
        this.setImageBg();
      }
    }
    this.edited.emit();
  }

  editTabNames = () => {

  }

  tabValueChange = (e, idx) => {
    e.stopPropagation();
    const value = e.target.value.trim();
    if (e.key === 'Enter') {
      this.saveTabNames();
      return;
    }
    this.tempTabNames[idx] = value.trim();
  }

  saveTabNames = () => {
    let isTabNameRequired = false;
    for (const i in this.tempTabNames) {
      if (isTabNameRequired && this.isEmpty(this.tempTabNames[i])) {
        isTabNameRequired = true;
      }
    }
    if (!isTabNameRequired) {
      for (const idx in this.tempTabNames) {
        if (this.selectedTab[constants.tabName] === this.totalFiles[idx][constants.tabName]) {
          this.selectedTab[constants.tabName] = this.tempTabNames[idx];
        }
        this.tabsList[idx] = { ...this.tabsList[idx], displayName: this.tempTabNames[idx], value: this.tempTabNames[idx] };
        this.totalFiles[idx] = { ...this.totalFiles[idx], [constants.tabName]: this.tempTabNames[idx], isEdited: true }
      }
      this.edited.emit();
      this.showTabNamesList = false;
    }
  }

  deleteImage = () => {
    this.selectedTab = { ...this.selectedTab, [constants.photoUrl]: '', bgImgPath: '' };
    if (this.selectedTab[constants.photoSID]) {
      this.deletedFiles.push(this.selectedTab[constants.photoSID]);
    }
    for (const idx in this.totalFiles) {
      if (this.totalFiles[idx][constants.tabName] === this.selectedTab[constants.tabName]) {
        this.totalFiles[idx] = { ...this.totalFiles[idx], [constants.photoUrl]: '', 'imgDeleted': true, 'newImage': false };
      }
    }
  }

  deleteBOM = () => {
    for (const idx in this.totalFiles) {
      this.totalFiles[idx] = { ...this.totalFiles[idx], 'imgDeleted': true };
    }
  }

  uploadFiles = (e, type) => {
    const { files } = e.target;
    this.edited.emit();
    if (type === 'images') {
      Object.keys(this.totalFiles).forEach(idx => {
        if (this.totalFiles[idx][constants.tabName] === this.selectedTab[constants.tabName]) {
          const presentimg = this.totalFiles[idx][constants.photoUrl];
          this.totalFiles[idx] = { ...this.totalFiles[idx], [constants.ctrSID]: this.containerSID, [constants.photoUrl]: files[0], 'imgDeleted': false };
          this.uploadFiles[idx] = { ...this.totalFiles[idx], [constants.ctrSID]: this.containerSID, [constants.photoUrl]: files[0], 'imgDeleted': false };
          if (!this.isEmpty(presentimg)) {
            this.totalFiles['others'].push({ ...constants.fileDataSkeleton, [constants.ctrSID]: this.containerSID, [constants.photoUrl]: presentimg });
            this.totalFiles[idx] = { ...this.totalFiles[idx], 'imgDeleted': true };
          }
          for (let i = 1; i < files.length; i++) {
            this.totalFiles['others'].push({ ...constants.fileDataSkeleton, [constants.ctrSID]: this.containerSID, [constants.photoUrl]: files[i] });
            this.uploadFiles['others'].push({ ...constants.fileDataSkeleton, [constants.ctrSID]: this.containerSID, [constants.photoUrl]: files[i] });
          }
          this.totalFiles[idx] = { ...this.totalFiles[idx], 'isEdited': true, 'newImage': true };
          this.selectedTab = { ...this.totalFiles[idx] };
          this.setImageBg();
        }
      });
    }
  }

  setImageBg = () => {
    if (!this.isEmpty(this.selectedTab[constants.photoUrl])) {
      if ((typeof this.selectedTab[constants.photoUrl] !== 'string')) {
        const reader = new FileReader();
        if (this.selectedTab[constants.photoUrl]) {
          reader.readAsDataURL(this.selectedTab[constants.photoUrl]);
        }
        reader.onloadend = () => {
          this.selectedTab.bgImgPath = reader.result;
        }
      } else {
        this.selectedTab.bgImgPath = this.selectedTab[constants.photoUrl];
      }
    }
  }

  getPhotoPlanningData = () => {
    const photoPlannings = [];
    Object.keys(this.totalFiles).forEach(idx => {
      if (idx !== 'others' && this.checkIfTabHasValue(this.totalFiles[idx])) {
        photoPlannings.push(this.totalFiles[idx]);
      }
    });

    return [...photoPlannings];
  }
  checkIfTabHasValue = rec => {
    if (!this.isEmpty(rec[constants.photoUrl]) || !this.isEmpty(rec[constants.photoSID]) || rec[constants.defaultTab]) {
      return true;
    }

    return false;
  }

  isEmpty = val => [null, undefined, ''].indexOf(val) > -1;

}
