import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatatablePCComponent } from './datatable-pc.component';

describe('DatatablePCComponent', () => {
  let component: DatatablePCComponent;
  let fixture: ComponentFixture<DatatablePCComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatatablePCComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatatablePCComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
