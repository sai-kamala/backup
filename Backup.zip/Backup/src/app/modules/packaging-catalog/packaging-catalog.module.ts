import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PackagingCatalogRoutingModule } from './packaging-catalog-routing.module';
import { PackagingCatalogComponent } from './packaging-catalog.component';
import { EditPackagingCatalogDetailsComponent } from './edit-packaging-catalog-details/edit-packaging-catalog-details.component';
import { DatatablePCComponent } from './datatable-pc/datatable-pc.component';
import { BillOfMaterialsComponent } from './bill-of-materials/bill-of-materials.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { InputMaskModule } from 'primeng/inputmask';
import { CalendarModule } from 'primeng/calendar';
import { DialogModule } from 'primeng/dialog';
import { PaginatorModule } from 'primeng/paginator';
import { ProgressBarModule } from 'primeng/progressbar';
import { MultiSelectModule } from 'primeng/multiselect';
import { TooltipModule } from 'primeng/tooltip';
import { DatePipe } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DirectivesModule } from 'src/app/shared/directives/directives.module';
import { SharedModule } from '../../shared/shared.module';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { PhotoPlanningComponent } from './bill-of-materials/photo-planning/photo-planning.component';

@NgModule({
  imports: [
    CommonModule,
    PackagingCatalogRoutingModule,
    ReactiveFormsModule,
    TableModule,
    DropdownModule,
    InputMaskModule,
    CalendarModule,
    DialogModule,
    PaginatorModule,
    ProgressBarModule,
    TooltipModule,
    NgbModule,
    DirectivesModule,
    MultiSelectModule,
    SharedModule,
    ConfirmDialogModule,
    BsDatepickerModule.forRoot()
  ],
  providers: [DatePipe, ConfirmationService],
  declarations: [PackagingCatalogComponent, EditPackagingCatalogDetailsComponent, DatatablePCComponent, BillOfMaterialsComponent, PhotoPlanningComponent],
})
export class PackagingCatalogModule { }
