import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

class TabList {
  displayName: String;
  value: String;
  class: String;
}

@Component({
  selector: 'pfep-tab-list',
  templateUrl: './tab-list.component.html',
  styleUrls: ['./tab-list.component.scss']
})
export class TabListComponent implements OnInit {

  @Input() className: String;
  @Input() tabs: Array<TabList>;
  @Input() selectedTab: String;
  @Input() toolTipExist: Boolean;
  @Output() callBack = new EventEmitter();

  constructor() {
  }

  ngOnInit() {
    if (!this.selectedTab) this.selectedTab = this.tabs[0]['value'];
  }

  ngOnChanges(changes) {
    this.setSelectedTab();
  }

  setSelectedTab = () => {
    this.selectedTab = this.tabs.find(tab => tab['value'] === this.selectedTab)['value'];
  }

  onTabClick = val => {
    this.selectedTab = val;
    this.callBack.emit(val);
  }


}
