import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { InputMaskModule } from 'primeng/inputmask';
import { CalendarModule } from 'primeng/calendar';
import { DialogModule } from 'primeng/dialog';
import { PaginatorModule } from 'primeng/paginator';
import { ProgressBarModule } from 'primeng/progressbar';
import { TooltipModule } from 'primeng/tooltip';

import { MasterDataRoutingModule } from './master-data-routing.module';
import { MasterDataComponent } from './master-data.component';
import { MasterdataService } from './master-data.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



// shared components
import { SharedModule } from '../../shared/shared.module';
import { MasterdataTableFormsComponent } from './masterdata-table-forms/masterdata-table-forms.component';
import { DirectivesModule } from 'src/app/shared/directives/directives.module';


@NgModule({
  imports: [
    CommonModule,
    MasterDataRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    CalendarModule,
    TableModule,
    DropdownModule,
    InputMaskModule,
    DirectivesModule,
    DialogModule,
    PaginatorModule,
    ProgressBarModule,
    TooltipModule
  ],
  declarations: [
    MasterDataComponent,
    MasterdataTableFormsComponent
  ],
  providers: [
    MasterdataService
  ]
})
export class MasterDataModule {
  constructor() {
    console.log('master data module');
  }
}
