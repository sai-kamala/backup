export const environment = {
  production: true,
  api: 'https://entpfepp01/pfepService/api/',
  authUser: 'https://entpfepp01/pfepService/api/User/Get',
  authToken: 'https://entpfepp01/pfepService/Token'
};
