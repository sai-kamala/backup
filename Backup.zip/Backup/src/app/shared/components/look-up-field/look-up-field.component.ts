import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  ViewChildren,
  QueryList
} from '@angular/core';
import tableConstants from './look-table-fields.constants';
import { tableFields } from './look-table-fields.constants';
import { Table, ContextMenuRow } from 'primeng/table';
import { DemandDashboardUtilService } from './../../../modules/demand-dashboard/demand-dashboard.utils';
import { SharedService } from './../../services/share.service';
import { MultiSelect } from 'primeng/multiselect';

@Component({
  selector: 'pfep-look-up-field',
  templateUrl: './look-up-field.component.html',
  styleUrls: ['./look-up-field.component.scss']
})
export class LookUpFieldComponent implements OnInit {
  @Input() config;
  @Input() dropDownList;
  @Input() itemNumberLookupData: any = [];
  @Input() workCenterLookupData: any = [];
  @Input() branchLookupData: any = [];
  @Input() onLoadItemId: any;
  @Input() onLoadBranchId: any;
  @Input() onLoadWorkCenterId: any;
  @Output() fieldDropDown = new EventEmitter();
  @Output() lookUpData = new EventEmitter();
  @Output() searchItemValue = new EventEmitter();
  @Output() searchBranchValue = new EventEmitter();
  @Output() searchWorkCenterValue = new EventEmitter();
  selectedWorkCenterData: any = [];
  selectedLookupValue: any = [];
  oldSelected: any = [];
  lookup_config: any;
  checkedAll: any;
  selectedWorkCenterValue: any = [];
  selectedItemLookUpValue: any;
  lookUpKey: any = '';
  tableData: any;
  selecteddropDownValue: any;
  displayDialog = false;
  showDropDown = false;
  field: any;
  columns: any[] = [];
  searchIcon = false;

  constructor(public demandDashboardUtilService: DemandDashboardUtilService, public sharedService: SharedService) { }

  ngOnInit() {
    this.getOnLoadPackagingDemandLists();
  }

  getOnLoadPackagingDemandLists() {
    this.selectedItemLookUpValue = this.onLoadItemId ? this.onLoadItemId : null;
    this.selectedLookupValue = this.onLoadBranchId ? this.onLoadBranchId : null;
    this.selectedWorkCenterValue = [];
    if (!this.selectedItemLookUpValue && !this.selectedLookupValue && this.onLoadWorkCenterId !== undefined) {
      this.selectedWorkCenterData.push({ 'WORK_CENTER_ID': this.onLoadWorkCenterId ? this.onLoadWorkCenterId : null });
      this.selectedWorkCenterData.forEach(data => {
        this.selectedWorkCenterValue.push(data);
      });
      this.showDropDown = true;
      this.searchIcon = true;
    }
  }

  inputModelChange(value) {
    this.selectedLookupValue = (this.lookup_config === 'FACILITY_ID') ? value : null;
    this.selectedItemLookUpValue = (this.lookup_config === 'ITEM_ID') ? value : null;
    this.searchOnFieldValues();
    this.searchOnBranch();
  }

  showDialog() {
    this.displayDialog = true;
    this.fieldDropDown.emit(this.config['lookUpConfig']['dropdownFieldName']);
    this.columns = [];
  }

  getTableData() {
    this.lookUpData.emit([this.selecteddropDownValue, this.lookUpKey]);
    // this.setLookUpData();
  }

  ngOnChanges() {
    this.setLookUpData();

  }

  setLookUpData() {
    this.lookup_config = this.config['lookUpConfig']['dropdownFieldName'];
    if (this.lookup_config === 'FACILITY_ID') {
      this.tableData = this.branchLookupData ?
        this.branchLookupData['SearchRecords'] : null;
      this.setTableWithFieldData(this.tableData);
    } else if (this.lookup_config === 'WORK_CENTER_ID') {
      this.tableData = this.workCenterLookupData
        ? this.workCenterLookupData['SearchRecords']
        : null;
      this.setTableWithFieldData(this.tableData);
    } else if (this.lookup_config === 'ITEM_ID') {
      this.tableData = this.itemNumberLookupData
        ? this.itemNumberLookupData['SearchRecords']
        : null;
      this.setTableWithFieldData(this.tableData);
    }
  }

  onClose() {
    this.displayDialog = false;
    this.selecteddropDownValue = '';
    this.lookUpKey = '';
    this.branchLookupData = null;
    this.workCenterLookupData = null;
    this.itemNumberLookupData = null;
    this.columns = [];
    this.showDropDown = false;
    this.searchIcon = true;
    console.log(this.selectedWorkCenterData, this.selectedWorkCenterValue.length);

    this.selectedWorkCenterValue = new Array<any>();
    this.selectedWorkCenterData.forEach(data => {
      this.selectedWorkCenterValue.push(data);
    });
    this.selectedWorkCenterValue = this.demandDashboardUtilService.removeArrayDuplicates(
      this.selectedWorkCenterValue, 'WORK_CENTER_ID');
    this.showDropDown = true;
    this.searchOnWorkCenters();
    console.log(this.selectedWorkCenterData, this.selectedWorkCenterValue);
  }

  setTableWithFieldData = tableData => {
    this.columns = [];
    if (tableData && tableData.length > 0) {
      Object.values(tableData).forEach(item => {
        this.field = Object.keys(item);
      });
      if (this.field && this.field[0] === undefined) {
        this.columns = [];
      } else {
        this.columns.push({ field: this.field[0], header: 'Description' });
      }
    }

  }

  setHeader(data) {
    const result = data.map(function (el) {
      const o = Object.assign({}, el);
      o.header = 'Description';
      return o;
    });
    console.log(result);
  }

  onRowSelect(event) {
    this.selectedWorkCenterValue = new Array<any>();
    if (event.data['WORK_CENTER_ID']) {
      this.selectedWorkCenterData.push(event.data);
    }
    if (event.data['ITEM_ID']) {
      this.selectedItemLookUpValue = event.data[this.lookup_config];
    } else {
      this.selectedLookupValue = event.data[this.lookup_config];
    }
    this.searchOnFieldValues();
    this.searchOnBranch();
    if (
      !this.selectedWorkCenterData &&
      this.selectedItemLookUpValue !== null &&
      this.selectedLookupValue !== null
    ) {
      this.onClose();
    }
  }

  choosenWorkCenters() {
    this.searchOnWorkCenters();
  }

  /*checked(col, event) {
    if (event.target.checked) {
      this.selectedWorkCenterData.push(col);
      this.selectedWorkCenterValue.push(col);
    }
    console.log(this.selectedWorkCenterData);
  }*/

  searchOnFieldValues() {
    this.searchItemValue.emit({
      selectedItemLookUpValue: this.selectedItemLookUpValue
    });
  }

  searchOnBranch() {
    this.searchBranchValue.emit({
      selectedLookupValue: this.selectedLookupValue
    });
  }

  searchOnWorkCenters() {
    this.searchWorkCenterValue.emit({
      selectedWorkCenterValue: this.selectedWorkCenterValue
    });
  }
}

