import {
  Component,
  OnInit,
  OnChanges,
  Input,
  Output,
  EventEmitter,
  ViewEncapsulation
} from '@angular/core';
import * as XLSX from 'xlsx';
import { MasterdataService } from '../master-data.service';
import { ToastrService } from 'ngx-toastr';
import { CoreServices } from 'src/app/core/services/core.service';

@Component({
  selector: 'pfep-masterdata-table-forms',
  templateUrl: './masterdata-table-forms.component.html',
  styleUrls: ['./masterdata-table-forms.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MasterdataTableFormsComponent {
  @Input() data;
  @Input() searchData;
  @Input() formTableKeysValues;
  @Input() pagination;
  @Input() loading;
  @Input() isEditable = false;
  @Input() isPartialEditable = false;
  @Output() public save = new EventEmitter<any>();
  @Output() public pageChange = new EventEmitter<any>();
  @Output() public downloadExcel = new EventEmitter<any>();
  @Output() public dataEdited = new EventEmitter<any>();
  @Output() public discardChanges = new EventEmitter<any>();
  displayDialog: boolean;
  masterDataRow: any = {};
  count = 0;
  masterData: any = [];
  selectedRowIndex: number;
  downloadConfig: any = {};
  headerText: string;
  mode: boolean;
  submitted = false;
  isNew = false;
  sortMode = { status: false, field: '' };
  maxExcelDataCount = 1000;
  PFEPSpecialist = ['ITEM_ID', 'CONTAINER_USAGE_TYPE1'];
  currentPage = 1;
  rowsPerPage = 10;
  facilities: Object;
  excelUploaded: boolean = false;

  constructor(
    public mdService: MasterdataService,
    private coreServices: CoreServices,
    private toastr: ToastrService
  ) {
    this.IECheck();
  }
  /*ngOnChanges = () => {

    this.mdDownloadExcel();

  ngOnInit = () => {
   console.log(this.data, this.searchData, this.formTableKeysValues);
  }*/

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnChanges() {
  }

  onClose() {
    this.submitted = false;
  }


  IECheck(): void {
    if (FileReader.prototype.readAsBinaryString === undefined) {
      FileReader.prototype.readAsBinaryString = function (fileData) {
        const pt = this;
        const reader = new FileReader();
        reader.onload = function (e) {
          const blobURL = URL.createObjectURL(fileData);
          const xhr = new XMLHttpRequest;
          xhr.open('get', blobURL);
          xhr.overrideMimeType('text/plain; charset=x-user-defined');
          xhr.onload = function () {
            const g = { target: { result: xhr.response } };
            pt.onload(g);
          };
          xhr.send();
        };
        reader.readAsArrayBuffer(fileData);
      };
    }
  }

  mdUploadExcel(evt: any) {
    if (this.mdService.masterDataFileValidation(evt.target.files[0])) {
      /* wire up file reader */
      if (evt.target.files[0].name.split('.')[0] === this.searchData.DataType.split('_').join(' ')) {
        const target: DataTransfer = <DataTransfer>evt.target;
        if (target.files.length !== 1) {
          throw new Error('Cannot use multiple files');
        }
        const reader: FileReader = new FileReader();
        reader.onload = (e: any) => {
          /* read workbook */
          const bstr: string = e.target.result;
          const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary', cellDates: true, dateNF: 'mm/dd/yyyy' });

          /* grab first sheet */
          const wsname: string = wb.SheetNames[0];
          const ws: XLSX.WorkSheet = wb.Sheets[wsname];

          /* save data */
          // this.data = <AOA>(XLSX.utils.sheet_to_json(ws, {header: 1}));
          const excelReadData = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false });
          if (excelReadData.length < this.maxExcelDataCount) {
            const excelData = this.mdService.validateExcelData(
              excelReadData,
              //  XLSX.utils.sheet_to_row_object_array(ws, {raw: false})
              this.formTableKeysValues,
              this.searchData
            );
            if (excelData.status) {
              this.data = [];
              this.masterData = [];
              this.data['MasterDataList'] = excelData['data'];
              this.data['MasterDataList'].forEach(element => {
                this.masterData.push(element);
              });
              this.dataEdited.emit(true);
              this.excelUploaded = true;
            }
          } else {
            this.toastr.error(`Excel has more then ${this.maxExcelDataCount} records.`);
          }


        };

        reader.readAsBinaryString(target.files[0]);
      } else {
        this.toastr.error(`Incorrect file name. it should be ${this.searchData.DataType.split('_').join(' ')}`);
      }

    } else {
      this.toastr.error('Invalid file selected, valid files are of .xlsx and .xls types');
    }
  }



  mdDownloadExcel = () => {
    this.downloadConfig['data'][this.searchData.DataType] = this.data;
    this.downloadConfig['filename'] = this.searchData.DataType.split('_').join(' ');
    this.downloadConfig['coloumns'][this.searchData.DataType] = this.searchData.DataType.split('_').join(' ');
  }
  mdAdd = () => {
    this.submitted = false;
    this.isNew = true;
    this.mode = true;
    this.headerText = 'Add Details';
    this.displayDialog = true;
    this.selectedRowIndex = -1;
    this.formTableKeysValues.forEach(element => {
      element.value = null;
      element.rowindex = null;
      element.disabled = false;
    });
    this.formTableKeysValues[1].data = [];
  }
  mdSave = (isNew) => {
    const Obj = {};
    this.formTableKeysValues.forEach(element => {
      Obj[element.field] = element.value;
    });
    Obj['isNew'] = isNew;
    Obj['isError'] = false;
    if (this.selectedRowIndex < 0) {
      this.data.MasterDataList.unshift(Obj);
      this.masterData.push(Obj);
    } else {
      this.data.MasterDataList[this.selectedRowIndex] = Obj;
      this.masterData[this.selectedRowIndex] = Obj;
    }
    this.masterDataRow = Obj;
    this.displayDialog = false;
    this.dataEdited.emit(true);
  }
  mdBulkSave = () => {
    this.save.emit(this.masterData.filter(function (el) {
      el['isNew'] = false;
      return el != null;
    }));
    this.masterData = [];
    this.excelUploaded = false;
  }
  onRowSelect = event => {
    if ((this.isEditable || this.isPartialEditable) && this.searchData.DataType !== 'FACILITY_STORAGE_UNITS') {
      this.headerText = 'Edit Details';
      this.isNew = (this.masterDataRow['isNew']) ? true : false;
      this.displayDialog = true;
      this.selectedRowIndex = event.index - ((this.currentPage - 1) * this.rowsPerPage);
      this.formTableKeysValues.forEach(element => {
        element.disabled = (element.isPrimary && !this.isNew) ? true : false;
        element.value = this.masterDataRow[element.field];
      });
      this.getFaclity(this.formTableKeysValues[0], false);
    }
  }
  paginate = (event) => {
    if (this.count > 0) {
      this.currentPage = Math.round(event.first / event.rows) + 1;
      this.rowsPerPage = event.rows;
      this.pageChange.emit(event);
    }
    this.count++;
  }

  downloadServerExcel(event) {
    this.downloadExcel.emit(event);
  }
  isEmpty(val) {
    if (['', null, undefined].indexOf(val) > -1) {
      return true;
    }
    return false;
  }

  onSort(event, field) {
    this.sortMode.status = !this.sortMode.status;
    this.sortMode.field = field;
    if (this.sortMode.status) {
      this.data['MasterDataList'].sort((a, b) => {
        if (a[field] === b[field]) {
          return 0;
        } else if (this.isEmpty(a[field])) {
          return 1;
        } else if (this.isEmpty(b[field])) {
          return -1;
        } else if (a[field] < b[field]) {
          return -1;
        } else if (a[field] > b[field]) {
          return 1;
        }
        return 0;

      });
    } else {
      this.data['MasterDataList'].sort((a, b) => {
        if (a[field] === b[field]) {
          return 0;
        } else if (this.isEmpty(a[field])) {
          return 1;
        } else if (this.isEmpty(b[field])) {
          return -1;
        } else if (a[field] < b[field]) {
          return 1;
        } else if (a[field] > b[field]) {
          return -1;
        }
        return 0;
      });
    }
  }
  getFaclity(col, flag) {
    if ((this.searchData.DataType === 'MATERIAL_FLOW_PLANS' || 'FACILITY_STORAGE_UNITS') && col.field === 'ORG_ID') {
      this.formTableKeysValues[1].value = flag ? null : this.formTableKeysValues[1].value;
      this.coreServices.showLoader();
      this.mdService.getBranchDropDownList(col.value)
        .subscribe((data: any[]) => {
          this.formTableKeysValues[1].data = data.map(e => e.FACILITY_ID);
        });
      this.coreServices.hideLoader();
    }
  }
}
