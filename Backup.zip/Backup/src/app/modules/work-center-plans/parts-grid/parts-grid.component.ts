import {
  Component,
  OnInit,
  AfterViewChecked,
  ViewEncapsulation,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { WorkCenterService } from '../work-center-plans.service';
import { CoreServices } from 'src/app/core/services/core.service';
import * as constants from '../constants';
import { formatDate } from '../utils';
import { WebWorkerService } from 'ngx-web-worker';

@Component({
  selector: 'pfep-parts-grid',
  templateUrl: './parts-grid.component.html',
  styleUrls: ['./parts-grid.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [WebWorkerService]
})
export class PartsGridComponent implements OnInit, AfterViewChecked {

  constructor(
    public workCenterService: WorkCenterService,
    private _webWorkerService: WebWorkerService,
    public coreService: CoreServices
  ) { }
  @Input() tableFields = constants.workCenterPlansTableFields;
  @Input() gridData: Array<object>;
  @Input() loading = false;
  @Input() isEditable: boolean;
  @Input() workCenterId: string;
  @Input() saveDisabled: boolean;
  @Input() itemDetailFn: Function;
  @Input() rowsSubmittedForCopyFn: Function
  @Input() exportExcel: Function
  @Input() singleRackNavigationFn: Function;


  filteredData: Array<object> = [];
  disableView = true;
  recordToEdit: object = {};
  editableFields: object = constants.editableFieldsMap;
  uniqueKeys: Array<string> = [constants.workCenter, constants.branch, constants.itemId, constants.itemPlanId, constants.taskId, constants.orgId];
  uniqueKeysWOPlanId: Array<string> = [
    constants.workCenter,
    constants.taskId,
    constants.itemId,
    constants.branch,
    constants.orgId
  ];
  filters: Array<string> = constants.filters;
  // typeDropDowns: Array<object> = constants.typeDropDowns;
  appliedFilters: object = {};
  searchTerm = '';
  isFilterApplied = true;
  selectedRowIdx = -1;
  formatDate = formatDate;
  allEditableFields = constants.allEditableFields;
  sortFields = constants.sortFields;
  checkboxValues = constants.checkboxValues;
  parseFloat = parseFloat;
  Number = Number;
  Object = Object;
  counter = 0;
  showConciseDetails = false;
  updatedRowIndex: number = -1;
  frozenColumns = constants.frozenColumns;
  scrollListener: any;
  rowsSelectedForCopy: Array<any> = [];
  indexedSelectedRows: object = {};
  itemPlanIdKey = constants.itemPlanId;
  WCStorageID = constants.WCStorageID;
  itemDescKey = constants.itemDesc;

  ngOnInit() {
    this.filteredData = [...this.gridData];
    this.differentiateColumns();
  }

  differentiateColumns = () => {
    const frozenCols = this.frozenColumns.map(col => col.field);
    this.tableFields = this.tableFields.filter(col => frozenCols.indexOf(col.field) === -1)
  }

  ngOnChanges(changes) {
    if (changes.gridData) {
      this.filteredData = [...changes.gridData.currentValue];
      this.disableView = true;
      this.selectedRowIdx = -1;
      this.rowsSelectedForCopy = [];
    }
  }

  navigateToItemPlanDetail = (e, rowData) => {
    e.preventDefault();
    this.itemDetailFn({
      itemPlanRequest: {
        planIdFromParent: rowData[constants.itemPlanId],
        parentScreenPath: '/work-center-plans',
        isChild: true,
        selectedRecord: rowData
      }
    });
  }
  navigateTosingleRack = (e, rowData) => {
    e.preventDefault();
    this.singleRackNavigationFn({
      parentScreenPath: '/work-center-plans',
      isChild: true,
      [constants.branch]: rowData[constants.branch],
      [constants.workCenterId]: rowData[constants.workCenterId],
      [constants.WCStorageSID]: rowData[constants.WCStorageSID]
    });
  }
  getWcStatus(data) {
    const selectedPresentation = this.getDDValue(data[constants.presentation], constants.typeDropDowns[constants.presentation].key);

    const itemPlanStatus = this.getDDValue(data[constants.itemPlanStatus], constants.typeDropDowns[constants.itemPlanStatus].key);

    return (
      ([constants.bulkSelectValue, constants.kitSelectValue].indexOf(selectedPresentation) === -1)
      &&
      (itemPlanStatus && itemPlanStatus.toUpperCase()) === 'ACTIVE')
      ? false
      : true;
  }
  ngAfterViewChecked() {
    // TODO: this code is to generate scroll on frozen column as well which is a slight performance hit. PLease talk to scott and tehn uncomment
    /* if(this.gridData.length > 0 && !this.scrollListener) {
      const frozenColumnView = document.querySelector('.ui-table-scrollable-view.ui-table-frozen-view .ui-table-scrollable-body');
      if(frozenColumnView ) {
        this.scrollListener = true;
        frozenColumnView.addEventListener('scroll', e  => {
            document.querySelector('.ui-table-scrollable-view.ui-table-unfrozen-view .ui-table-scrollable-body').scrollTop = (e.target as HTMLTextAreaElement).scrollTop;
        });
      }
    } */
  }

  trackRow = (idx, row) => {
    return row[this.uniqueKeys[0]] + row[this.uniqueKeys[1]];
  }

  getDDValue = (arr, key) => {
    if (arr) {
      const displayOption = arr.filter(opt => opt.IsSelected);
      return displayOption[0] ? displayOption[0][key] : '';
    }
  }

  /* disablePlanStatus = (field, val) => {
    if (field !== constants.itemPlanStatus) { return false; }
    const statusVal = this.getDDValue(
      this.recordToEdit[constants.itemPlanStatus],
      constants.itemPlanStatusKey
    );
    if (
      statusVal &&
      constants.plsnStatusDisabledOpts[statusVal.toUpperCase()] &&
      constants.plsnStatusDisabledOpts[statusVal.toUpperCase()].indexOf(
        val.toUpperCase()
      ) > -1
    ) {
      return true;
    }
    return false;
  } */

  // constants.dateFields.forEach(field => {
  //   this.dataToSave[field] =
  //     typeof this.dataToSave[field] !== "string"
  //       ? formatDate(this.dataToSave[field], true)
  //       : this.dataToSave[field];
  // });

  getIndex = (data, record, checkWOItemPlan) => {
    //const { uniqueKeys, isPlanIdPresent } = this.determineUniqueKeys(record);
    const uniqueKeys = checkWOItemPlan ? [...this.uniqueKeysWOPlanId] : [...this.uniqueKeys];
    const isPlanIdPresent = !checkWOItemPlan;

    const checkRecEquality = refRecord => {
      let isEqual = true;
      uniqueKeys.forEach(key => {
        if (refRecord[key] !== record[key] && isEqual) {
          isEqual = false;
        }
      });
      return isEqual;
    };


    return uniqueKeys.length > 0
      ? data.findIndex(rec => {
        if (!isPlanIdPresent) {
          if (
            rec[constants.itemPlanId] !== null &&
            rec[constants.itemPlanId] !== undefined
          ) {
            return false;
          } else {
            return checkRecEquality(rec);
          }
        } else {
          return checkRecEquality(rec);
        }
      })
      : data.indexOf(record);
  }

  getRowUniqueValue = (row) => {
    const { uniqueKeys } = this.determineUniqueKeys(row);
    return `${uniqueKeys.map(key => row[key] || '').join('')}`;
  }

  determineUniqueKeys = record => {
    let uniqueKeys = [...this.uniqueKeysWOPlanId];
    let isPlanIdPresent = false;

    if (
      record[constants.itemPlanId] !== null &&
      record[constants.itemPlanId] !== undefined
    ) {
      uniqueKeys = [...this.uniqueKeys];
      isPlanIdPresent = true;
    }

    return { uniqueKeys, isPlanIdPresent };

  }

  updateRow = (data, index, checkWOItemPlan) => {
    this.gridData[index] = { ...data };
    this.updatedRowIndex = this.getIndex(this.filteredData, data, checkWOItemPlan);
    this.filteredData[this.updatedRowIndex] = this.gridData[index];
    setTimeout(() => {
      this.updatedRowIndex = -1;
    }, 4000);
  }

  filterApplied = (value, field, type, key) => {
    this.loading = true;
    if (value === 'null') { value = null; }

    this.disableView = true;
    this.selectedRowIdx = -1;
    switch (type) {
      case 'number':
        value = Number(value);
      case 'decimal':
        value = parseFloat(value);
    }
    this.validateFilters(value, field);
    this.filterFn();
  }

  validateFilters = (value, field) => {
    value
      ? (this.appliedFilters[field] = value)
      : delete this.appliedFilters[field];
    this.isFilterApplied = Object.keys(this.appliedFilters).length > 0;
  }

  filterFn = () => {
    const message = {
      type: 'filterSearch',
      dataArr: [...this.gridData],
      filters: this.appliedFilters,
      searchTerm: this.searchTerm,
      constants: { typeDropDowns: constants.typeDropDowns, dateFields: constants.dateFields }
    };
    this.invokeWorker(message);
  }

  onSort = field => {
    this.loading = true;

    this.sortFields = { ...constants.sortFields };
    this.sortFields[field] =
      this.sortFields[field] === 0 ? 1 : this.sortFields[field] * -1;
    const message = {
      type: 'sort',
      dataArr: [...this.filteredData],
      field,
      sortMode: this.sortFields[field]
    };
    this.invokeWorker(message);
  }

  searchTermChange = e => {
    this.searchTerm = e.target.value;
    this.filterFn();
  }

  invokeWorker = message => {
    const promise =
      message.type === 'filterSearch'
        ? this._webWorkerService.run(this.filterGrid, message)
        : this._webWorkerService.run(this.sortGrid, message);
    promise.then(res => {
      this.updateDataWithSearch([...res]);
    });
  }

  updateDataWithSearch = data => {
    this.filteredData = [...data];
    this.loading = false;
  }

  debounce = (func, timeOut) => {
    let delay;
    return (...rest) => {
      const context = this;
      const later = () => {
        delay = null;
        func.apply(context, rest);
      };
      clearTimeout(delay);
      delay = setTimeout(later, timeOut);
    };
  }

  debounceFilter = this.debounce(this.filterApplied, 1000);
  debounceSearch = this.debounce(this.searchTermChange, 1000);

  filterGrid = input => {
    // date formating function
    const formatDate = (date, withoutTime) => {
      if (date !== null && date !== undefined && date !== "") {
        var d = new Date(date),
          month = "" + (d.getMonth() + 1),
          day = "" + d.getDate(),
          year = d.getFullYear(),
          hours = "" + d.getHours(),
          minutes = "" + d.getMinutes(),
          seconds = "" + d.getSeconds();

        if (month.length < 2) month = "0" + month;
        if (day.length < 2) day = "0" + day;
        if (hours.length < 2) hours = "0" + hours;
        if (minutes.length < 2) minutes = "0" + minutes;
        if (seconds.length < 2) seconds = "0" + seconds;

        return `${[month, day, year].join("-")}${withoutTime ? '' : '  ' + [hours, minutes, seconds].join(":")}`;
      } else {
        return "";
      }
    }

    // grid search function
    const searchGrid = (array, term, cts) => {
      term = term.toUpperCase();
      return [...array].filter(rec => {
        const values = Object.values(rec);
        for (const dd in cts.typeDropDowns) {
          rec[dd].forEach(opt => {
            if (opt.IsSelected) {
              values.push(opt[cts.typeDropDowns[dd].key]);
            }
          });
        }
        cts.dateFields.forEach(field => {
          values.push(cts.formatDate(rec[field]));
        });
        return values.join('^||').toUpperCase().indexOf(term) > -1
          ? true
          : false;
      });
    };

    const { dataArr, filters, searchTerm, constants, type } = input;
    constants.formatDate = formatDate;

    // table filters function
    let filteredData = [...dataArr];
    if (Object.keys(filters).length > 0) {
      filteredData = [...dataArr].filter(rec => {
        let isValid = true;
        Object.keys(filters).forEach(attr => {
          if (constants.typeDropDowns[attr] && isValid) {
            rec[attr].forEach(opt => {
              if (opt[constants.typeDropDowns[attr]['key']] === filters[attr]) {
                isValid = opt.IsSelected;
              }
            });
          } else {
            if (isValid) {
              isValid = rec[attr]
                ? rec[attr].indexOf(filters[attr]) > -1
                : rec[attr] === filters[attr];
            }
          }
        });
        return isValid;
      });
    }

    const finalResults = searchTerm
      ? searchGrid(filteredData, searchTerm, constants)
      : [...filteredData];
    return finalResults;
  }

  sortGrid = input => {
    const { dataArr, field, sortMode, type } = input;
    const dataToSort = [...dataArr];
    dataToSort.sort((a, b) => {
      return sortMode === 1 ? a[field] - b[field] : b[field] - a[field];
    });

    return [...dataToSort];
  }

  // Row Selection functions

  rowSelected = e => {
    this.addRowToCopyCollection(e.data);
  }

  rowUnSelected = e => {
    this.deleteRowFromCollection(e.data);
  }

  rowSelectionChanged = (checked, row) => {
    checked ? this.addRowToCopyCollection(row) : this.deleteRowFromCollection(row).then(this.deleteRow);
  }

  selectAllToggled = checked => {
    checked ? this.selectAllinFilteredList() : this.unSelectAllinFilteredList();
  }

  selectAllinFilteredList = () => {
    this.filteredData.forEach(row => this.addRowToCopyCollection(row));
  }

  unSelectAllinFilteredList = () => {
    this.coreService.showLoader();
    this.invokeWorkerForUnselecting().then(({ rowsSelectedForCopy, indexedSelectedRows }) => {
      this.rowsSelectedForCopy = [...rowsSelectedForCopy];
      this.indexedSelectedRows = { ...indexedSelectedRows };
      this.coreService.hideLoader();
      const t1 = performance.now();
    }).catch(e => {
      this.coreService.hideLoader();
      console.error('ERROR!!!!', e);
    });

  }

  //add row to colelction methods

  addRowToCopyCollection = row => {
    const rowUniqueValue = this.getRowUniqueValue(row);
    if (!this.indexedSelectedRows[rowUniqueValue] && row[constants.itemPlanId]) {
      this.rowsSelectedForCopy.push({ ...row });
      this.indexedSelectedRows[rowUniqueValue] = true;
    } /* else {
      this.invokeWorkerForRowCheck(row).then(idx => {
        if (idx === -1) {
          delete this.indexedSelectedRows[rowUniqueValue];
        }
      })
    } */
  }

  //delete row from collection methods

  deleteRowFromCollection = (row) => {
    const rowUniqueValue = this.getRowUniqueValue(row);
    if (this.indexedSelectedRows[rowUniqueValue] && row[constants.itemPlanId]) {
      return this.invokeWorkerForRowCheck(row);
    }
  }

  deleteRow = idx => {
    const rowUniqueValue = this.getRowUniqueValue(this.rowsSelectedForCopy[idx]);
    this.rowsSelectedForCopy.splice(idx, 1);
    delete this.indexedSelectedRows[rowUniqueValue];
  }

  copyCancelled = () => {
    this.indexedSelectedRows = {};
    this.rowsSelectedForCopy = [];
  }


  // selected row operation worker functions

  invokeWorkerForRowCheck(row) {
    return this._webWorkerService.run(this.checkForRowinCollection, { collection: this.rowsSelectedForCopy, row, uniqueKeys: this.uniqueKeys });
  }

  checkForRowinCollection = ({ collection, row, uniqueKeys }) => {
    const checkRecEquality = refRecord => {
      let isEqual = true;
      uniqueKeys.forEach(key => {
        if (refRecord[key] !== row[key] && isEqual) {
          isEqual = false;
        }
      });
      return isEqual;
    };

    return collection.findIndex(rowToCompare => checkRecEquality(rowToCompare));
  }

  invokeWorkerForUnselecting = () => {
    return this._webWorkerService.run(
      this.unselectAll,
      {
        rowsSelectedForCopy: this.rowsSelectedForCopy,
        filteredData: this.filteredData,
        indexedSelectedRows: this.indexedSelectedRows,
        uniqueKeys: this.uniqueKeys
      });
  }

  unselectAll = ({ rowsSelectedForCopy, filteredData, indexedSelectedRows, uniqueKeys }) => {

    const getRowUniqueValue = (row) => `${uniqueKeys.map(key => row[key] || '').join('')}`;

    const checkForRowinCollection = ({ collection, row, uniqueKeys }) => {
      const checkRecEquality = refRecord => {
        let isEqual = true;
        uniqueKeys.forEach(key => {
          if (refRecord[key] !== row[key] && isEqual) {
            isEqual = false;
          }
        });
        return isEqual;
      };
      return collection.findIndex(rowToCompare => checkRecEquality(rowToCompare));
    }

    const indexes = filteredData.map(row => checkForRowinCollection({ collection: rowsSelectedForCopy, row, uniqueKeys }));

    indexes.sort((a, b) => b - a);
    const idxObj = {};

    indexes.forEach(idx => {
      if (idx !== -1 && !idxObj[idx]) {
        idxObj[idx] = true;
        const rowUniqueValue = getRowUniqueValue(rowsSelectedForCopy[idx]);
        rowsSelectedForCopy.splice(idx, 1);
        delete indexedSelectedRows[rowUniqueValue];
      }
    });

    return { rowsSelectedForCopy, indexedSelectedRows };

  }


}
