import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { PageNotFoundComponent } from "./page-not-found/page-not-found.component";
import { UnAuthorizedComponent } from './un-authorized/un-authorized.component';

@NgModule({
  imports: [CommonModule],
  declarations: [PageNotFoundComponent, UnAuthorizedComponent],
  exports: []
})
export class CoreModule {}
