import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { WorkCenterPlansComponent } from './work-center-plans.component';
import { WorkCenterPlansRoutingModule } from './work-center-plans-routing.module';
import { SharedModule } from '../../shared/shared.module';
import { CalendarModule } from 'primeng/calendar';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { InputSwitchModule } from 'primeng/inputswitch';
import { DialogModule } from 'primeng/dialog';
import { DirectivesModule } from 'src/app/shared/directives/directives.module';
import { TooltipModule } from 'primeng/tooltip';
import { CheckboxModule } from 'primeng/checkbox';
import { PartsGridComponent } from './parts-grid/parts-grid.component';
import { CopyPlansComponent } from './copy-plans/copy-plans.component';

@NgModule({
  imports: [
    WorkCenterPlansRoutingModule,
    CommonModule,
    FormsModule,
    SharedModule,
    CalendarModule,
    TableModule,
    DropdownModule,
    InputSwitchModule,
    DialogModule,
    DirectivesModule,
    TooltipModule,
    CheckboxModule
  ],
  declarations: [WorkCenterPlansComponent, PartsGridComponent, CopyPlansComponent],
  bootstrap: [WorkCenterPlansComponent]
})
export class WorkCenterPlansModule {
  constructor() {
  }
}