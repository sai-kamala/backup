import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";

const httpOptions = {
  headers: new HttpHeaders({
    "Content-Type": "application/json"
  })
};


@Injectable({
  providedIn: "root" // TODO: change the scope to bom component
})
export class BomService {
  baseUrl = environment.api
  constructor(private http: HttpClient) { }
  bomContainerId: any;
  bomOrgId: any;
  routeData: any;

  setBomContainerId = param => (this.bomContainerId = param)
  setBomOrgId = param => (this.bomOrgId = param);
  setRouteData = (CONTAINER_SID, ORG_ID) => (this.routeData = { CONTAINER_SID, ORG_ID })


  getBOMData = id => {
    return this.http.get<Object>(
      `${this.baseUrl}PackageCatalog/GetPackagingComponentList?CONTAINER_SID=${id}`
    );
  };

  saveBomData = (rowData) => {
    return this.http.post<any[]>(`${this.baseUrl}PackageCatalog/UpdateNewPackagingComponent`, rowData);
  };

  deleteComponent = (deleteData) => {
    deleteData.isDeleted = "true";
    return this.http.post<any[]>(`${this.baseUrl}PackageCatalog/DeletePackagingComponent`, deleteData);
  }

  getMaterialData() {
    return this.http.get<any[]>(`${this.baseUrl}PackageCatalog/GetMaterialType`);
  }

  checkValidSupplier(orgID, supplierID) {
    return this.http.get<any[]>(`${this.baseUrl}PackageCatalog/IsValidSupplier?orgID=${orgID}&supplierID=${supplierID}`);
  }

  deleteUploadedFiles(ids) {
    return this.http.post(`${this.baseUrl}PackageCatalog/DeleteUploadFiles`, ids);
  }
}
