import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class CoreServices {
  navItemsJson = 'assets/jsons/menu-constants.json';
  count = 0;
  constructor(private http: HttpClient, private toastr: ToastrService) { }

  getNavItems(): Observable<any> {
    return this.http.get<any[]>(this.navItemsJson);
  }


  get(url): Observable<any> {
    return this.http.get<any[]>(url);
  }

  Post(url, data): Observable<any> {
    return this.http.get<any[]>(url, data);
  }

  checkAccess(routeRoles) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    let editAccess = false;
    if (Array.isArray(currentUser.roles)) {
      editAccess = currentUser.roles.some(obj => routeRoles.indexOf(obj) >= 0);
    } else {
      editAccess = JSON.parse(currentUser.roles).some(obj => routeRoles.indexOf(obj) >= 0);
    }
    return editAccess;
  }

  checkRole = role => {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    let rolePresent = false;
    if (Array.isArray(currentUser.roles)) {
      rolePresent = currentUser.roles.indexOf(role) > -1;
    } else {
      rolePresent = JSON.parse(currentUser.roles).indexOf(role) > -1;
    }
    return rolePresent;
  }

  showLoader() {
    this.count++;
  }
  hideLoader() {
    this.count > 0 ? this.count-- : this.count = 0;
  }
  checkLoader() {
    return this.count;
  }

  successToaster(data) {
    this.toastr.success(data, '', { disableTimeOut: false });
  }

  failureToaster(data) {
    this.toastr.error(data);
  }



}
