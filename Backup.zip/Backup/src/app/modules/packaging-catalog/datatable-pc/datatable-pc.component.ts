import { Component, OnChanges, Input, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'datatables.net';
import { PackagingCatalogService } from '../packaging-catalog.service';
import { Router, ActivatedRoute } from '@angular/router';
import * as tableKeyFields from '../packaging_catalog';
// import {APP_ROUTER_PROVIDERS} from "./../packaging-catalog-routing.module"

@Component({
  selector: 'app-datatable-pc',
  templateUrl: './datatable-pc.component.html',
  styleUrls: ['./datatable-pc.component.css']
})
export class DatatablePCComponent implements OnChanges {
  @Input() searchTableData: any;
  @Input() isSearchNull: Boolean;
  @Input() tableFields: any;
  @Input() isEditable = false;
  loadPackageDetailsScreen = false;
  rowClickData: any;
  loadComponent = false;
  tableKey = 'CONTAINER_CODE';
  first: any;

  

  constructor(private router: Router, public packagingCatalogService: PackagingCatalogService) {

  }
  childData: any;
  searchTest: any;

  ngOnChanges(changes) {
    if(changes.searchTableData) {
      this.first = 0;
    }
    this.isSearchNull !== true ? this.fetchData() : this.emptyTable();
  }

  fetchData() {
    return this.searchTableData;
  }

  reloadGridData() {

  }

  emptyTable = () => {
    this.searchTableData = null;
  }

  onRowSelect(event, rowData) {
    event.preventDefault();
    this.rowClickData = rowData ? rowData['CONTAINER_SID'] : null;
    this.packagingCatalogService.setParamForEdit(this.rowClickData);
    // this.router.config.filter(e=>e.path==='catalog')
    // this.route.parent.data.subscribe((data)=> console.log(data));
    // APP_ROUTER_PROVIDERS[0].forEach(data => this.getChildPath(data))
    // console.log(this.childPath);
    // childRoutes.find(e=>e.path === 'edit-detail').data.containerID = this.rowClickData;
    this.router.navigate(['catalog/edit-detail']);
  }

  pageChange(e) {
    this.first = e.first;
  }


}
