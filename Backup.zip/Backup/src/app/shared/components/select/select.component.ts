import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { config } from 'rxjs';


@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.css']
})
export  class SelectComponent implements OnInit {
@Input() config;
@Input() data;
@Input() defaultLabel;
@Input() loadSelectedValue;
@Output() public onChange = new EventEmitter<any>();
modifiedData: any = [];
public selectedValue;
  constructor() {}
  ngOnChanges() {
    this.lableChange();
    this.loadSelectedData();
  }
  ngOnInit() {

  this.data.forEach(element => {
    this.modifiedData.push({'label': element.split('_').join(' '), 'value': element});
  });
   this.lableChange();

     if (this.config.selectedValue) {
        this.selectedValue = this.config.selectedValue;
     } else {
       this.selectedValue = '';
     }

  }
  lableChange() {
    this.defaultLabel = this.defaultLabel.replace('_', ' ');
  }
  loadSelectedData() {

    if (this.loadSelectedValue) {
      console.log(this.loadSelectedValue);
      this.selectedValue = this.loadSelectedValue;
    } else {
      this.selectedValue = '';
    }
  }
  ChangingValue(event) {
    this.onChange.emit(this.selectedValue);
  }

}
