import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WorkCenterPlansComponent } from './work-center-plans.component';
import { AuthGuard } from 'src/app/core/guards/auth-guard';
import { CanDeactivateGuard } from 'src/app/core/guards/can-deactivate-guard';

const routes: Routes = [
  { path: '', component: WorkCenterPlansComponent, data: { roles: ['PFEP SPECIALIST'] }, canActivate: [AuthGuard], canDeactivate: [CanDeactivateGuard] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WorkCenterPlansRoutingModule { }
