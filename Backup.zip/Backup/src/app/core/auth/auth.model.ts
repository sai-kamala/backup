/*export class AuthModel{
    access_token: any;
    user_name: string;
    roles: any;
    facility_id: any;
    facility_desc: string;
    org_id : string;
    org_desc :string;
    work_center_id : any;
    work_center_desc : string;
    issued : string;
    expires  : any;
    expires_in :any;
    token_type: any;
 }
*/
