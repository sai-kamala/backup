import {
  RouteReuseStrategy,
  DetachedRouteHandle,
  ActivatedRouteSnapshot
} from "@angular/router";
import { Injectable } from "@angular/core";

@Injectable()
export  class CustomReuseStrategy implements RouteReuseStrategy {
  routesToReuse = ["packagingcatalog"];

  // this map is in  toUrl:prevUrl format
  routesMap = {
    packagingcatalog: ["edit-detail", "catalog-detail"]
  };

  // this array is to tell which routes to be held when navigated to certain routes
  routesToStore = {
    "packagingcatalog": ['packagingcatalog', 'edit-detail', "bom", "catalog-detail"]
}

  handlers: { [key: string]: DetachedRouteHandle } = {};

  shouldDetach(route: ActivatedRouteSnapshot): boolean {
    const path = route.routeConfig ? route.routeConfig.path : "";
    if (this.routesToReuse.indexOf(path) > -1) {
      return true;
    }
    return false; // reuse edit-detail route
  }

  store(route: ActivatedRouteSnapshot, handle: DetachedRouteHandle): void {
    this.handlers[this.getRouteKey(route)] = handle;
  }

  shouldAttach(route: ActivatedRouteSnapshot): boolean {
    this.removeHandles(route);
    const url = this.getRouteKey(route);
    return !!this.handlers[url];
  }

  retrieve(route: ActivatedRouteSnapshot): DetachedRouteHandle {
    if (!route.routeConfig) return null;
    return this.handlers[this.getRouteKey(route)];
  }

  shouldReuseRoute(
    previous: ActivatedRouteSnapshot,
    current: ActivatedRouteSnapshot
  ): boolean {
    return Object.keys(this.routesMap).indexOf(current.url.join("/")) > -1 &&
      (this.routesMap[current.url.join("/")].indexOf(previous.url.join("/")) > -1)
      ? true
      : false;
  }

  getRouteKey(route) {
    if (route.routeConfig) return `${route.routeConfig.path}`;
  }

  removeHandles(route) {
    const handles = Object.keys(this.handlers);
    handles.forEach(handle => {
      if(route.routeConfig && this.routesToStore[handle] && this.routesToStore[handle].indexOf(route.routeConfig.path) === -1) {
        this.handlers = {};
      }
    })
  }
}
