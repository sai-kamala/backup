export default {
    formTableKeysValues: [
        { header: 'Description', field: 'ITEM_ID' },
        { header: 'Description', field: 'ORG_ID' }
    ]
};

export class tableFields {
    tableFields: [
        'ITEM_ID', 'WORK_CENTER_ID', 'FACILITY_ID'
    ];
}
