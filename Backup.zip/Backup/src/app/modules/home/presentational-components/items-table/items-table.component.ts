// Presentational Component for table (Screens to display when clicked on graph)

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-items-table',
  templateUrl: './items-table.component.html',
  styleUrls: ['./items-table.component.css']
})
export  class ItemsTableComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
