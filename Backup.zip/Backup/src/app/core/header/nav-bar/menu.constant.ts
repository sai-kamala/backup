export const menuItems = [
    {
        'label': 'Home',
        'to': '/home'
    },
    {
        'label': 'PFEP Summary',
        'to': '/pfep-summary'
    },
    {
        'label': 'Work Center Plans',
        'to': '/work-center-plans'
    },
    {
        'label': 'Demand Dashboard',
        'to': '/demand'
    },
    {
        'label': 'Packaging Catalog',
        'to': '/catalog'
    },
    {
        'label': 'Master Data',
        'to': '/masterdata'
    },
    {
        'label': 'Item Flow Summary',
        'to': '/plans'
    },
    {
        'label': 'Item Plan Detail',
        'to': '/item-plan-detail'
    },
    {
        'label': 'POU Presentation',
        'to': '/pou'
    },
    {
        'label': 'MFCR',
        'to': '/mfcr'
    },
    {
        'label': 'Administration',
        'to': '/administrator'
    }
];
