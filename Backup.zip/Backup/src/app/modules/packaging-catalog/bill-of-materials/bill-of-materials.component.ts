import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { BomService } from './bom.service';
import { DataTableDirective } from 'angular-datatables';
import { DatePipe, Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { FileUploadService } from '../file-upload.service';
import { CoreServices } from 'src/app/core/services/core.service';
import { ModalService } from 'src/app/core/services/modal.service';
import { NavBarComponent } from 'src/app/core/header/nav-bar/nav-bar.component';
import { SharedService } from 'src/app/shared/services/share.service';
import * as constants from './constants';
import { forkJoin } from 'rxjs';
import { PhotoPlanningComponent } from './photo-planning/photo-planning.component';

class Bom {
  PartNumber: number;
  Description: string;
  Supplier: string;
  Cost: number;
  MaterialType: string;
  Quantity: number;
  Notes: any;
}
@Component({
  selector: 'app-bill-of-materials',
  templateUrl: './bill-of-materials.component.html',
  styleUrls: ['./bill-of-materials.component.scss']
})
export class BillOfMaterialsComponent implements OnInit {
  @ViewChild(DataTableDirective) public datatableElement: DataTableDirective;
  @ViewChild(PhotoPlanningComponent) public photoPlanningComp: PhotoPlanningComponent;
  // @ViewChild(NavBarComponent) nav: NavBarComponent;
  boms = [];
  bomDetails: any = {};
  returnScreen: boolean;
  bomData: Object = {};
  containerId = '';
  orgId = '';
  showGrid: Boolean = false;
  dtOptions: Object = {};
  selectedIds: Array<string> = [];
  isFormInvalid: Boolean = false;
  supplierInvalid: Boolean = false;
  files: any;
  selectedMaterial: any;
  formData = new FormData();
  fileArray: any[] = [];
  imgUploaded = false;
  bgImgPath: any = '';
  // change user id once fetched from db
  userId: any = '';
  imagesArray: any[] = [];
  photo_id: any;
  photo_title: any;
  uploadImagesForId: any[] = [];
  newFileArray: any[] = [];
  materialDropDownData = [{}];
  materialInvalid = false;
  isEditable = false;
  hasEdit = false;
  columns = [
    { header: 'Part Number', field: 'ITEM_ID' },
    { header: 'Description', field: 'PACKAGING_DESC' },
    { header: 'Supplier', field: 'SUPPLIER_ID' },
    { header: 'Cost($)', field: 'ITEM_COST' },
    { header: 'Material Type', field: 'MTRL_TYPE' },
    { header: 'Quantity', field: 'ITEM_QNTY' },
    { header: 'Notes', field: 'PACKAGING_NOTES' },
  ];
  tableGridData: any = [];
  fields: Array<string> = [
    'ITEM_ID',
    'PACKAGING_DESC',
    'SUPPLIER_ID',
    'ITEM_COST',
    'MTRL_TYPE',
    'ITEM_QNTY',
    'PACKAGING_NOTES',
    'PHOTO_SID',
    'PHOTO_ORIGIN_SCREEN',
    'PHOTO_TITLE',
    'Photoplanning'
  ];
  static_required_fields: Array<string> = [
    'ITEM_ID',
    'SUPPLIER_ID',
    'MTRL_TYPE'
  ];
  index: any = -1;
  bomRouteData: any;
  isSupplierInvalid: boolean;
  photoPlanning = [];
  selectedBOM: any = {};
  deletedBOMImages = [];
  invalidCtr: boolean = false;

  constructor(
    public fb: FormBuilder,
    public router: Router,
    public route: ActivatedRoute,
    private bomService: BomService,
    public datePipe: DatePipe,
    private toastr: ToastrService,
    public fileUploadService: FileUploadService,
    private coreServices: CoreServices,
    private modalService: ModalService,
    private location: Location,
    private sharedService: SharedService
  ) {
    this.buildForm();
    // this.buildGrid();
  }
  ngOnInit() {
    this.bomRouteData = this.bomService.routeData;
    const routeRoles = this.route.snapshot.data.roles;
    this.isEditable = this.coreServices.checkAccess(routeRoles);
    if (this.bomRouteData !== null && this.bomRouteData !== undefined) {
      this.containerId = this.bomService.bomContainerId;
      this.orgId = this.bomService.bomOrgId;
      console.log(this.containerId, this.orgId);
      this.orgId = this.bomService.routeData['ORG_ID'];
      this.fetchBOMData();
    } else {
      this.router.navigate(['/home']);
    }
    this.bomService.getMaterialData().subscribe((data: any) => { this.materialData(data); });
    this.subscribeToValueChanges();
  }

  materialData = data => {
    this.materialDropDownData = data;
    this.materialDropDownData.unshift({ MaterialName: 'Select One', value: undefined });
  }

  buildForm = () => {
    this.bomDetails = this.fb.group({
      ITEM_ID: [null, Validators.required],
      PACKAGING_DESC: [null],
      SUPPLIER_ID: [null, Validators.required],
      ITEM_COST: [null],
      MTRL_TYPE: [null, Validators.required],
      ITEM_QNTY: [null],
      PACKAGING_NOTES: [null],
      PHOTO_SID: [null],
      PHOTO_TITLE: [null]
    });
  }

  extractIds = arr => {
    return arr.map(item => item['ITEM_ID']);
  }

  fetchBOMData = () => {
    this.bomService.getBOMData(this.containerId).subscribe((res: any[]) => {
      if (res && res.length > 0) {
        this.boms = this.extractIds(res);
        this.buildGrid(res);
      } else {
        this.tableGridData = [...res];
      }
    });
  }

  populateForm = data => {
    this.setFieldValues(data);
    this.photoPlanning = [...data.Photoplanning];
  }

  setFieldValues = data => {
    if (data) {
      this.fields.forEach(ctrl => {
        const value = data[ctrl.toUpperCase()] || null;
        if (this.bomDetails.controls[ctrl]) {
          this.bomDetails.controls[ctrl].setValue(value, { onlySelf: true });
        }
        if (data.PHOTO_TITLE) {
          this.bgImgPath = data.PHOTO_TITLE;
          this.imgUploaded = true;
        }
        if (
          value &&
          this.static_required_fields.indexOf(ctrl.toUpperCase()) > -1
        ) {
          this.bomDetails.get(ctrl).disable();
        }
      });
    }
  }

  getFormDetails = () => {
    const formValues = {};
    Object.keys(this.bomDetails.controls).forEach(ctrl => {
      formValues[ctrl] = this.bomDetails.get(ctrl).value;
    });
    formValues[constants.photoPlanning] = this.photoPlanningComp.getPhotoPlanningData();
    return formValues;
  }

  returnToPackingDetailsScreen() {
    // this.nav.breadcrumbListCopy();
    this.sharedService.createCopy.next();
    this.router.navigate(['catalog/edit-detail']);
  }

  // Grid functions
  buildGrid = data => {
    this.tableGridData = data;
    this.showGrid = true;
  }

  onRowSelect = (event) => {
    if (this.isEditable) {
      this.index = event.index;
      // TODO: Dont need this for single selection, added for multi selection
      this.selectedIds = [];
      if (this.boms.indexOf(event.data.ITEM_ID) !== -1) {
        this.selectedIds.push(event.data.ITEM_ID);
        this.resetForm();
        this.populateForm(event.data);
      }
    }
  }

  onRowUnselect = event => {
    this.selectedIds = [];
    this.resetForm();
    this.imgUploaded = false;
    this.index = -1;
    this.selectedBOM = {};
    this.photoPlanning = [];
  }

  prepareRowData = (details, isNew) => {
    return {
      ...details,

      [isNew ? 'CREATED_DATE' : 'UPDATED_DATE']: this.datePipe.transform(
        new Date(),
        'yyyy-MM-dd'
      ),
      [isNew ? 'CREATED_BY_USER' : 'UPDATED_BY_USER']: this.userId
    };
  }

  determineRowIndex(formDetails, tblInstance) {
    let idx = -1;
    tblInstance.rows().every(function (rowIndex) {
      if (
        this.data() &&
        this.data()['ITEM_ID'] === formDetails['ITEM_ID'] &&
        idx === -1
      ) {
        idx = rowIndex;
      }
    });
    return idx;
  }

  updateGrid = formDetails => {
    formDetails = this.prepareRowData(formDetails, 'new');
    this.tableGridData.push(formDetails);
    this.imgUploaded = false;
    this.resetForm();
  }

  updateRowData(formDetails) {
    const rowIndex = this.index;
    if (rowIndex !== -1) {
      formDetails = this.prepareRowData(formDetails, false);
      this.tableGridData[rowIndex] = formDetails;
      this.resetForm();
    } else {
      if (!this.checkForDeletedBOM(formDetails)) {
        this.displayMessage('danger', 'Please select a record to update');
      }
    }
  }

  checkForDeletedBOM = formDetails => {
    let replaceDeleted = false;
    this.tableGridData.forEach((rec, idx) => {
      if (rec['ITEM_ID'] === formDetails['ITEM_ID']) {
        rec['IS_DELETED'] = false;
        replaceDeleted = true;
        rec[constants.photoPlanning].forEach(tab => {
          if (tab[constants.photoSID]) {
            this.deletedBOMImages.push(tab[constants.photoSID]);
          }
        });
        this.tableGridData[idx] = { ...rec, ...formDetails };
        this.resetForm();
      }
    });
    return replaceDeleted;
  }

  addBOM() {
    if (this.validateForm() && !this.supplierInvalid) {
      let formDetails = this.getFormDetails();
      if (this.updateExistingRecWithoutSelection(formDetails)) {
        this.displayMessage('danger', 'BOM with this Component Code already exists');
        return;
      }
      if (this.boms.indexOf(formDetails['ITEM_ID']) === -1) {
        this.boms.push(formDetails['ITEM_ID']);
        if (!this.showGrid) {
          // add the first row to the table
          formDetails = this.prepareRowData(formDetails, true);
          this.buildGrid([formDetails]);
          this.imgUploaded = false;
          this.resetForm();
        } else {
          // add subsequent rows
          this.updateGrid(formDetails);
        }
      } else {
        // update existing row
        this.imgUploaded = false;
        this.updateRowData(formDetails);
      }
    } else {
      this.isFormInvalid = true;
    }
    this.photoPlanning = [];
    this.index = -1;
    this.selectedBOM = {};
  }

  updateExistingRecWithoutSelection = (formDetails) => {
    const rec = this.tableGridData.filter(rec => rec['ITEM_ID'] === formDetails['ITEM_ID']);
    if (this.boms.indexOf(formDetails['ITEM_ID']) !== -1 && this.index === -1 && rec.length > 0 && !rec[0]['IS_DELETED']) {
      return true;
    }
    return false;
  }

  saveBom() {
    if (this.tableGridData.length > 0) {
      this.deleteFiles();
    }
  }

  deleteFiles = () => {
    let deletedPhotoSIDs = [];
    this.tableGridData.map(bom => {
      bom[constants.photoPlanning].forEach(row => {
        if (row['imgDeleted'] && !bom['IS_DELETED']) {
          deletedPhotoSIDs.push({ 'ITEM_ID': bom['ITEM_ID'], [constants.tabName]: row[constants.tabName], [constants.photoSID]: row[constants.photoSID] });
        }
      });
    });
    //removing duplicate SID's if any
    const tempIdArr = [...deletedPhotoSIDs.map(rec => rec[constants.photoSID]), ...this.deletedBOMImages]
    const deletedSIDSet = tempIdArr.filter(function (item, pos) {
      return tempIdArr.indexOf(item) === pos;
    });

    if (deletedSIDSet.length > 0) {
      this.bomService.deleteUploadedFiles(deletedSIDSet).subscribe(res => {
        this.deletedBOMImages = [];
        this.fileDeleteSuccess(deletedPhotoSIDs);
        this.uploadNewFiles();
      });
    } else {
      this.uploadNewFiles();
    }
  }

  fileDeleteSuccess = sids => {
    sids.forEach(id => {
      this.tableGridData.forEach((bom, idx) => {
        if (bom['ITEM_ID'] === id['ITEM_ID']) {
          bom[constants.photoPlanning].forEach(rec => {
            if (rec[constants.tabName] === id[constants.tabName]) {
              rec[constants.photoSID] = '';
            }
          });
        }
      });
    });
  }

  uploadNewFiles = () => {
    const newFiles = [];
    this.tableGridData.map(bom => {
      bom[constants.photoPlanning].forEach(row => {
        if (row['newImage'] && !this.isEmpty(row[constants.photoUrl]) && !bom['IS_DELETED']) {
          newFiles.push({ 'ITEM_ID': bom['ITEM_ID'], [constants.tabName]: row[constants.tabName], [constants.photoUrl]: row[constants.photoUrl] });
        }
      });
    });

    this.uploadService(newFiles);
  }

  deleteBOMs = () => {
    this.tableGridData = [...this.tableGridData.filter(bom => !bom['IS_DELETED'])];
  }

  uploadService = newFiles => {
    if (newFiles.length === 0) {
      this.saveUpdatedBoms();
      return;
    }
    this.formData = new FormData();
    this.formData.append('ORG_ID', this.orgId);
    this.formData.append('PHOTO_ORIGIN_SCREEN', 'BOM');
    this.formData.append('CONTAINERSID_ORGID', `${this.containerId}_${this.orgId}`);
    const formDataValue = this.formData;
    for (let i = 0; i < newFiles.length; i++) {
      // Add the file to the request.
      this.formData.append('FileUpload' + i, newFiles[i][constants.photoUrl], `${newFiles[i][constants.tabName]}^${newFiles[i]['ITEM_ID']}^${newFiles[i][constants.photoUrl].name}`);
    }

    this.fileUploadService.uploadFiles(
      this.formData,
      (progress, percent, res) => {
        // if(e.Photoplannings)  this.imagesArray = e.Photoplannings;
        if (
          progress === 'complete' &&
          res.StatusEntity.StatusType === 'SUCCESS'
        ) {
          this.updatePhotoPlannings(res);
        } else if (progress === 'error') {
          this.displayMessage('danger', res);
        }
      }
    );
  }

  updatePhotoPlannings = res => {
    const { Photoplannings: uploadFilesRes } = res;
    uploadFilesRes.forEach(rec => {
      this.tableGridData.forEach(bom => {
        if (bom['ITEM_ID'] === rec['ITEM_ID']) {
          bom[constants.photoPlanning].forEach((pP, idx) => {
            if (pP[constants.tabName] === rec[constants.tabName]) {
              const isDefault = pP[constants.defaultTab];
              bom[constants.photoPlanning][idx] = { ...pP, ...rec, [constants.defaultTab]: isDefault };
            }
          })
        }
      })
    })
    this.saveUpdatedBoms();
  }

  saveUpdatedBoms = () => {
    this.tableGridData.forEach(data => {
      data['CONTAINER_SID'] = this.containerId;
      data['ORG_ID'] = this.orgId;
      data['PHOTO_ORIGIN_SCREEN'] = 'BOM';
    });
    this.bomService.saveBomData(this.tableGridData).subscribe(data => {
      if (data['StatusType'] === 'SUCCESS') {
        // this.uploadService();
        this.hasEdit = false;
        this.displayMessage('success', 'Details succesfully updated');

      } else {
        this.displayMessage('danger', data['Message']);
      }
    });
  }

  displayMessage(
    type = 'danger',
    message = 'Unknown Error occured. Please try again.'
  ) {
    type === 'danger' ? this.toastr.error(message) : this.toastr.success(message, '', { disableTimeOut: false });
  }

  checkValidSupplier() {
    const supplierId = this.bomDetails.get('SUPPLIER_ID').value;
    if (supplierId) {
      this.bomService.checkValidSupplier(this.orgId, supplierId)
        .subscribe(data => {
          if (data['StatusType'] === 'SUCCESS') {
            this.supplierInvalid = false;
          } else {
            this.supplierInvalid = true;
          }
        });
    }
  }

  removeBOM() {
    if (this.index > -1) {
      // TODO: Remove the below line and the corresponding function
      //this.photoPlanningComp.deleteBOM();
      this.tableGridData[this.index]['IS_DELETED'] = true;
      this.index = -1;
      this.selectedBOM = {};
      this.resetForm();
      this.photoPlanning = [];
      // TODO: Remove the below code after testing
      /* const deleteData = this.tableGridData[this.index];
      if (deleteData.IS_DELETED !== undefined) {
        this.bomService
          .deleteComponent(deleteData)
          .subscribe(res => {
            if (res['StatusType'] === 'SUCCESS') {
              this.fetchBOMData();
              this.displayMessage('success', 'Removed Successfully');
              this.resetForm();
            } else {
              this.displayMessage('danger', res['Message']);
            }
          });
      } else {
        this.tableGridData.splice(this.index, 1);
        this.tableGridData = [...this.tableGridData];
        this.resetForm();
        this.displayMessage('success', 'Removed Successfully');
      } */
    } else {
      this.resetForm();
      this.supplierInvalid = false;
    }
  }

  resetForm = () => {
    this.bomDetails.reset();
    this.isFormInvalid = false;
    this.supplierInvalid = false;
    this.materialInvalid = false;
    this.invalidCtr = false;
    this.static_required_fields.forEach(ctrl => {
      if (this.bomDetails.get(ctrl).disabled === true) {
        this.bomDetails.get(ctrl).enable();
      }
    });
  }

  validateForm = () => {
    // TODo: Add form validations here
    let detailsValid = true;
    this.invalidCtr = false;
    this.materialInvalid = false;
    this.static_required_fields.forEach(field => {
      const fieldState = this.bomDetails.get(field);
      if ((fieldState.invalid || fieldState.value === null) && detailsValid) {
        detailsValid = false;
      }

      if (field === 'SUPPLIER_ID') {
        if ((fieldState.value === undefined || fieldState.invalid || fieldState.value === null)) {
          detailsValid = false;
          this.supplierInvalid = true;
        }
      }

      if (field === 'MTRL_TYPE') {
        this.materialDropDownData.forEach(data => {
          if (fieldState.value === undefined) {
            detailsValid = false;
            this.materialInvalid = true;
          }
        });
      }

      if (field === 'ITEM_ID') {
        if ((fieldState.value === undefined || fieldState.invalid || fieldState.value === null)) {
          detailsValid = false;
          this.invalidCtr = true;
        }
      }
    });
    return detailsValid;
  }

  setImageBg = file => {
    const reader = new FileReader();
    if (file) {
      reader.readAsDataURL(file);
    }
    reader.onloadend = () => {

      this.bgImgPath = reader.result;
      this.imgUploaded = true;
    };
  }

  // File Upload functions

  uploadFiles = event => {
    console.log('--------upload----------');
    this.hasEdit = true;
    this.files = event.target.files;
    this.setImageBg(this.files[0]);
    // this.uploadService();
    if (this.boms.indexOf(this.selectedIds[0]) !== -1) {
      this.uploadImagesForId.push(this.files[0]);
    } else if (this.boms.indexOf(this.selectedIds[0]) === -1) {
      this.newFileArray.push(this.files[0]);
    }
    //this.uploadService();
  }

  /* uploadService = () => {
    this.formData = new FormData();
    this.formData.append('ORG_ID', this.orgId);
    // this.formData.append('containerSID', this.containerId);
    this.formData.append('PHOTO_ORIGIN_SCREEN', 'BOM');
    this.formData.append('CONTAINERSID_ORGID', `${this.containerId}_${this.orgId}`);
    const formDataValue = this.formData;
    if (
      this.boms.indexOf(this.selectedIds[0]) !== -1 &&
      this.uploadImagesForId.length !== 0
    ) {
      for (let i = 0; i < this.uploadImagesForId.length; i++) {
        // Add the file to the request.
        this.formData.append('FileUpload' + i, this.uploadImagesForId[i], this.uploadImagesForId[i].name);
      }
    } else if (
      this.boms.indexOf(this.selectedIds[0]) === -1 &&
      this.newFileArray.length !== 0
    ) {
      for (let i = 0; i < this.newFileArray.length; i++) {
        // Add the file to the request.
        if (this.newFileArray[i] !== undefined) {
          this.formData.append(
            'FileUpload' + i,
            this.newFileArray[i],
            this.newFileArray[i].name
          );
        }
      }
    }

    this.fileUploadService.uploadFiles(
      this.formData,
      (progress, percent, e) => {
        // if(e.Photoplannings)  this.imagesArray = e.Photoplannings;
        if (
          progress === 'complete' &&
          e.StatusEntity.StatusType === 'SUCCESS'
        ) {
          // this.bgImgPath=e.Photoplannings[0].PHOTO_TITLE;
          this.displayMessage('success', 'File Uploaded Successfully');
          if (
            e.Photoplannings !== null &&
            e.Photoplannings !== undefined
          ) {
            this.imagesArray = e.Photoplannings;
            this.uploadImagesForId = [];
            this.newFileArray = [];
          }
        } else if (progress === 'error') {
          this.displayMessage('danger', e);
        }
      }
    );
  } */

  subscribeToValueChanges = () => {
    this.bomDetails.valueChanges
      .subscribe(val => {
        this.hasEdit = true;
      });
  }


  canDeactivate = () => {
    if (this.hasEdit) {
      this.modalService.open();
      return this.modalService.getConfirmationSubject();
    }
    return true;

  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.hasEdit = false;
    }, 800);
  }

  validateNumber(controlName, event) {
    if (event.target.value === '.') {
      this.bomDetails.controls[controlName].setValue(null);
      event.target.value = '';
    }
  }

  isEmpty = val => [null, undefined, ''].indexOf(val) > -1;

}
