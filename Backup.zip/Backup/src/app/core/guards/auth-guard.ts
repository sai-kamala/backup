

import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CoreServices } from 'src/app/core/services/core.service';

const userAdmin = ['USER ACCESS ADMINISTRATOR'];


@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
    constructor(private router: Router, private coreServices: CoreServices) { }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser) {
            // check if route is restricted by role
            if (this.coreServices.checkAccess(userAdmin)) {
                this.coreServices.hideLoader();
                this.router.navigate(['/administrator']);
                return false;
            } else if (!this.coreServices.checkAccess(userAdmin)) {
                return true;
            }
        }
        // not logged in so redirect to login page with the return url
        this.router.navigate(['/un-authorized']);
        return false;
    }
}
