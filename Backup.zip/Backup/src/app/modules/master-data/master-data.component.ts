import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import mdConstants from './master-data-pages';
import { MasterdataService } from './master-data.service';
import { ToastrService } from 'ngx-toastr';
import { CoreServices } from 'src/app/core/services/core.service';
import { ActivatedRoute } from '@angular/router';
import { ModalService } from 'src/app/core/services/modal.service';
import { MasterdataTableFormsComponent } from './masterdata-table-forms/masterdata-table-forms.component';
@Component({
  selector: 'pfep-masterdata',
  templateUrl: './master-data.component.html',
  styleUrls: ['./master-data.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MasterDataComponent implements OnInit {
  @ViewChild('fileInput') fileInput;
  @ViewChild(MasterdataTableFormsComponent) MasterdataTable: MasterdataTableFormsComponent;
  masterDataDdconfig = {};
  todos: any;
  defaultLabel: any;
  selectedDataType: any;
  segmentsByUserId: any;
  storageUnitByUserId: any;
  selectedDataTypeKeys: any;
  selectedDataTypeKey: any;
  showStatusDatatype = false;
  paginationData: any;
  searchCriteria: object;
  masterFormData: object;
  masterData: any;
  mdKeysValues: any;
  saveCriteria: any;
  transnationalDataTypes: any = ['ITEM_DEMAND', 'ITEMS', 'MATERIAL_FLOW_PLANS', 'STORAGE_UNITS', 'SHOP_CALENDAR', 'FACILITY_STORAGE_UNITS'];
  pfepTables = ['CONTAINER_USAGE_TYPE', 'ITEM_DEMAND', 'ITEMS', 'PRESENTATION_TYPES', 'REPLENISH_METHOD_CODES', 'SHOP_CALENDAR', 'STORAGE_UNITS'];
  transnationalFields: any = mdConstants['transnationalFields'];
  transnationalDataPageSize = 10;
  transnationalDataPageIndex = 1;
  transnationalPaginationStatus = false;
  isEditable = false;
  dataLoading = false;
  errorData: any = [];
  isPfepSpecialist: boolean;
  isPartialEditable: boolean;
  DimensionalUOM: any;
  WeightUOM: any;
  hasEdits: boolean = false;
  constructor(
    private masterDataService: MasterdataService,
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private coreServices: CoreServices,
    private modalService: ModalService
  ) { }
  ngOnInit() {
    const isAdmin = this.route.snapshot.data.roles.All;
    const isPfepSpecialist = this.route.snapshot.data.roles.Partial;
    this.isEditable = this.coreServices.checkAccess(isAdmin);
    this.isPfepSpecialist = this.coreServices.checkAccess(isPfepSpecialist);
    this.getDataTypes();
    this.getSegmentsByUserId();
    this.getDimensionalUOM();
    this.getWeightUOM();
    this.masterDataDdconfig = {
      selectedValue: '',
      cssClass: 'form-control'
    };
  }
  initTranationlFields() {
    // tslint:disable-next-line:forin
    for (const key in this.transnationalFields) {
      this.transnationalFields[key].forEach(element => {
        return element.value = '';
      });
    }
  }

  isPFEPSPecTable(tableName) {
    const editAccess = this.pfepTables.some(obj => tableName.indexOf(obj) >= 0);
    const canEdit = (editAccess && this.isPfepSpecialist) ? true : false;
    return canEdit;
  }

  checkIfOrg(tableName) {
    const isOrgTable = ['ORGANIZATION'].some(obj => tableName.indexOf(obj) >= 0);
    if (isOrgTable) {
      this.isPartialEditable = false;
      this.isEditable = false;
    }
  }

  getDataTypes() {
    const self = this;
    this.masterDataService.getDataTypes().subscribe(data => {
      self.todos = data;
    });
  }

  getSegmentsByUserId() {
    this.masterDataService.getSegmentsByUserId().subscribe(data => {
      this.segmentsByUserId = data;
    });
  }

  getStorageUnitId() {
    this.masterDataService.getStorageUnitId().subscribe(data => {
      this.storageUnitByUserId = data;
      this.mdKeysValues.forEach(data => {
        if (data.field === 'STORAGE_UNIT_ID') {
          data.data = this.storageUnitByUserId;
        }
      });
    });
  }
  getDimensionalUOM() {
    this.masterDataService.getDimensionalTypes()
      .subscribe(data => {
        this.DimensionalUOM = data.map(e => e['DROP_DOWN_VALUE']);
      });
  }

  getWeightUOM() {
    this.masterDataService.getWeightTypes()
      .subscribe(data => {
        this.WeightUOM = data.map(e => e['DROP_DOWN_VALUE']);
      });
  }

  dataTypeOnChange(data) {
    this.isPartialEditable = this.isPFEPSPecTable(data);
    this.isEditable = this.coreServices.checkAccess(this.route.snapshot.data.roles.All);
    this.checkIfOrg(data);
    this.mdKeysValues = mdConstants.fieldFormsTables[data];
    this.getStorageUnitId();
    this.mdKeysValues.forEach(data => {
      if (data.field === 'ORG_ID') {
        data.data = this.segmentsByUserId;
      }
      if (data.field === 'ITEM_DIMENSION_UOM') {
        data.data = this.DimensionalUOM;
      }
      if (data.field === 'ITEM_WEIGHT_UOM') {
        data.data = this.WeightUOM;
      }
    });
    this.showStatusDatatype = false;
    this.selectedDataType = data;
    this.selectedDataTypeKeys = this.todos.DataTypeKeyValues[data]
      ? this.todos.DataTypeKeyValues[data]
      : [];
    this.selectedDataTypeKey = '';
    if (this.transnationalDataTypes.indexOf(data) !== -1) {
      this.transnationalPaginationStatus = true;
      this.initTranationlFields();

    } else {
      this.transnationalPaginationStatus = false;
    }


  }
  dataTypeKeyOnChange(data) {
    this.selectedDataTypeKey = data;
  }
  // mselectedDataTypeKeys(data) {
  //   this.selectedDataTypeKeys = data;
  // }

  masterDataPageChange(pageData) {
    // this.dataLoading = true;
    this.showStatusDatatype = true;
    this.searchCriteria['PageIndex'] = Math.round(pageData.first / pageData.rows) + 1;
    this.searchCriteria['PageSize'] = pageData.rows;
    this.transnationalDataPageIndex = this.searchCriteria['PageIndex'];
    this.transnationalDataPageSize = this.searchCriteria['PageSize'];
    this.getMasterData();
  }
  download() {
    this.coreServices.showLoader();
    this.masterDataService.getServerExcelFilePath(this.searchCriteria).subscribe(data => {
      if (data.StatusType === 'SUCCESS') {
        window.open(data.FilePath, '_blank');
      } else {
        this.toastr.error(data.Message);
      }
      this.coreServices.hideLoader();
    });
  }
  searchMasterData() {
    this.searchCriteria = {};
    if (this.transnationalPaginationStatus) {
      this.searchCriteria = {
        DataType: this.selectedDataType
      };
      this.transnationalFields[this.selectedDataType].forEach(element => {
        this.searchCriteria[element.field] = element.value;
      });
      this.searchCriteria['PageIndex'] = this.transnationalDataPageIndex;
      this.searchCriteria['PageSize'] = this.transnationalDataPageSize;
    } else {
      this.searchCriteria = {
        DataType: this.selectedDataType,
        Description: this.selectedDataTypeKey
      };
    }
    this.getMasterData();
  }
  getMasterData() {
    this.dataLoading = true;
    this.masterDataService.getMasterData(this.searchCriteria)
      .subscribe(data => {
        this.masterData = data;
        this.hasEdits = false;
        this.showStatusDatatype = true;
        this.dataLoading = false;
        if (this.MasterdataTable) {
          this.MasterdataTable.sortMode.field = '';
          this.MasterdataTable.excelUploaded = false;
        }
        if (this.errorData.length > 0) {
          this.errorData.forEach(element => {
            this.masterData['MasterDataList'].unshift(element);
          });
          this.errorData = [];

        }
      });
  }
  selectedRowDataType(data) {
    this.masterFormData = data;
  }
  saveMasterData(data) {
    if (data.length > 0) {
      this.saveCriteria = {
        DataType: this.searchCriteria['DataType'],
        Description: data
      };
      this.masterDataService.saveMasterData(this.saveCriteria).subscribe(res => {
        (res.StatusType === 'ERROR' || res.StatusType === 'FAILURE') ? this.toastr.error(res.Message) : this.toastr.success(res.Message, '', { disableTimeOut: false });
        if (res.StatusType === 'ERROR' || res.StatusType === 'FAILURE') {
          if (res.InvalidRecords.length > 0) {
            res['InvalidRecords'].filter(element => {
              element['isNew'] = element['isError'] = true;
            });

            this.errorData = res.InvalidRecords;
            this.getMasterData();
          }

        } else {
          this.hasEdits = false;
          this.MasterdataTable.excelUploaded = false;
        }
      });
    } else {
      this.toastr.error('Please Enter or Modify the data');
    }


  }

  upload() {
    const fileBrowser = this.fileInput.nativeElement;
    if (fileBrowser.files && fileBrowser.files[0]) {
      const formData = new FormData();
      formData.append('image', fileBrowser.files[0]);
    }
  }


  dataEdited = event => this.hasEdits = event;

  canDeactivate = () => {

    if (this.hasEdits) {
      this.modalService.open();
      return this.modalService.getConfirmationSubject();
    }

    return true;

  }
}
