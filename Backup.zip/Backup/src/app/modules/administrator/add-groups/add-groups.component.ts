import { Component, OnInit, Input, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import * as constant from '../constants';
import { AdministrativeService } from '../administrator.service';
import { CoreServices } from '../../../core/services/core.service';
import { ConfirmationService } from 'primeng/api';


@Component({
  selector: 'pfep-add-groups',
  templateUrl: './add-groups.component.html',
  styleUrls: ['./add-groups.component.scss']
})
export class AddGroupsComponent implements OnInit {

  constructor(public adminservice: AdministrativeService, public coreService: CoreServices, private confirmationService: ConfirmationService, private changeDetector: ChangeDetectorRef) { }

  groupListColumn: Array<any>;
  @Output() isEdited = new EventEmitter<Boolean>(false);
  groupListData: any;
  wildCardLookUpConfigAdd: Array<any> = [];
  wildCardLookUpConfigUpdate: Array<any> = [];
  showGrid: boolean;
  wildCardLookUpConfigCopy: any;
  addCriteria: any = {
    APPROVAL_GROUP: '',
    ORG_ID: '',
    FACILITY_ID: '',
    OSHKOSH_USER_ID: [],
    WORK_CENTER_IDS: []
  };
  searchCriteria: any = {
    APPROVAL_GROUP: '',
    ORG_ID: '',
    FACILITY_ID: '',
    OSHKOSH_USER_ID: [],
    WORK_CENTER_IDS: [],
    PageSize: 10,
    PageIndex: 1

  };
  addSearchInvalid: boolean = false;
  approvalGroupList: any;
  segmentList: any;
  selectedRecord = [];
  pageCount: number;
  disableSave: boolean;
  getinvalidUsers: any = [];



  ngOnInit() {
    this.groupListColumn = constant.addGroupTblColumns;
    this.addSearchInvalid = false;
    this.disableSave = true;
    this.pageCount = 0;
    this.wildCardLookUpConfigAdd = Object.assign([], [...constant.wildCardLookUpConfig]);
    this.wildCardLookUpConfigUpdate = Object.assign([], [...constant.wildCardLookUpConfig]);
    this.wildCardLookUpConfigCopy = JSON.parse(JSON.stringify(this.wildCardLookUpConfigAdd));
    this.adminservice.getApprovalGroupDD().subscribe(res => {
      this.approvalGroupList = res;
    });
    this.adminservice.getSegmentDD().subscribe(res => {
      this.segmentList = res;
    });
  }

  wildCardChangeEventUpdate(data) {
    this.valueChangeConfirmation(false);
    this.searchCriteria[
      data.modelName === 'WORK_CENTER_ID' ? 'WORK_CENTER_IDS' : data.modelName
    ] = data.selectedData;

    if (data.modelName === constant.branch) {
      this.wildCardLookUpConfigInit([1, 2], 'update');

      this.wildCardLookUpConfigUpdate[1] = {
        ...this.wildCardLookUpConfigUpdate[1],
        dependentData: {
          [constant.segment]: this.searchCriteria[constant.segment],
          [constant.branch]: data.selectedData,
          [constant.workCenter]: '',
          [constant.username]: '',
        }
      }

      this.wildCardLookUpConfigUpdate[2] = {
        ...this.wildCardLookUpConfigUpdate[2],
        dependentData: {
          [constant.segment]: this.searchCriteria[constant.segment],
          [constant.branch]: this.wildCardLookUpConfigUpdate[1].dependentData[constant.branch],
          [constant.workCenter]: '',
          [constant.username]: '',
        }
      }

      this.searchCriteria[constant.workCenterDDKey] = '';
      this.searchCriteria[constant.oshKoshId] = '';
    } else if (data.modelName === constant.workCenter) {


      this.wildCardLookUpConfigInit([2], 'update');

      this.wildCardLookUpConfigUpdate[2] = {
        ...this.wildCardLookUpConfigUpdate[2],
        dependentData: {
          [constant.segment]: this.searchCriteria[constant.segment],
          [constant.branch]: this.wildCardLookUpConfigUpdate[1].dependentData[constant.branch],
          [constant.workCenter]: this.wildCardLookUpConfigUpdate[1].selectedData ? this.wildCardLookUpConfigUpdate[1].selectedData : '',
          [constant.username]: '',
        }
      }
      this.searchCriteria[constant.oshKoshId] = '';
    }
    // else if (data.modelName === constant.oshKoshId) {
    //   this.wildCardLookUpConfigAdd[2] = {
    //     ...this.wildCardLookUpConfigAdd[2],
    //     dependentData: {
    //       [constant.segment]: this.addCriteria[constant.segment],
    //     }
    //   }
    // } 
  }

  wildCardChangeEventAdd(data) {
    this.addCriteria[
      data.modelName === 'WORK_CENTER_ID' ? 'WORK_CENTER_IDS' : data.modelName
    ] = data.selectedData;
    if (data.modelName === constant.branch) {
      this.wildCardLookUpConfigInit([1, 2], 'add');
      this.wildCardLookUpConfigAdd[1] = {
        ...this.wildCardLookUpConfigAdd[1],
        dependentData: {
          [constant.segment]: this.addCriteria[constant.segment],
          [constant.branch]: data.selectedData,
          [constant.workCenter]: '',
          [constant.username]: '',
        }
      }

      this.wildCardLookUpConfigAdd[2] = {
        ...this.wildCardLookUpConfigAdd[2],
        dependentData: {
          [constant.segment]: this.addCriteria[constant.segment],
          [constant.branch]: this.wildCardLookUpConfigAdd[1].dependentData[constant.branch],
          [constant.workCenter]: '',
          [constant.username]: '',
        }
      }
      this.addCriteria[constant.workCenterDDKey] = '';
      this.addCriteria[constant.oshKoshId] = '';
    } else if (data.modelName === constant.workCenter) {


      this.wildCardLookUpConfigInit([2], 'add');

      this.wildCardLookUpConfigAdd[2] = {
        ...this.wildCardLookUpConfigAdd[2],
        dependentData: {
          [constant.segment]: this.addCriteria[constant.segment],
          [constant.branch]: this.wildCardLookUpConfigAdd[1].dependentData[constant.branch],
          [constant.workCenter]: this.wildCardLookUpConfigAdd[1].selectedData ? this.wildCardLookUpConfigAdd[1].selectedData : '',
          [constant.username]: '',
        }
      }
      this.addCriteria[constant.oshKoshId] = '';
    }
    this.valueChangeConfirmation(true);
    //  else if (data.modelName === constant.oshKoshId) {
    //   this.wildCardLookUpConfigAdd[2] = {
    //     ...this.wildCardLookUpConfigAdd[2],
    //     dependentData: {
    //       [constant.segment]: this.addCriteria[constant.segment],
    //     }
    //   }


  }

  wildCardLookUpConfigInit(data, opt) {
    data.forEach(element => {
      if (opt == 'add') {
        this.wildCardLookUpConfigAdd[element] = JSON.parse(JSON.stringify(this.wildCardLookUpConfigCopy[element]));
      } else {
        this.wildCardLookUpConfigUpdate[element] = JSON.parse(JSON.stringify(this.wildCardLookUpConfigCopy[element]));
      }
    });
  }


  getDDValue = (arr, key) => {
    if (arr) {
      const displayOption = arr.filter(opt => opt.IsSelected);
      return displayOption[0] ? displayOption[0][key] : '';
    }
  }

  emptyField = (value, ddKey) => {
    if (Array.isArray(value)) {
      value = this.getDDValue(value, ddKey);
    }
    return [null, '', undefined].indexOf(value) > -1;
  }

  addClicked = () => {
    const addSearch = {};
    addSearch['MFCRApprovers'] = this.addCriteria;
    this.emptyField(this.addCriteria[constant.branch].trim(), '') || this.addCriteria[constant.oshKoshId].length === 0
      || this.emptyField(this.addCriteria[constant.segment], '')
      || this.emptyField(this.addCriteria[constant.approvalGroup], '') ||
      (this.addCriteria[constant.approvalGroup] == 'Materials' && this.addCriteria[constant.workCenterDDKey].length === 0)
      ? (this.addSearchInvalid = true) : this.addGroup()
  }

  addGroup() {
    const oshkoshID = [...this.addCriteria[constant.oshKoshId]];
    this.addCriteria[constant.oshKoshId] = [];
    oshkoshID.forEach(val => {
      this.addCriteria[constant.oshKoshId].push(val.OSHKOSH_USER_ID)
    })
    this.coreService.showLoader();
    const addSearch = {};
    addSearch['MFCRApprovers'] = this.addCriteria;

    this.adminservice.addGroup(addSearch).subscribe(res => {
      if (res['StatusType'] == 'SUCCESS') {
        this.coreService.hideLoader();
        this.adminservice.displayMessage('success', res['Message']);
        this.addSearchInvalid = false;
        this.valueChangeConfirmation(false);
        this.addCriteria[constant.branch] = '';
        this.addCriteria[constant.segment] = '';
        this.addCriteria[constant.approvalGroup] = '';
        this.addCriteria[constant.workCenterDDKey] = [];
        this.addCriteria[constant.oshKoshId] = [];
        this.wildCardLookUpConfigAdd = JSON.parse(JSON.stringify(constant.wildCardLookUpConfig));
        this.changeDetector.detectChanges();
        if (this.showGrid) {
          this.searchGroup();
        }
      } else {
        this.addSearchInvalid = false;
        this.coreService.hideLoader();
        this.adminservice.displayMessage('error', res['Message']);
      }
    });


  }

  searchClicked = () => {
    this.valueChangeConfirmation(false);
    this.emptyField(this.searchCriteria[constant.branch].trim(), '') && this.searchCriteria[constant.oshKoshId].length === 0
      && this.emptyField(this.searchCriteria[constant.segment], '') && this.searchCriteria[constant.workCenterDDKey].length === 0
      && this.emptyField(this.searchCriteria[constant.approvalGroup], '')
      ? this.adminservice.displayMessage('error', 'Please Enter value in any of the search field') : this.searchGroup()
  }

  searchGroup() {
    this.getinvalidUsers = [];
    const oshkoshID = [];
    const oshkoshIDCopy = [...this.searchCriteria[constant.oshKoshId]];
    if (this.searchCriteria[constant.oshKoshId].length > 0) {
      const oshkoshID = [...this.searchCriteria[constant.oshKoshId]];
      this.searchCriteria[constant.oshKoshId] = [];
      oshkoshID.forEach(val => {
        this.searchCriteria[constant.oshKoshId].push(val.OSHKOSH_USER_ID)
      })
    }
    this.coreService.showLoader();
    this.adminservice.searchGroup(this.searchCriteria).subscribe(res => {
      this.coreService.hideLoader();
      if (res['StatusType'] == 'SUCCESS') {
        this.groupListData = res;
        this.searchCriteria[constant.oshKoshId] = oshkoshIDCopy;
        this.selectedRecord = [];
        this.showGrid = true;
      } else {
        this.coreService.hideLoader();
        this.adminservice.displayMessage('error', res['Message']);
      }
    });

  }

  changeGroup(e, opt) {
    if (opt === 'add') {
      this.addCriteria[constant.approvalGroup] = e.target.value;
      this.valueChangeConfirmation(true);
    }
    else {
      this.searchCriteria[constant.approvalGroup] = e.target.value;
      this.valueChangeConfirmation(false);
    }

  }

  changeSegment(event, opt) {
    if (opt === 'add') {
      this.addCriteria[constant.segment] = event.target.value;
      this.wildCardLookUpConfigAdd = JSON.parse(JSON.stringify(constant.wildCardLookUpConfig));
      this.wildCardLookUpConfigAdd.forEach(element => {
        element.dependentData = {
          [constant.segment]: this.addCriteria[constant.segment]
        }
      });
      this.valueChangeConfirmation(true);
    }
    else {
      this.searchCriteria[constant.segment] = event.target.value;
      this.wildCardLookUpConfigUpdate = JSON.parse(JSON.stringify(constant.wildCardLookUpConfig));
      this.wildCardLookUpConfigUpdate.forEach(element => {
        element.dependentData = {
          [constant.segment]: this.searchCriteria[constant.segment]
        }
      });
      this.valueChangeConfirmation(false);
    }

  }

  deleteConfirmation() {
    this.confirmationService.confirm({
      message: 'Do you want to delete the group(s)?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.deleteGroup();
      },
      reject: () => {

      }
    })
  }

  deleteGroup() {
    this.coreService.showLoader();
    if (this.selectedRecord.length > 0) {
      const postdata = {};
      postdata['ApproverSIDs'] = this.selectedRecord.map(val => val.APPROVER_SID);
      this.adminservice.removeApprover(postdata).subscribe(res => {
        if (res['StatusType'] == 'SUCCESS') {
          this.coreService.hideLoader();
          this.adminservice.displayMessage('success', res['Message']);
          this.selectedRecord = [];
          this.searchGroup();
        } else {
          this.coreService.hideLoader();
          this.adminservice.displayMessage('error', res['Message']);
        }
      })
    }
  }

  cellClikedToEdit = (e, col, rowData) => {
    if (!col.isEdit || e.srcElement.className.includes('form-control')) {
      e.stopPropagation();
      return;
    }
  }

  idKeyUp = (e, idx) => {
    if (e.key === 'Enter') {
      this.checkValidUser(idx);
    }
  }

  pageChange(e) {
    this.searchCriteria['PageIndex'] = e.page + 1;
    this.searchCriteria['PageSize'] = e.rows;
    this.searchGroup();
  }


  valueChangeConfirmation(bol) {
    this.isEdited.emit(bol);
  }

  editRow(index) {
    this.groupListData['SearchRecords'][index]['isEdit'] = true;
    this.disableSave = true;
    this.valueChangeConfirmation(true);
  }

  checkValidUser(index) {
    this.adminservice.checkValidUserWitSegment(this.groupListData['SearchRecords'][index]['OSHKOSH_USER_ID'], this.groupListData['SearchRecords'][index]['ORG_ID'])
      .subscribe(res => {
        this.groupListData['SearchRecords'][index]['USER_NAME'] = '';
        if (res['StatusType'] === 'SUCCESS') {
          this.groupListData['SearchRecords'][index]['isValid'] = true;
          this.groupListData['SearchRecords'][index]['USER_NAME'] = res['USER_NAME'];
        } else {
          this.groupListData['SearchRecords'][index]['isValid'] = false;
        }
        this.getinvalidUsers = this.groupListData['SearchRecords'].filter(val => val.isValid == false);
        this.disableSave = (this.getinvalidUsers.length > 0) ? true : false;
      });

  }


  saveChange() {
    const editedRows = {};
    this.coreService.showLoader();
    editedRows['UpdateApprover'] = this.groupListData['SearchRecords'].filter(val => val.isEdit);
    this.adminservice.saveGrpChanges(editedRows).subscribe(res => {
      if (res['StatusType'] == 'SUCCESS') {
        this.getinvalidUsers = [];
        this.coreService.hideLoader();
        this.adminservice.displayMessage('success', res['Message']);
        this.searchGroup();
        this.valueChangeConfirmation(false);
      } else {
        this.coreService.hideLoader();
        this.adminservice.displayMessage('error', res['Message']);
        this.searchGroup();
      }
    })
  }
}
