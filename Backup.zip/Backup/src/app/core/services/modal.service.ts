import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ModalService {
  isShowing = false;
  modal = new Subject();
  confirmation = new Subject();

  getModalSubject() {
    return this.modal;
  }
  open() {
    if (!this.isShowing) {
      this.modal.next(true);
    }
    this.isShowing = true;
  }
  close() {
    if (this.isShowing) {
      this.modal.next(false);
    }
    this.isShowing = false;
  }

  getConfirmationSubject() {
    return this.confirmation;
  }

  navigateAway() {
    this.close();
    this.confirmation.next(true);
  }

  stay() {
    this.close();
    this.confirmation.next(false);
  }
}
