export class PfepShortage {
    /*FEP_SHORTAGE_SID: number = null;*/
    ORG_ID: string = null;
    FACILITY_ID: string = null;
    PERCENT_OVER_TOLERANCE: string = null;
    PERCENT_UNDER_TOLERANCE: string = null;
    ANALYSIS_PERIOD_LENGTH: string = null;
    DURATION_TO_EXCEED: string = null;
}
