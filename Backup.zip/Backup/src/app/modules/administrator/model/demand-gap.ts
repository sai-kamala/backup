export class DemandGap {
    DEMAND_GAP_SID: number = null;
    ORG_ID: string = null;
    FACILITY_ID: string = null;
    DEMAND_GAP_LENGTH: number = null;
}
